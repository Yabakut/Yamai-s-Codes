package p035q;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.lifecycle.C0051d;
import p020io.flutter.embedding.android.C0219c;

/* renamed from: q.b */
public interface C0565b {
    /* renamed from: a */
    boolean mo947a(int i, String[] strArr, int[] iArr);

    /* renamed from: b */
    void mo948b(Bundle bundle);

    /* renamed from: c */
    boolean mo949c(int i, int i2, Intent intent);

    /* renamed from: d */
    void mo950d(Intent intent);

    /* renamed from: e */
    void mo951e(Bundle bundle);

    /* renamed from: f */
    void mo952f();

    /* renamed from: g */
    void mo953g(C0219c<Activity> cVar, C0051d dVar);

    /* renamed from: h */
    void mo954h();

    /* renamed from: i */
    void mo955i();
}
