package p035q;

import android.app.Activity;
import android.os.Bundle;
import p051y.C0862l;
import p051y.C0865o;

/* renamed from: q.c */
public interface C0566c {

    /* renamed from: q.c$a */
    public interface C0567a {
        /* renamed from: b */
        void mo1522b(Bundle bundle);

        /* renamed from: e */
        void mo1523e(Bundle bundle);
    }

    /* renamed from: a */
    Object mo965a();

    /* renamed from: b */
    Activity mo966b();

    /* renamed from: c */
    void mo967c(C0862l lVar);

    /* renamed from: d */
    void mo968d(C0865o oVar);

    /* renamed from: e */
    void mo969e(C0865o oVar);

    /* renamed from: f */
    void mo970f(C0862l lVar);
}
