package p035q;

/* renamed from: q.a */
public interface C0564a {
    /* renamed from: a */
    void mo672a(C0566c cVar);

    /* renamed from: c */
    void mo673c();

    /* renamed from: f */
    void mo674f();

    /* renamed from: g */
    void mo675g(C0566c cVar);
}
