package p030n0;

import kotlin.jvm.internal.C0421b;
import kotlin.jvm.internal.C0429i;
import kotlin.jvm.internal.C0432l;
import p040s0.C0583c;

/* renamed from: n0.a */
public final class C0528a {
    /* renamed from: a */
    public static final <T> Class<T> m1818a(C0583c<T> cVar) {
        C0429i.m1496d(cVar, "<this>");
        Class<?> b = ((C0421b) cVar).mo1322b();
        if (!b.isPrimitive()) {
            return b;
        }
        String name = b.getName();
        switch (name.hashCode()) {
            case -1325958191:
                return !name.equals("double") ? b : Double.class;
            case 104431:
                return !name.equals("int") ? b : Integer.class;
            case 3039496:
                return !name.equals("byte") ? b : Byte.class;
            case 3052374:
                return !name.equals("char") ? b : Character.class;
            case 3327612:
                return !name.equals("long") ? b : Long.class;
            case 3625364:
                return !name.equals("void") ? b : Void.class;
            case 64711720:
                return !name.equals("boolean") ? b : Boolean.class;
            case 97526364:
                return !name.equals("float") ? b : Float.class;
            case 109413500:
                return !name.equals("short") ? b : Short.class;
            default:
                return b;
        }
    }

    /* renamed from: b */
    public static final <T> C0583c<T> m1819b(Class<T> cls) {
        C0429i.m1496d(cls, "<this>");
        return C0432l.m1508b(cls);
    }
}
