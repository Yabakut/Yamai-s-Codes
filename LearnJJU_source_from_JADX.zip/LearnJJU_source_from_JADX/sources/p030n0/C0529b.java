package p030n0;

/* renamed from: n0.b */
public class C0529b extends Error {
    public C0529b() {
        super("Kotlin reflection implementation is not found at runtime. Make sure you have kotlin-reflect.jar in the classpath");
    }
}
