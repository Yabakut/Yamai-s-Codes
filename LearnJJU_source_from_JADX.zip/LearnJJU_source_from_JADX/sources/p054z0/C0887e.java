package p054z0;

import kotlin.jvm.internal.C0430j;
import kotlinx.coroutines.internal.C0482x;
import p017h0.C0195g;
import p032o0.C0547p;
import p046v0.C0689o1;

/* renamed from: z0.e */
public final class C0887e {

    /* renamed from: z0.e$a */
    static final class C0888a extends C0430j implements C0547p<Integer, C0195g.C0198b, Integer> {

        /* renamed from: d */
        final /* synthetic */ C0883c<?> f1675d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        C0888a(C0883c<?> cVar) {
            super(2);
            this.f1675d = cVar;
        }

        /* renamed from: a */
        public final Integer mo1864a(int i, C0195g.C0198b bVar) {
            C0195g.C0200c key = bVar.getKey();
            C0195g.C0198b bVar2 = this.f1675d.f1668e.get(key);
            if (key != C0689o1.f1285c) {
                return Integer.valueOf(bVar != bVar2 ? Integer.MIN_VALUE : i + 1);
            }
            C0689o1 o1Var = (C0689o1) bVar2;
            C0689o1 b = C0887e.m2740b((C0689o1) bVar, o1Var);
            if (b == o1Var) {
                if (o1Var != null) {
                    i++;
                }
                return Integer.valueOf(i);
            }
            throw new IllegalStateException(("Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n\t\tChild of " + b + ", expected child of " + o1Var + ".\n\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n\t\tTo mitigate this restriction please use 'channelFlow' builder instead of 'flow'").toString());
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return mo1864a(((Number) obj).intValue(), (C0195g.C0198b) obj2);
        }
    }

    /* renamed from: a */
    public static final void m2739a(C0883c<?> cVar, C0195g gVar) {
        if (((Number) gVar.fold(0, new C0888a(cVar))).intValue() != cVar.f1669f) {
            throw new IllegalStateException(("Flow invariant is violated:\n\t\tFlow was collected in " + cVar.f1668e + ",\n\t\tbut emission happened in " + gVar + ".\n\t\tPlease refer to 'flow' documentation or use 'flowOn' instead").toString());
        }
    }

    /* renamed from: b */
    public static final C0689o1 m2740b(C0689o1 o1Var, C0689o1 o1Var2) {
        while (o1Var != null) {
            if (o1Var == o1Var2 || !(o1Var instanceof C0482x)) {
                return o1Var;
            }
            o1Var = ((C0482x) o1Var).mo1434x0();
        }
        return null;
    }
}
