package p054z0;

import kotlin.coroutines.jvm.internal.C0410d;
import kotlin.coroutines.jvm.internal.C0411e;
import kotlin.coroutines.jvm.internal.C0414h;
import kotlin.jvm.internal.C0430j;
import p011e0.C0133k;
import p011e0.C0141q;
import p017h0.C0190d;
import p017h0.C0195g;
import p017h0.C0201h;
import p032o0.C0547p;
import p046v0.C0703s1;
import p052y0.C0874c;

/* renamed from: z0.c */
public final class C0883c<T> extends C0410d implements C0874c<T> {

    /* renamed from: d */
    public final C0874c<T> f1667d;

    /* renamed from: e */
    public final C0195g f1668e;

    /* renamed from: f */
    public final int f1669f;

    /* renamed from: g */
    private C0195g f1670g;

    /* renamed from: h */
    private C0190d<? super C0141q> f1671h;

    /* renamed from: z0.c$a */
    static final class C0884a extends C0430j implements C0547p<Integer, C0195g.C0198b, Integer> {

        /* renamed from: d */
        public static final C0884a f1672d = new C0884a();

        C0884a() {
            super(2);
        }

        /* renamed from: a */
        public final Integer mo1862a(int i, C0195g.C0198b bVar) {
            return Integer.valueOf(i + 1);
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return mo1862a(((Number) obj).intValue(), (C0195g.C0198b) obj2);
        }
    }

    public C0883c(C0874c<? super T> cVar, C0195g gVar) {
        super(C0882b.f1665d, C0201h.f297d);
        this.f1667d = cVar;
        this.f1668e = gVar;
        this.f1669f = ((Number) gVar.fold(0, C0884a.f1672d)).intValue();
    }

    /* renamed from: a */
    private final void m2732a(C0195g gVar, C0195g gVar2, T t) {
        if (gVar2 instanceof C0880a) {
            m2734d((C0880a) gVar2, t);
        }
        C0887e.m2739a(this, gVar);
        this.f1670g = gVar;
    }

    /* renamed from: b */
    private final Object m2733b(C0190d<? super C0141q> dVar, T t) {
        C0195g context = dVar.getContext();
        C0703s1.m2180d(context);
        C0195g gVar = this.f1670g;
        if (gVar != context) {
            m2732a(context, gVar, t);
        }
        this.f1671h = dVar;
        return C0885d.f1673a.mo1515f(this.f1667d, t, this);
    }

    /* renamed from: d */
    private final void m2734d(C0880a aVar, Object obj) {
        throw new IllegalStateException(C0608f.m1932e("\n            Flow exception transparency is violated:\n                Previous 'emit' call has thrown exception " + aVar.f1663d + ", but then emission attempt of value '" + obj + "' has been detected.\n                Emissions from 'catch' blocks are prohibited in order to avoid unspecified behaviour, 'Flow.catch' operator can be used instead.\n                For a more detailed explanation, please refer to Flow documentation.\n            ").toString());
    }

    public Object emit(T t, C0190d<? super C0141q> dVar) {
        try {
            Object b = m2733b(dVar, t);
            if (b == C0210d.m564c()) {
                C0414h.m1482c(dVar);
            }
            return b == C0210d.m564c() ? b : C0141q.f277a;
        } catch (Throwable th) {
            this.f1670g = new C0880a(th);
            throw th;
        }
    }

    public C0411e getCallerFrame() {
        C0190d<? super C0141q> dVar = this.f1671h;
        if (dVar instanceof C0411e) {
            return (C0411e) dVar;
        }
        return null;
    }

    public C0195g getContext() {
        C0190d<? super C0141q> dVar = this.f1671h;
        C0195g context = dVar == null ? null : dVar.getContext();
        return context == null ? C0201h.f297d : context;
    }

    public StackTraceElement getStackTraceElement() {
        return null;
    }

    public Object invokeSuspend(Object obj) {
        Throwable b = C0133k.m418b(obj);
        if (b != null) {
            this.f1670g = new C0880a(b);
        }
        C0190d<? super C0141q> dVar = this.f1671h;
        if (dVar != null) {
            dVar.resumeWith(obj);
        }
        return C0210d.m564c();
    }

    public void releaseIntercepted() {
        super.releaseIntercepted();
    }
}
