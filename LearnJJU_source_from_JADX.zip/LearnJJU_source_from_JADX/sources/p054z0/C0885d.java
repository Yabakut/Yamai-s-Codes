package p054z0;

import kotlin.jvm.internal.C0428h;
import kotlin.jvm.internal.C0434n;
import p011e0.C0141q;
import p017h0.C0190d;
import p032o0.C0548q;
import p052y0.C0874c;

/* renamed from: z0.d */
public final class C0885d {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public static final C0548q<C0874c<Object>, Object, C0190d<? super C0141q>, Object> f1673a = ((C0548q) C0434n.m1517a(C0886a.f1674d, 3));

    /* renamed from: z0.d$a */
    /* synthetic */ class C0886a extends C0428h implements C0548q {

        /* renamed from: d */
        public static final C0886a f1674d = new C0886a();

        C0886a() {
            super(3, C0874c.class, "emit", "emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
        }

        /* renamed from: b */
        public final Object mo1515f(C0874c<Object> cVar, Object obj, C0190d<? super C0141q> dVar) {
            return cVar.emit(obj, dVar);
        }
    }
}
