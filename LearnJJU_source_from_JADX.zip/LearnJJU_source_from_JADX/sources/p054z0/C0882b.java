package p054z0;

import p017h0.C0190d;
import p017h0.C0195g;
import p017h0.C0201h;

/* renamed from: z0.b */
final class C0882b implements C0190d<Object> {

    /* renamed from: d */
    public static final C0882b f1665d = new C0882b();

    /* renamed from: e */
    private static final C0195g f1666e = C0201h.f297d;

    private C0882b() {
    }

    public C0195g getContext() {
        return f1666e;
    }

    public void resumeWith(Object obj) {
    }
}
