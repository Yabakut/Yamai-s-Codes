package p054z0;

import kotlin.jvm.internal.C0425e;
import p017h0.C0195g;
import p032o0.C0547p;

/* renamed from: z0.a */
public final class C0880a implements C0195g.C0198b {

    /* renamed from: f */
    public static final C0881a f1662f = new C0881a((C0425e) null);

    /* renamed from: d */
    public final Throwable f1663d;

    /* renamed from: e */
    private final C0195g.C0200c<?> f1664e = f1662f;

    /* renamed from: z0.a$a */
    public static final class C0881a implements C0195g.C0200c<C0880a> {
        private C0881a() {
        }

        public /* synthetic */ C0881a(C0425e eVar) {
            this();
        }
    }

    public C0880a(Throwable th) {
        this.f1663d = th;
    }

    public <R> R fold(R r, C0547p<? super R, ? super C0195g.C0198b, ? extends R> pVar) {
        return C0195g.C0198b.C0199a.m547a(this, r, pVar);
    }

    public <E extends C0195g.C0198b> E get(C0195g.C0200c<E> cVar) {
        return C0195g.C0198b.C0199a.m548b(this, cVar);
    }

    public C0195g.C0200c<?> getKey() {
        return this.f1664e;
    }

    public C0195g minusKey(C0195g.C0200c<?> cVar) {
        return C0195g.C0198b.C0199a.m549c(this, cVar);
    }

    public C0195g plus(C0195g gVar) {
        return C0195g.C0198b.C0199a.m550d(this, gVar);
    }
}
