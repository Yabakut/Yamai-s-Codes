package p018i;

import android.app.Activity;
import android.os.Build;
import android.os.Handler;
import p033p.C0555a;
import p035q.C0564a;
import p035q.C0566c;
import p051y.C0854i;
import p051y.C0855j;

/* renamed from: i.a */
public class C0202a implements C0555a, C0855j.C0859c, C0564a {

    /* renamed from: a */
    private C0855j f298a;

    /* renamed from: b */
    private Activity f299b;

    /* renamed from: c */
    final Handler f300c = new Handler();

    /* renamed from: i.a$a */
    class C0203a implements Runnable {
        C0203a() {
        }

        public void run() {
            System.exit(0);
        }
    }

    /* renamed from: i.a$b */
    class C0204b implements Runnable {
        C0204b() {
        }

        public void run() {
            System.exit(0);
        }
    }

    /* renamed from: a */
    public void mo672a(C0566c cVar) {
        this.f299b = cVar.mo966b();
    }

    /* renamed from: b */
    public void mo531b(C0854i iVar, C0855j.C0860d dVar) {
        Handler handler;
        Runnable bVar;
        if (iVar.f1634a.equals("getPlatformVersion")) {
            dVar.mo1199a("Android " + Build.VERSION.RELEASE);
        } else if (iVar.f1634a.equals("com.laoitdev.exit.app")) {
            int i = Build.VERSION.SDK_INT;
            if (i >= 16 && i < 21) {
                this.f299b.finishAffinity();
                handler = this.f300c;
                bVar = new C0203a();
            } else if (i >= 21) {
                this.f299b.finishAndRemoveTask();
                handler = this.f300c;
                bVar = new C0204b();
            } else {
                dVar.mo1200b("NO_EXIT", "", "");
                return;
            }
            handler.postDelayed(bVar, 1000);
            dVar.mo1199a("Done");
        } else {
            dVar.mo1201c();
        }
    }

    /* renamed from: c */
    public void mo673c() {
        this.f299b = null;
    }

    /* renamed from: d */
    public void mo429d(C0555a.C0557b bVar) {
        this.f298a.mo1847e((C0855j.C0859c) null);
    }

    /* renamed from: e */
    public void mo430e(C0555a.C0557b bVar) {
        C0855j jVar = new C0855j(bVar.mo1517b(), "flutter_exit_app");
        this.f298a = jVar;
        jVar.mo1847e(this);
    }

    /* renamed from: f */
    public void mo674f() {
        this.f299b = null;
    }

    /* renamed from: g */
    public void mo675g(C0566c cVar) {
        this.f299b = cVar.mo966b();
    }
}
