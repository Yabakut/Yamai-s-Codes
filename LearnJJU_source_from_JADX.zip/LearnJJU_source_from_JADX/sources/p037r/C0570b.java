package p037r;

/* renamed from: r.b */
public interface C0570b {
}
