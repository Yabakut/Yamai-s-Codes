package p037r;

/* renamed from: r.a */
public interface C0569a {
    /* renamed from: a */
    void mo1524a(C0570b bVar);

    /* renamed from: b */
    void mo1525b();
}
