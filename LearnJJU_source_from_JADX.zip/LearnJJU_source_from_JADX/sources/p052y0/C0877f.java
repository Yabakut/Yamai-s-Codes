package p052y0;

import p011e0.C0141q;
import p017h0.C0190d;
import p032o0.C0547p;

/* renamed from: y0.f */
final class C0877f<T> extends C0871a<T> {

    /* renamed from: a */
    private final C0547p<C0874c<? super T>, C0190d<? super C0141q>, Object> f1657a;

    public C0877f(C0547p<? super C0874c<? super T>, ? super C0190d<? super C0141q>, ? extends Object> pVar) {
        this.f1657a = pVar;
    }

    /* renamed from: b */
    public Object mo1859b(C0874c<? super T> cVar, C0190d<? super C0141q> dVar) {
        Object invoke = this.f1657a.invoke(cVar, dVar);
        return invoke == C0210d.m564c() ? invoke : C0141q.f277a;
    }
}
