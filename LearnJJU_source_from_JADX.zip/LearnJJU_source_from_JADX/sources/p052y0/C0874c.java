package p052y0;

import p011e0.C0141q;
import p017h0.C0190d;

/* renamed from: y0.c */
public interface C0874c<T> {
    Object emit(T t, C0190d<? super C0141q> dVar);
}
