package p052y0;

import kotlin.coroutines.jvm.internal.C0410d;
import kotlin.coroutines.jvm.internal.C0412f;
import p011e0.C0141q;
import p017h0.C0190d;

/* renamed from: y0.a */
public abstract class C0871a<T> implements C0873b<T> {

    @C0412f(mo1297c = "kotlinx.coroutines.flow.AbstractFlow", mo1298f = "Flow.kt", mo1299l = {212}, mo1300m = "collect")
    /* renamed from: y0.a$a */
    static final class C0872a extends C0410d {

        /* renamed from: d */
        Object f1653d;

        /* renamed from: e */
        /* synthetic */ Object f1654e;

        /* renamed from: f */
        final /* synthetic */ C0871a<T> f1655f;

        /* renamed from: g */
        int f1656g;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        C0872a(C0871a<T> aVar, C0190d<? super C0872a> dVar) {
            super(dVar);
            this.f1655f = aVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.f1654e = obj;
            this.f1656g |= Integer.MIN_VALUE;
            return this.f1655f.mo1858a((C0874c) null, this);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0037  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object mo1858a(p052y0.C0874c<? super T> r6, p017h0.C0190d<? super p011e0.C0141q> r7) {
        /*
            r5 = this;
            boolean r0 = r7 instanceof p052y0.C0871a.C0872a
            if (r0 == 0) goto L_0x0013
            r0 = r7
            y0.a$a r0 = (p052y0.C0871a.C0872a) r0
            int r1 = r0.f1656g
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f1656g = r1
            goto L_0x0018
        L_0x0013:
            y0.a$a r0 = new y0.a$a
            r0.<init>(r5, r7)
        L_0x0018:
            java.lang.Object r7 = r0.f1654e
            java.lang.Object r1 = p019i0.C0210d.m564c()
            int r2 = r0.f1656g
            r3 = 1
            if (r2 == 0) goto L_0x0037
            if (r2 != r3) goto L_0x002f
            java.lang.Object r6 = r0.f1653d
            z0.c r6 = (p054z0.C0883c) r6
            p011e0.C0136l.m422b(r7)     // Catch:{ all -> 0x002d }
            goto L_0x004f
        L_0x002d:
            r7 = move-exception
            goto L_0x0059
        L_0x002f:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L_0x0037:
            p011e0.C0136l.m422b(r7)
            z0.c r7 = new z0.c
            h0.g r2 = r0.getContext()
            r7.<init>(r6, r2)
            r0.f1653d = r7     // Catch:{ all -> 0x0055 }
            r0.f1656g = r3     // Catch:{ all -> 0x0055 }
            java.lang.Object r6 = r5.mo1859b(r7, r0)     // Catch:{ all -> 0x0055 }
            if (r6 != r1) goto L_0x004e
            return r1
        L_0x004e:
            r6 = r7
        L_0x004f:
            r6.releaseIntercepted()
            e0.q r6 = p011e0.C0141q.f277a
            return r6
        L_0x0055:
            r6 = move-exception
            r4 = r7
            r7 = r6
            r6 = r4
        L_0x0059:
            r6.releaseIntercepted()
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: p052y0.C0871a.mo1858a(y0.c, h0.d):java.lang.Object");
    }

    /* renamed from: b */
    public abstract Object mo1859b(C0874c<? super T> cVar, C0190d<? super C0141q> dVar);
}
