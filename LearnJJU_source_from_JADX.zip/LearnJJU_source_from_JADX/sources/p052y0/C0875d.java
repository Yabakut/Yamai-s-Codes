package p052y0;

import p011e0.C0141q;
import p017h0.C0190d;
import p032o0.C0547p;

/* renamed from: y0.d */
public final class C0875d {
    /* renamed from: a */
    public static final <T> C0873b<T> m2724a(C0547p<? super C0874c<? super T>, ? super C0190d<? super C0141q>, ? extends Object> pVar) {
        return C0876e.m2725a(pVar);
    }
}
