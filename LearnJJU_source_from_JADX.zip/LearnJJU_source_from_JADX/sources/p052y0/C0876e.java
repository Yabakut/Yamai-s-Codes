package p052y0;

import p011e0.C0141q;
import p017h0.C0190d;
import p032o0.C0547p;

/* renamed from: y0.e */
final /* synthetic */ class C0876e {
    /* renamed from: a */
    public static final <T> C0873b<T> m2725a(C0547p<? super C0874c<? super T>, ? super C0190d<? super C0141q>, ? extends Object> pVar) {
        return new C0877f(pVar);
    }
}
