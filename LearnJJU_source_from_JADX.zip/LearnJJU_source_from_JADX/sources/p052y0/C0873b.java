package p052y0;

import p011e0.C0141q;
import p017h0.C0190d;

/* renamed from: y0.b */
public interface C0873b<T> {
    /* renamed from: a */
    Object mo1858a(C0874c<? super T> cVar, C0190d<? super C0141q> dVar);
}
