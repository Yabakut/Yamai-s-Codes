package p011e0;

/* renamed from: e0.d */
public final class C0126d extends RuntimeException {
}
