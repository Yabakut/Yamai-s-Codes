package p011e0;

/* renamed from: e0.c */
public interface C0125c<R> {
}
