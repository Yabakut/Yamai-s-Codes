package p011e0;

/* renamed from: e0.a */
public final class C0123a extends C0124b {
}
