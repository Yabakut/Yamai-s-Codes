package p011e0;

import java.io.Serializable;
import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0429i;

/* renamed from: e0.k */
public final class C0133k<T> implements Serializable {

    /* renamed from: d */
    public static final C0134a f271d = new C0134a((C0425e) null);

    /* renamed from: e0.k$a */
    public static final class C0134a {
        private C0134a() {
        }

        public /* synthetic */ C0134a(C0425e eVar) {
            this();
        }
    }

    /* renamed from: e0.k$b */
    public static final class C0135b implements Serializable {

        /* renamed from: d */
        public final Throwable f272d;

        public C0135b(Throwable th) {
            C0429i.m1496d(th, "exception");
            this.f272d = th;
        }

        public boolean equals(Object obj) {
            return (obj instanceof C0135b) && C0429i.m1493a(this.f272d, ((C0135b) obj).f272d);
        }

        public int hashCode() {
            return this.f272d.hashCode();
        }

        public String toString() {
            return "Failure(" + this.f272d + ')';
        }
    }

    /* renamed from: a */
    public static <T> Object m417a(Object obj) {
        return obj;
    }

    /* renamed from: b */
    public static final Throwable m418b(Object obj) {
        if (obj instanceof C0135b) {
            return ((C0135b) obj).f272d;
        }
        return null;
    }

    /* renamed from: c */
    public static final boolean m419c(Object obj) {
        return obj instanceof C0135b;
    }

    /* renamed from: d */
    public static final boolean m420d(Object obj) {
        return !(obj instanceof C0135b);
    }
}
