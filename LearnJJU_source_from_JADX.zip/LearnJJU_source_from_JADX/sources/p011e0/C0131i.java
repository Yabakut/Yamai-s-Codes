package p011e0;

/* renamed from: e0.i */
public class C0131i extends RuntimeException {
}
