package p011e0;

import kotlin.jvm.internal.C0429i;
import p022j0.C0399b;

/* renamed from: e0.b */
class C0124b {
    /* renamed from: a */
    public static void m410a(Throwable th, Throwable th2) {
        C0429i.m1496d(th, "<this>");
        C0429i.m1496d(th2, "exception");
        if (th != th2) {
            C0399b.f952a.mo1281a(th, th2);
        }
    }
}
