package p011e0;

/* renamed from: e0.o */
public final class C0139o {

    /* renamed from: a */
    public static final C0139o f276a = new C0139o();

    private C0139o() {
    }
}
