package p011e0;

/* renamed from: e0.n */
public final class C0138n {
    /* renamed from: a */
    public static final <A, B> C0132j<A, B> m424a(A a, B b) {
        return new C0132j<>(a, b);
    }
}
