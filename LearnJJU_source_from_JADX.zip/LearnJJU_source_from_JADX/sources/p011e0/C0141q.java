package p011e0;

/* renamed from: e0.q */
public final class C0141q {

    /* renamed from: a */
    public static final C0141q f277a = new C0141q();

    private C0141q() {
    }

    public String toString() {
        return "kotlin.Unit";
    }
}
