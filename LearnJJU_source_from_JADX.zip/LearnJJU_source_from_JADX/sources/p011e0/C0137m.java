package p011e0;

import java.io.Serializable;
import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0429i;
import p032o0.C0532a;

/* renamed from: e0.m */
final class C0137m<T> implements C0127e<T>, Serializable {

    /* renamed from: d */
    private C0532a<? extends T> f273d;

    /* renamed from: e */
    private volatile Object f274e;

    /* renamed from: f */
    private final Object f275f;

    public C0137m(C0532a<? extends T> aVar, Object obj) {
        C0429i.m1496d(aVar, "initializer");
        this.f273d = aVar;
        this.f274e = C0139o.f276a;
        this.f275f = obj == null ? this : obj;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0137m(C0532a aVar, Object obj, int i, C0425e eVar) {
        this(aVar, (i & 2) != 0 ? null : obj);
    }

    /* renamed from: a */
    public boolean mo549a() {
        return this.f274e != C0139o.f276a;
    }

    public T getValue() {
        T t;
        T t2 = this.f274e;
        T t3 = C0139o.f276a;
        if (t2 != t3) {
            return t2;
        }
        synchronized (this.f275f) {
            t = this.f274e;
            if (t == t3) {
                C0532a aVar = this.f273d;
                C0429i.m1494b(aVar);
                t = aVar.invoke();
                this.f274e = t;
                this.f273d = null;
            }
        }
        return t;
    }

    public String toString() {
        return mo549a() ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }
}
