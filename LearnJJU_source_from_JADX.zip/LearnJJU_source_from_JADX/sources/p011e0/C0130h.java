package p011e0;

/* renamed from: e0.h */
class C0130h extends C0129g {
}
