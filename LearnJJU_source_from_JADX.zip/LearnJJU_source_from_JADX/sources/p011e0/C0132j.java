package p011e0;

import java.io.Serializable;
import kotlin.jvm.internal.C0429i;

/* renamed from: e0.j */
public final class C0132j<A, B> implements Serializable {

    /* renamed from: d */
    private final A f269d;

    /* renamed from: e */
    private final B f270e;

    public C0132j(A a, B b) {
        this.f269d = a;
        this.f270e = b;
    }

    /* renamed from: a */
    public final A mo539a() {
        return this.f269d;
    }

    /* renamed from: b */
    public final B mo540b() {
        return this.f270e;
    }

    /* renamed from: c */
    public final A mo541c() {
        return this.f269d;
    }

    /* renamed from: d */
    public final B mo542d() {
        return this.f270e;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0132j)) {
            return false;
        }
        C0132j jVar = (C0132j) obj;
        return C0429i.m1493a(this.f269d, jVar.f269d) && C0429i.m1493a(this.f270e, jVar.f270e);
    }

    public int hashCode() {
        A a = this.f269d;
        int i = 0;
        int hashCode = (a == null ? 0 : a.hashCode()) * 31;
        B b = this.f270e;
        if (b != null) {
            i = b.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        return '(' + this.f269d + ", " + this.f270e + ')';
    }
}
