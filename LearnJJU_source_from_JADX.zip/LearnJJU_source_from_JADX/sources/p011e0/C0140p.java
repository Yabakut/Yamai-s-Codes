package p011e0;

/* renamed from: e0.p */
public final class C0140p extends RuntimeException {
    public C0140p() {
    }

    public C0140p(String str) {
        super(str);
    }
}
