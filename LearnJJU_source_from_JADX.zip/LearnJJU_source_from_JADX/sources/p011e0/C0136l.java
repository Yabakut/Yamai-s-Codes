package p011e0;

import kotlin.jvm.internal.C0429i;
import p011e0.C0133k;

/* renamed from: e0.l */
public final class C0136l {
    /* renamed from: a */
    public static final Object m421a(Throwable th) {
        C0429i.m1496d(th, "exception");
        return new C0133k.C0135b(th);
    }

    /* renamed from: b */
    public static final void m422b(Object obj) {
        if (obj instanceof C0133k.C0135b) {
            throw ((C0133k.C0135b) obj).f272d;
        }
    }
}
