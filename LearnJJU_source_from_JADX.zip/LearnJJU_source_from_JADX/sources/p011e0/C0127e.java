package p011e0;

/* renamed from: e0.e */
public interface C0127e<T> {
    T getValue();
}
