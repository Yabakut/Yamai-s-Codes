package p011e0;

import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0429i;
import p032o0.C0532a;

/* renamed from: e0.g */
class C0129g {
    /* renamed from: a */
    public static <T> C0127e<T> m412a(C0532a<? extends T> aVar) {
        C0429i.m1496d(aVar, "initializer");
        return new C0137m(aVar, (Object) null, 2, (C0425e) null);
    }
}
