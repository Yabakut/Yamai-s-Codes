package p014g;

import android.os.Build;

/* renamed from: g.a */
public final class C0179a {
    /* renamed from: a */
    public static void m528a(String str) {
        if (Build.VERSION.SDK_INT >= 18) {
            C0180b.m530a(str);
        }
    }

    /* renamed from: b */
    public static void m529b() {
        if (Build.VERSION.SDK_INT >= 18) {
            C0180b.m531b();
        }
    }
}
