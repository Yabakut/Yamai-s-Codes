package p014g;

import android.os.Trace;

/* renamed from: g.b */
final class C0180b {
    /* renamed from: a */
    public static void m530a(String str) {
        Trace.beginSection(str);
    }

    /* renamed from: b */
    public static void m531b() {
        Trace.endSection();
    }
}
