package p041t;

import androidx.lifecycle.C0051d;
import p020io.flutter.embedding.engine.plugins.lifecycle.HiddenLifecycleReference;
import p035q.C0566c;

/* renamed from: t.a */
public class C0588a {
    /* renamed from: a */
    public static C0051d m1887a(C0566c cVar) {
        return ((HiddenLifecycleReference) cVar.mo965a()).getLifecycle();
    }
}
