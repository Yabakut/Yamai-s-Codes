package p004b;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

/* renamed from: b.b */
public class C0087b<K, V> implements Iterable<Map.Entry<K, V>> {

    /* renamed from: d */
    C0090c<K, V> f216d;

    /* renamed from: e */
    private C0090c<K, V> f217e;

    /* renamed from: f */
    private WeakHashMap<C0093f<K, V>, Boolean> f218f = new WeakHashMap<>();

    /* renamed from: g */
    private int f219g = 0;

    /* renamed from: b.b$a */
    static class C0088a<K, V> extends C0092e<K, V> {
        C0088a(C0090c<K, V> cVar, C0090c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public C0090c<K, V> mo414b(C0090c<K, V> cVar) {
            return cVar.f223g;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: c */
        public C0090c<K, V> mo415c(C0090c<K, V> cVar) {
            return cVar.f222f;
        }
    }

    /* renamed from: b.b$b */
    private static class C0089b<K, V> extends C0092e<K, V> {
        C0089b(C0090c<K, V> cVar, C0090c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public C0090c<K, V> mo414b(C0090c<K, V> cVar) {
            return cVar.f222f;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: c */
        public C0090c<K, V> mo415c(C0090c<K, V> cVar) {
            return cVar.f223g;
        }
    }

    /* renamed from: b.b$c */
    static class C0090c<K, V> implements Map.Entry<K, V> {

        /* renamed from: d */
        final K f220d;

        /* renamed from: e */
        final V f221e;

        /* renamed from: f */
        C0090c<K, V> f222f;

        /* renamed from: g */
        C0090c<K, V> f223g;

        C0090c(K k, V v) {
            this.f220d = k;
            this.f221e = v;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C0090c)) {
                return false;
            }
            C0090c cVar = (C0090c) obj;
            return this.f220d.equals(cVar.f220d) && this.f221e.equals(cVar.f221e);
        }

        public K getKey() {
            return this.f220d;
        }

        public V getValue() {
            return this.f221e;
        }

        public int hashCode() {
            return this.f220d.hashCode() ^ this.f221e.hashCode();
        }

        public V setValue(V v) {
            throw new UnsupportedOperationException("An entry modification is not supported");
        }

        public String toString() {
            return this.f220d + "=" + this.f221e;
        }
    }

    /* renamed from: b.b$d */
    private class C0091d implements Iterator<Map.Entry<K, V>>, C0093f<K, V> {

        /* renamed from: d */
        private C0090c<K, V> f224d;

        /* renamed from: e */
        private boolean f225e = true;

        C0091d() {
        }

        /* renamed from: a */
        public void mo422a(C0090c<K, V> cVar) {
            C0090c<K, V> cVar2 = this.f224d;
            if (cVar == cVar2) {
                C0090c<K, V> cVar3 = cVar2.f223g;
                this.f224d = cVar3;
                this.f225e = cVar3 == null;
            }
        }

        /* renamed from: b */
        public Map.Entry<K, V> next() {
            C0090c<K, V> cVar;
            if (this.f225e) {
                this.f225e = false;
                cVar = C0087b.this.f216d;
            } else {
                C0090c<K, V> cVar2 = this.f224d;
                cVar = cVar2 != null ? cVar2.f222f : null;
            }
            this.f224d = cVar;
            return this.f224d;
        }

        public boolean hasNext() {
            if (this.f225e) {
                return C0087b.this.f216d != null;
            }
            C0090c<K, V> cVar = this.f224d;
            return (cVar == null || cVar.f222f == null) ? false : true;
        }
    }

    /* renamed from: b.b$e */
    private static abstract class C0092e<K, V> implements Iterator<Map.Entry<K, V>>, C0093f<K, V> {

        /* renamed from: d */
        C0090c<K, V> f227d;

        /* renamed from: e */
        C0090c<K, V> f228e;

        C0092e(C0090c<K, V> cVar, C0090c<K, V> cVar2) {
            this.f227d = cVar2;
            this.f228e = cVar;
        }

        /* renamed from: e */
        private C0090c<K, V> m323e() {
            C0090c<K, V> cVar = this.f228e;
            C0090c<K, V> cVar2 = this.f227d;
            if (cVar == cVar2 || cVar2 == null) {
                return null;
            }
            return mo415c(cVar);
        }

        /* renamed from: a */
        public void mo422a(C0090c<K, V> cVar) {
            if (this.f227d == cVar && cVar == this.f228e) {
                this.f228e = null;
                this.f227d = null;
            }
            C0090c<K, V> cVar2 = this.f227d;
            if (cVar2 == cVar) {
                this.f227d = mo414b(cVar2);
            }
            if (this.f228e == cVar) {
                this.f228e = m323e();
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public abstract C0090c<K, V> mo414b(C0090c<K, V> cVar);

        /* access modifiers changed from: package-private */
        /* renamed from: c */
        public abstract C0090c<K, V> mo415c(C0090c<K, V> cVar);

        /* renamed from: d */
        public Map.Entry<K, V> next() {
            C0090c<K, V> cVar = this.f228e;
            this.f228e = m323e();
            return cVar;
        }

        public boolean hasNext() {
            return this.f228e != null;
        }
    }

    /* renamed from: b.b$f */
    interface C0093f<K, V> {
        /* renamed from: a */
        void mo422a(C0090c<K, V> cVar);
    }

    /* renamed from: a */
    public Iterator<Map.Entry<K, V>> mo404a() {
        C0089b bVar = new C0089b(this.f217e, this.f216d);
        this.f218f.put(bVar, Boolean.FALSE);
        return bVar;
    }

    /* renamed from: b */
    public Map.Entry<K, V> mo405b() {
        return this.f216d;
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public C0090c<K, V> mo399c(K k) {
        C0090c<K, V> cVar = this.f216d;
        while (cVar != null && !cVar.f220d.equals(k)) {
            cVar = cVar.f222f;
        }
        return cVar;
    }

    /* renamed from: d */
    public C0087b<K, V>.d mo406d() {
        C0087b<K, V>.d dVar = new C0091d();
        this.f218f.put(dVar, Boolean.FALSE);
        return dVar;
    }

    /* renamed from: e */
    public Map.Entry<K, V> mo407e() {
        return this.f217e;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0087b)) {
            return false;
        }
        C0087b bVar = (C0087b) obj;
        if (size() != bVar.size()) {
            return false;
        }
        Iterator it = iterator();
        Iterator it2 = bVar.iterator();
        while (it.hasNext() && it2.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            Object next = it2.next();
            if ((entry == null && next != null) || (entry != null && !entry.equals(next))) {
                return false;
            }
        }
        return !it.hasNext() && !it2.hasNext();
    }

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public C0090c<K, V> mo409f(K k, V v) {
        C0090c<K, V> cVar = new C0090c<>(k, v);
        this.f219g++;
        C0090c<K, V> cVar2 = this.f217e;
        if (cVar2 == null) {
            this.f216d = cVar;
        } else {
            cVar2.f222f = cVar;
            cVar.f223g = cVar2;
        }
        this.f217e = cVar;
        return cVar;
    }

    /* renamed from: g */
    public V mo401g(K k) {
        C0090c c = mo399c(k);
        if (c == null) {
            return null;
        }
        this.f219g--;
        if (!this.f218f.isEmpty()) {
            for (C0093f<K, V> a : this.f218f.keySet()) {
                a.mo422a(c);
            }
        }
        C0090c<K, V> cVar = c.f223g;
        C0090c<K, V> cVar2 = c.f222f;
        if (cVar != null) {
            cVar.f222f = cVar2;
        } else {
            this.f216d = cVar2;
        }
        C0090c<K, V> cVar3 = c.f222f;
        if (cVar3 != null) {
            cVar3.f223g = cVar;
        } else {
            this.f217e = cVar;
        }
        c.f222f = null;
        c.f223g = null;
        return c.f221e;
    }

    public int hashCode() {
        Iterator it = iterator();
        int i = 0;
        while (it.hasNext()) {
            i += ((Map.Entry) it.next()).hashCode();
        }
        return i;
    }

    public Iterator<Map.Entry<K, V>> iterator() {
        C0088a aVar = new C0088a(this.f216d, this.f217e);
        this.f218f.put(aVar, Boolean.FALSE);
        return aVar;
    }

    public int size() {
        return this.f219g;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Iterator it = iterator();
        while (it.hasNext()) {
            sb.append(((Map.Entry) it.next()).toString());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
