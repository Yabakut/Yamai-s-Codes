package p004b;

import java.util.HashMap;
import java.util.Map;
import p004b.C0087b;

/* renamed from: b.a */
public class C0086a<K, V> extends C0087b<K, V> {

    /* renamed from: h */
    private HashMap<K, C0087b.C0090c<K, V>> f215h = new HashMap<>();

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public C0087b.C0090c<K, V> mo399c(K k) {
        return this.f215h.get(k);
    }

    public boolean contains(K k) {
        return this.f215h.containsKey(k);
    }

    /* renamed from: g */
    public V mo401g(K k) {
        V g = super.mo401g(k);
        this.f215h.remove(k);
        return g;
    }

    /* renamed from: h */
    public Map.Entry<K, V> mo402h(K k) {
        if (contains(k)) {
            return this.f215h.get(k).f223g;
        }
        return null;
    }

    /* renamed from: i */
    public V mo403i(K k, V v) {
        C0087b.C0090c c = mo399c(k);
        if (c != null) {
            return c.f221e;
        }
        this.f215h.put(k, mo409f(k, v));
        return null;
    }
}
