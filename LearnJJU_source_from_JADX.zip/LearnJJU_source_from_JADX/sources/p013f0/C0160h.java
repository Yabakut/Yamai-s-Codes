package p013f0;

import java.util.Collections;
import java.util.List;
import kotlin.jvm.internal.C0429i;

/* renamed from: f0.h */
class C0160h {
    /* renamed from: a */
    public static final <T> List<T> m474a(T t) {
        List<T> singletonList = Collections.singletonList(t);
        C0429i.m1495c(singletonList, "singletonList(element)");
        return singletonList;
    }
}
