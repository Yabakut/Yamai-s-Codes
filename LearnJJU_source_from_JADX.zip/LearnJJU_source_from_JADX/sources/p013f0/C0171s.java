package p013f0;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import kotlin.jvm.internal.C0424d;
import kotlin.jvm.internal.C0429i;

/* renamed from: f0.s */
public final class C0171s implements List, Serializable, RandomAccess {

    /* renamed from: d */
    public static final C0171s f286d = new C0171s();

    private C0171s() {
    }

    /* renamed from: a */
    public void add(int i, Void voidR) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean addAll(int i, Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    /* renamed from: b */
    public boolean add(Void voidR) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    /* renamed from: c */
    public boolean mo581c(Void voidR) {
        C0429i.m1496d(voidR, "element");
        return false;
    }

    public void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* bridge */ boolean contains(Object obj) {
        if (!(obj instanceof Void)) {
            return false;
        }
        return mo581c((Void) obj);
    }

    public boolean containsAll(Collection collection) {
        C0429i.m1496d(collection, "elements");
        return collection.isEmpty();
    }

    /* renamed from: d */
    public Void get(int i) {
        throw new IndexOutOfBoundsException("Empty list doesn't contain element at index " + i + '.');
    }

    /* renamed from: e */
    public int mo586e() {
        return 0;
    }

    public boolean equals(Object obj) {
        return (obj instanceof List) && ((List) obj).isEmpty();
    }

    /* renamed from: f */
    public int mo588f(Void voidR) {
        C0429i.m1496d(voidR, "element");
        return -1;
    }

    /* renamed from: g */
    public int mo589g(Void voidR) {
        C0429i.m1496d(voidR, "element");
        return -1;
    }

    /* renamed from: h */
    public Void set(int i, Void voidR) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public int hashCode() {
        return 1;
    }

    public final /* bridge */ int indexOf(Object obj) {
        if (!(obj instanceof Void)) {
            return -1;
        }
        return mo588f((Void) obj);
    }

    public boolean isEmpty() {
        return true;
    }

    public Iterator iterator() {
        return C0170r.f285d;
    }

    public final /* bridge */ int lastIndexOf(Object obj) {
        if (!(obj instanceof Void)) {
            return -1;
        }
        return mo589g((Void) obj);
    }

    public ListIterator listIterator() {
        return C0170r.f285d;
    }

    public ListIterator listIterator(int i) {
        if (i == 0) {
            return C0170r.f285d;
        }
        throw new IndexOutOfBoundsException(C0429i.m1501i("Index: ", Integer.valueOf(i)));
    }

    public /* bridge */ /* synthetic */ Object remove(int i) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* bridge */ int size() {
        return mo586e();
    }

    public List subList(int i, int i2) {
        if (i == 0 && i2 == 0) {
            return this;
        }
        throw new IndexOutOfBoundsException("fromIndex: " + i + ", toIndex: " + i2);
    }

    public Object[] toArray() {
        return C0424d.m1491a(this);
    }

    public <T> T[] toArray(T[] tArr) {
        C0429i.m1496d(tArr, "array");
        return C0424d.m1492b(this, tArr);
    }

    public String toString() {
        return "[]";
    }
}
