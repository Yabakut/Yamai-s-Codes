package p013f0;

import java.util.List;
import kotlin.jvm.internal.C0429i;

/* renamed from: f0.i */
class C0161i extends C0160h {
    /* renamed from: b */
    public static <T> List<T> m475b() {
        return C0171s.f286d;
    }

    /* renamed from: c */
    public static <T> int m476c(List<? extends T> list) {
        C0429i.m1496d(list, "<this>");
        return list.size() - 1;
    }

    /* renamed from: d */
    public static <T> List<T> m477d(T... tArr) {
        C0429i.m1496d(tArr, "elements");
        return tArr.length > 0 ? C0154d.m448a(tArr) : m475b();
    }

    /* renamed from: e */
    public static <T> List<T> m478e(List<? extends T> list) {
        C0429i.m1496d(list, "<this>");
        int size = list.size();
        return size != 0 ? size != 1 ? list : C0160h.m474a(list.get(0)) : m475b();
    }

    /* renamed from: f */
    public static void m479f() {
        throw new ArithmeticException("Index overflow has happened.");
    }
}
