package p013f0;

import java.util.Collections;
import java.util.Set;
import kotlin.jvm.internal.C0429i;

/* renamed from: f0.c0 */
class C0153c0 {
    /* renamed from: a */
    public static final <T> Set<T> m447a(T t) {
        Set<T> singleton = Collections.singleton(t);
        C0429i.m1495c(singleton, "singleton(element)");
        return singleton;
    }
}
