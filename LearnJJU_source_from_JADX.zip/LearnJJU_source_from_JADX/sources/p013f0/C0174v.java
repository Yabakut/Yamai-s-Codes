package p013f0;

import java.util.Iterator;

/* renamed from: f0.v */
public abstract class C0174v implements Iterator<Integer> {
    /* renamed from: a */
    public abstract int mo651a();

    public /* bridge */ /* synthetic */ Object next() {
        return Integer.valueOf(mo651a());
    }

    public void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
