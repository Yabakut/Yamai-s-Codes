package p013f0;

/* renamed from: f0.b */
class C0150b {
}
