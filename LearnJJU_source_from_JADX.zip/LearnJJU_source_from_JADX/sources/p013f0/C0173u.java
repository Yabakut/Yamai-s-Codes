package p013f0;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import kotlin.jvm.internal.C0424d;
import kotlin.jvm.internal.C0429i;

/* renamed from: f0.u */
public final class C0173u implements Set, Serializable {

    /* renamed from: d */
    public static final C0173u f288d = new C0173u();

    private C0173u() {
    }

    /* renamed from: a */
    public boolean add(Void voidR) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    /* renamed from: b */
    public boolean mo635b(Void voidR) {
        C0429i.m1496d(voidR, "element");
        return false;
    }

    /* renamed from: c */
    public int mo636c() {
        return 0;
    }

    public void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* bridge */ boolean contains(Object obj) {
        if (!(obj instanceof Void)) {
            return false;
        }
        return mo635b((Void) obj);
    }

    public boolean containsAll(Collection collection) {
        C0429i.m1496d(collection, "elements");
        return collection.isEmpty();
    }

    public boolean equals(Object obj) {
        return (obj instanceof Set) && ((Set) obj).isEmpty();
    }

    public int hashCode() {
        return 0;
    }

    public boolean isEmpty() {
        return true;
    }

    public Iterator iterator() {
        return C0170r.f285d;
    }

    public boolean remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* bridge */ int size() {
        return mo636c();
    }

    public Object[] toArray() {
        return C0424d.m1491a(this);
    }

    public <T> T[] toArray(T[] tArr) {
        C0429i.m1496d(tArr, "array");
        return C0424d.m1492b(this, tArr);
    }

    public String toString() {
        return "[]";
    }
}
