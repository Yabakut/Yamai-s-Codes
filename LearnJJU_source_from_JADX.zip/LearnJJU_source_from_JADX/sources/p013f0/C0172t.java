package p013f0;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import kotlin.jvm.internal.C0429i;

/* renamed from: f0.t */
final class C0172t implements Map, Serializable {

    /* renamed from: d */
    public static final C0172t f287d = new C0172t();

    private C0172t() {
    }

    /* renamed from: a */
    public boolean mo609a(Void voidR) {
        C0429i.m1496d(voidR, "value");
        return false;
    }

    /* renamed from: b */
    public Void get(Object obj) {
        return null;
    }

    /* renamed from: c */
    public Set<Map.Entry> mo611c() {
        return C0173u.f288d;
    }

    public void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean containsKey(Object obj) {
        return false;
    }

    public final /* bridge */ boolean containsValue(Object obj) {
        if (!(obj instanceof Void)) {
            return false;
        }
        return mo609a((Void) obj);
    }

    /* renamed from: d */
    public Set<Object> mo615d() {
        return C0173u.f288d;
    }

    /* renamed from: e */
    public int mo616e() {
        return 0;
    }

    public final /* bridge */ Set<Map.Entry> entrySet() {
        return mo611c();
    }

    public boolean equals(Object obj) {
        return (obj instanceof Map) && ((Map) obj).isEmpty();
    }

    /* renamed from: f */
    public Collection mo619f() {
        return C0171s.f286d;
    }

    /* renamed from: g */
    public Void put(Object obj, Void voidR) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    /* renamed from: h */
    public Void remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public int hashCode() {
        return 0;
    }

    public boolean isEmpty() {
        return true;
    }

    public final /* bridge */ Set<Object> keySet() {
        return mo615d();
    }

    public void putAll(Map map) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* bridge */ int size() {
        return mo616e();
    }

    public String toString() {
        return "{}";
    }

    public final /* bridge */ Collection values() {
        return mo619f();
    }
}
