package p013f0;

/* renamed from: f0.c */
class C0152c extends C0150b {
}
