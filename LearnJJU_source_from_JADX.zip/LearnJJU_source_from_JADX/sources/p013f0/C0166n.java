package p013f0;

import java.util.Collection;
import kotlin.jvm.internal.C0429i;

/* renamed from: f0.n */
class C0166n extends C0165m {
    /* renamed from: h */
    public static <T> boolean m481h(Collection<? super T> collection, Iterable<? extends T> iterable) {
        C0429i.m1496d(collection, "<this>");
        C0429i.m1496d(iterable, "elements");
        if (iterable instanceof Collection) {
            return collection.addAll((Collection) iterable);
        }
        boolean z = false;
        for (Object add : iterable) {
            if (collection.add(add)) {
                z = true;
            }
        }
        return z;
    }
}
