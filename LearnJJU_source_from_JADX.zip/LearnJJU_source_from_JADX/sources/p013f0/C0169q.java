package p013f0;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import kotlin.jvm.internal.C0429i;
import p032o0.C0543l;

/* renamed from: f0.q */
class C0169q extends C0168p {
    /* renamed from: i */
    public static final <T, A extends Appendable> A m482i(Iterable<? extends T> iterable, A a, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i, CharSequence charSequence4, C0543l<? super T, ? extends CharSequence> lVar) {
        C0429i.m1496d(iterable, "<this>");
        C0429i.m1496d(a, "buffer");
        C0429i.m1496d(charSequence, "separator");
        C0429i.m1496d(charSequence2, "prefix");
        C0429i.m1496d(charSequence3, "postfix");
        C0429i.m1496d(charSequence4, "truncated");
        a.append(charSequence2);
        int i2 = 0;
        for (Object next : iterable) {
            i2++;
            if (i2 > 1) {
                a.append(charSequence);
            }
            if (i >= 0 && i2 > i) {
                break;
            }
            C0607e.m1928a(a, next, lVar);
        }
        if (i >= 0 && i2 > i) {
            a.append(charSequence4);
        }
        a.append(charSequence3);
        return a;
    }

    /* renamed from: j */
    public static /* synthetic */ Appendable m483j(Iterable iterable, Appendable appendable, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i, CharSequence charSequence4, C0543l lVar, int i2, Object obj) {
        String str = (i2 & 2) != 0 ? ", " : charSequence;
        CharSequence charSequence5 = "";
        CharSequence charSequence6 = (i2 & 4) != 0 ? charSequence5 : charSequence2;
        if ((i2 & 8) == 0) {
            charSequence5 = charSequence3;
        }
        return m482i(iterable, appendable, str, charSequence6, charSequence5, (i2 & 16) != 0 ? -1 : i, (i2 & 32) != 0 ? "..." : charSequence4, (i2 & 64) != 0 ? null : lVar);
    }

    /* renamed from: k */
    public static final <T> String m484k(Iterable<? extends T> iterable, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i, CharSequence charSequence4, C0543l<? super T, ? extends CharSequence> lVar) {
        C0429i.m1496d(iterable, "<this>");
        C0429i.m1496d(charSequence, "separator");
        C0429i.m1496d(charSequence2, "prefix");
        C0429i.m1496d(charSequence3, "postfix");
        C0429i.m1496d(charSequence4, "truncated");
        String sb = ((StringBuilder) m482i(iterable, new StringBuilder(), charSequence, charSequence2, charSequence3, i, charSequence4, lVar)).toString();
        C0429i.m1495c(sb, "joinTo(StringBuilder(), …ed, transform).toString()");
        return sb;
    }

    /* renamed from: l */
    public static /* synthetic */ String m485l(Iterable iterable, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i, CharSequence charSequence4, C0543l lVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            charSequence = ", ";
        }
        CharSequence charSequence5 = "";
        CharSequence charSequence6 = (i2 & 2) != 0 ? charSequence5 : charSequence2;
        if ((i2 & 4) == 0) {
            charSequence5 = charSequence3;
        }
        int i3 = (i2 & 8) != 0 ? -1 : i;
        if ((i2 & 16) != 0) {
            charSequence4 = "...";
        }
        CharSequence charSequence7 = charSequence4;
        if ((i2 & 32) != 0) {
            lVar = null;
        }
        return m484k(iterable, charSequence, charSequence6, charSequence5, i3, charSequence7, lVar);
    }

    /* renamed from: m */
    public static <T extends Comparable<? super T>> T m486m(Iterable<? extends T> iterable) {
        C0429i.m1496d(iterable, "<this>");
        Iterator<? extends T> it = iterable.iterator();
        if (!it.hasNext()) {
            return null;
        }
        T t = (Comparable) it.next();
        while (it.hasNext()) {
            T t2 = (Comparable) it.next();
            if (t.compareTo(t2) > 0) {
                t = t2;
            }
        }
        return t;
    }

    /* renamed from: n */
    public static <T> T m487n(Iterable<? extends T> iterable) {
        C0429i.m1496d(iterable, "<this>");
        if (iterable instanceof List) {
            return m488o((List) iterable);
        }
        Iterator<? extends T> it = iterable.iterator();
        if (it.hasNext()) {
            T next = it.next();
            if (!it.hasNext()) {
                return next;
            }
            throw new IllegalArgumentException("Collection has more than one element.");
        }
        throw new NoSuchElementException("Collection is empty.");
    }

    /* renamed from: o */
    public static final <T> T m488o(List<? extends T> list) {
        C0429i.m1496d(list, "<this>");
        int size = list.size();
        if (size == 0) {
            throw new NoSuchElementException("List is empty.");
        } else if (size == 1) {
            return list.get(0);
        } else {
            throw new IllegalArgumentException("List has more than one element.");
        }
    }

    /* renamed from: p */
    public static final <T, C extends Collection<? super T>> C m489p(Iterable<? extends T> iterable, C c) {
        C0429i.m1496d(iterable, "<this>");
        C0429i.m1496d(c, "destination");
        for (Object add : iterable) {
            c.add(add);
        }
        return c;
    }

    /* renamed from: q */
    public static <T> List<T> m490q(Iterable<? extends T> iterable) {
        C0429i.m1496d(iterable, "<this>");
        if (!(iterable instanceof Collection)) {
            return C0161i.m478e(m491r(iterable));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return C0161i.m475b();
        }
        if (size != 1) {
            return m492s(collection);
        }
        return C0160h.m474a(iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next());
    }

    /* renamed from: r */
    public static final <T> List<T> m491r(Iterable<? extends T> iterable) {
        C0429i.m1496d(iterable, "<this>");
        return iterable instanceof Collection ? m492s((Collection) iterable) : (List) m489p(iterable, new ArrayList());
    }

    /* renamed from: s */
    public static final <T> List<T> m492s(Collection<? extends T> collection) {
        C0429i.m1496d(collection, "<this>");
        return new ArrayList(collection);
    }

    /* renamed from: t */
    public static <T> Set<T> m493t(Iterable<? extends T> iterable) {
        C0429i.m1496d(iterable, "<this>");
        if (!(iterable instanceof Collection)) {
            return C0155d0.m455c((Set) m489p(iterable, new LinkedHashSet()));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return C0155d0.m454b();
        }
        if (size != 1) {
            return (Set) m489p(iterable, new LinkedHashSet(C0177y.m520a(collection.size())));
        }
        return C0153c0.m447a(iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next());
    }
}
