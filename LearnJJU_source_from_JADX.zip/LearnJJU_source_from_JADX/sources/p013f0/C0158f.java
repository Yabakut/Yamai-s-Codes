package p013f0;

import java.util.Arrays;
import java.util.List;

/* renamed from: f0.f */
class C0158f {
    /* renamed from: a */
    static <T> List<T> m460a(T[] tArr) {
        return Arrays.asList(tArr);
    }
}
