package p013f0;

import java.util.ListIterator;
import java.util.NoSuchElementException;

/* renamed from: f0.r */
public final class C0170r implements ListIterator {

    /* renamed from: d */
    public static final C0170r f285d = new C0170r();

    private C0170r() {
    }

    /* renamed from: a */
    public void add(Void voidR) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    /* renamed from: b */
    public Void next() {
        throw new NoSuchElementException();
    }

    /* renamed from: c */
    public Void previous() {
        throw new NoSuchElementException();
    }

    /* renamed from: d */
    public void set(Void voidR) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean hasNext() {
        return false;
    }

    public boolean hasPrevious() {
        return false;
    }

    public int nextIndex() {
        return 0;
    }

    public int previousIndex() {
        return -1;
    }

    public void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
