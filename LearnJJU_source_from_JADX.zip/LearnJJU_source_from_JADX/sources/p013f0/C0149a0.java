package p013f0;

/* renamed from: f0.a0 */
class C0149a0 extends C0178z {
}
