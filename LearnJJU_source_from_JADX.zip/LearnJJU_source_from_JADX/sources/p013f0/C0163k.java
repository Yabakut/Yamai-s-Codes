package p013f0;

/* renamed from: f0.k */
class C0163k extends C0162j {
}
