package p013f0;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.C0429i;

/* renamed from: f0.e */
class C0156e extends C0154d {
    /* renamed from: g */
    public static char m456g(char[] cArr) {
        C0429i.m1496d(cArr, "<this>");
        int length = cArr.length;
        if (length == 0) {
            throw new NoSuchElementException("Array is empty.");
        } else if (length == 1) {
            return cArr[0];
        } else {
            throw new IllegalArgumentException("Array has more than one element.");
        }
    }

    /* renamed from: h */
    public static <T> T m457h(T[] tArr) {
        C0429i.m1496d(tArr, "<this>");
        if (tArr.length == 1) {
            return tArr[0];
        }
        return null;
    }

    /* renamed from: i */
    public static final <T> T[] m458i(T[] tArr, Comparator<? super T> comparator) {
        C0429i.m1496d(tArr, "<this>");
        C0429i.m1496d(comparator, "comparator");
        if (tArr.length == 0) {
            return tArr;
        }
        T[] copyOf = Arrays.copyOf(tArr, tArr.length);
        C0429i.m1495c(copyOf, "copyOf(this, size)");
        C0154d.m453f(copyOf, comparator);
        return copyOf;
    }

    /* renamed from: j */
    public static <T> List<T> m459j(T[] tArr, Comparator<? super T> comparator) {
        C0429i.m1496d(tArr, "<this>");
        C0429i.m1496d(comparator, "comparator");
        return C0154d.m448a(m458i(tArr, comparator));
    }
}
