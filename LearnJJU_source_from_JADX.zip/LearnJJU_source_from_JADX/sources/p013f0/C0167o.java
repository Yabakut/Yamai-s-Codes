package p013f0;

/* renamed from: f0.o */
class C0167o extends C0166n {
}
