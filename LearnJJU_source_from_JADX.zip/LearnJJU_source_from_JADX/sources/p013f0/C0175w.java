package p013f0;

/* renamed from: f0.w */
public final class C0175w extends C0149a0 {
}
