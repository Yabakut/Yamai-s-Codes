package p013f0;

import java.util.Collection;
import kotlin.jvm.internal.C0429i;

/* renamed from: f0.j */
class C0162j extends C0161i {
    /* renamed from: g */
    public static <T> int m480g(Iterable<? extends T> iterable, int i) {
        C0429i.m1496d(iterable, "<this>");
        return iterable instanceof Collection ? ((Collection) iterable).size() : i;
    }
}
