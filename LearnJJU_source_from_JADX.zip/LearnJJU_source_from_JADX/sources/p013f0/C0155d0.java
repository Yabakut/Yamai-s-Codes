package p013f0;

import java.util.Set;
import kotlin.jvm.internal.C0429i;

/* renamed from: f0.d0 */
class C0155d0 extends C0153c0 {
    /* renamed from: b */
    public static <T> Set<T> m454b() {
        return C0173u.f288d;
    }

    /* renamed from: c */
    public static final <T> Set<T> m455c(Set<? extends T> set) {
        C0429i.m1496d(set, "<this>");
        int size = set.size();
        return size != 0 ? size != 1 ? set : C0153c0.m447a(set.iterator().next()) : m454b();
    }
}
