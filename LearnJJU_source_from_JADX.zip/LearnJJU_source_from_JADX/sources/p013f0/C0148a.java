package p013f0;

/* renamed from: f0.a */
public final class C0148a extends C0156e {
}
