package p013f0;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.C0429i;
import p011e0.C0132j;

/* renamed from: f0.z */
class C0178z extends C0177y {
    /* renamed from: d */
    public static final <K, V> Map<K, V> m523d() {
        return C0172t.f287d;
    }

    /* renamed from: e */
    public static final <K, V> Map<K, V> m524e(Map<K, ? extends V> map) {
        C0429i.m1496d(map, "<this>");
        int size = map.size();
        return size != 0 ? size != 1 ? map : C0177y.m522c(map) : m523d();
    }

    /* renamed from: f */
    public static final <K, V> void m525f(Map<? super K, ? super V> map, Iterable<? extends C0132j<? extends K, ? extends V>> iterable) {
        C0429i.m1496d(map, "<this>");
        C0429i.m1496d(iterable, "pairs");
        for (C0132j jVar : iterable) {
            map.put(jVar.mo539a(), jVar.mo540b());
        }
    }

    /* renamed from: g */
    public static <K, V> Map<K, V> m526g(Iterable<? extends C0132j<? extends K, ? extends V>> iterable) {
        C0429i.m1496d(iterable, "<this>");
        if (!(iterable instanceof Collection)) {
            return m524e(m527h(iterable, new LinkedHashMap()));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return m523d();
        }
        if (size != 1) {
            return m527h(iterable, new LinkedHashMap(C0177y.m520a(collection.size())));
        }
        return C0177y.m521b((C0132j) (iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next()));
    }

    /* renamed from: h */
    public static final <K, V, M extends Map<? super K, ? super V>> M m527h(Iterable<? extends C0132j<? extends K, ? extends V>> iterable, M m) {
        C0429i.m1496d(iterable, "<this>");
        C0429i.m1496d(m, "destination");
        m525f(m, iterable);
        return m;
    }
}
