package p013f0;

/* renamed from: f0.e0 */
class C0157e0 extends C0155d0 {
}
