package p013f0;

import java.util.Collections;
import java.util.Map;
import kotlin.jvm.internal.C0429i;
import p011e0.C0132j;

/* renamed from: f0.y */
class C0177y extends C0176x {
    /* renamed from: a */
    public static int m520a(int i) {
        if (i < 0) {
            return i;
        }
        if (i < 3) {
            return i + 1;
        }
        if (i < 1073741824) {
            return (int) ((((float) i) / 0.75f) + 1.0f);
        }
        return Integer.MAX_VALUE;
    }

    /* renamed from: b */
    public static final <K, V> Map<K, V> m521b(C0132j<? extends K, ? extends V> jVar) {
        C0429i.m1496d(jVar, "pair");
        Map<K, V> singletonMap = Collections.singletonMap(jVar.mo541c(), jVar.mo542d());
        C0429i.m1495c(singletonMap, "singletonMap(pair.first, pair.second)");
        return singletonMap;
    }

    /* renamed from: c */
    public static final <K, V> Map<K, V> m522c(Map<? extends K, ? extends V> map) {
        C0429i.m1496d(map, "<this>");
        Map.Entry next = map.entrySet().iterator().next();
        Map<K, V> singletonMap = Collections.singletonMap(next.getKey(), next.getValue());
        C0429i.m1495c(singletonMap, "with(entries.iterator().…ingletonMap(key, value) }");
        return singletonMap;
    }
}
