package p013f0;

/* renamed from: f0.b0 */
public final class C0151b0 extends C0157e0 {
}
