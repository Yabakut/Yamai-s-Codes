package p044u0;

import kotlin.jvm.internal.C0429i;

/* renamed from: u0.p */
class C0622p extends C0621o {
    /* renamed from: b0 */
    public static final String m1985b0(String str, int i) {
        C0429i.m1496d(str, "<this>");
        if (i >= 0) {
            String substring = str.substring(C0578f.m1878c(i, str.length()));
            C0429i.m1495c(substring, "this as java.lang.String).substring(startIndex)");
            return substring;
        }
        throw new IllegalArgumentException(("Requested character count " + i + " is less than zero.").toString());
    }
}
