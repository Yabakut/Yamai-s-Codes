package p044u0;

/* renamed from: u0.o */
class C0621o extends C0618n {
}
