package p044u0;

import p038r0.C0574c;

/* renamed from: u0.a */
class C0602a {
    /* renamed from: a */
    public static final int m1901a(int i) {
        boolean z = false;
        if (2 <= i && i < 37) {
            z = true;
        }
        if (z) {
            return i;
        }
        throw new IllegalArgumentException("radix " + i + " was not in valid range " + new C0574c(2, 36));
    }

    /* renamed from: b */
    public static final int m1902b(char c, int i) {
        return Character.digit(c, i);
    }

    /* renamed from: c */
    public static final boolean m1903c(char c) {
        return Character.isWhitespace(c) || Character.isSpaceChar(c);
    }
}
