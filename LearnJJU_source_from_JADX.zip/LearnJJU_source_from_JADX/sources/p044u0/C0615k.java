package p044u0;

/* renamed from: u0.k */
class C0615k extends C0614j {
}
