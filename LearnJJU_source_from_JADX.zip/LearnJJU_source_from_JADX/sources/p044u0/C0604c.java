package p044u0;

import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.C0429i;
import p011e0.C0132j;
import p032o0.C0547p;
import p038r0.C0574c;
import p042t0.C0590b;

/* renamed from: u0.c */
final class C0604c implements C0590b<C0574c> {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public final CharSequence f1219a;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public final int f1220b;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public final int f1221c;
    /* access modifiers changed from: private */

    /* renamed from: d */
    public final C0547p<CharSequence, Integer, C0132j<Integer, Integer>> f1222d;

    /* renamed from: u0.c$a */
    public static final class C0605a implements Iterator<C0574c> {

        /* renamed from: d */
        private int f1223d = -1;

        /* renamed from: e */
        private int f1224e;

        /* renamed from: f */
        private int f1225f;

        /* renamed from: g */
        private C0574c f1226g;

        /* renamed from: h */
        private int f1227h;

        /* renamed from: i */
        final /* synthetic */ C0604c f1228i;

        C0605a(C0604c cVar) {
            this.f1228i = cVar;
            int e = C0578f.m1880e(cVar.f1220b, 0, cVar.f1219a.length());
            this.f1224e = e;
            this.f1225f = e;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:6:0x0021, code lost:
            if (r0 < p044u0.C0604c.m1907c(r6.f1228i)) goto L_0x0023;
         */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private final void m1909a() {
            /*
                r6 = this;
                int r0 = r6.f1225f
                r1 = 0
                if (r0 >= 0) goto L_0x000c
                r6.f1223d = r1
                r0 = 0
                r6.f1226g = r0
                goto L_0x0099
            L_0x000c:
                u0.c r0 = r6.f1228i
                int r0 = r0.f1221c
                r2 = -1
                r3 = 1
                if (r0 <= 0) goto L_0x0023
                int r0 = r6.f1227h
                int r0 = r0 + r3
                r6.f1227h = r0
                u0.c r4 = r6.f1228i
                int r4 = r4.f1221c
                if (r0 >= r4) goto L_0x0031
            L_0x0023:
                int r0 = r6.f1225f
                u0.c r4 = r6.f1228i
                java.lang.CharSequence r4 = r4.f1219a
                int r4 = r4.length()
                if (r0 <= r4) goto L_0x0047
            L_0x0031:
                r0.c r0 = new r0.c
                int r1 = r6.f1224e
                u0.c r4 = r6.f1228i
                java.lang.CharSequence r4 = r4.f1219a
                int r4 = p044u0.C0618n.m1977u(r4)
                r0.<init>(r1, r4)
            L_0x0042:
                r6.f1226g = r0
            L_0x0044:
                r6.f1225f = r2
                goto L_0x0097
            L_0x0047:
                u0.c r0 = r6.f1228i
                o0.p r0 = r0.f1222d
                u0.c r4 = r6.f1228i
                java.lang.CharSequence r4 = r4.f1219a
                int r5 = r6.f1225f
                java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
                java.lang.Object r0 = r0.invoke(r4, r5)
                e0.j r0 = (p011e0.C0132j) r0
                if (r0 != 0) goto L_0x0073
                r0.c r0 = new r0.c
                int r1 = r6.f1224e
                u0.c r4 = r6.f1228i
                java.lang.CharSequence r4 = r4.f1219a
                int r4 = p044u0.C0618n.m1977u(r4)
                r0.<init>(r1, r4)
                goto L_0x0042
            L_0x0073:
                java.lang.Object r2 = r0.mo539a()
                java.lang.Number r2 = (java.lang.Number) r2
                int r2 = r2.intValue()
                java.lang.Object r0 = r0.mo540b()
                java.lang.Number r0 = (java.lang.Number) r0
                int r0 = r0.intValue()
                int r4 = r6.f1224e
                r0.c r4 = p038r0.C0578f.m1882g(r4, r2)
                r6.f1226g = r4
                int r2 = r2 + r0
                r6.f1224e = r2
                if (r0 != 0) goto L_0x0095
                r1 = 1
            L_0x0095:
                int r2 = r2 + r1
                goto L_0x0044
            L_0x0097:
                r6.f1223d = r3
            L_0x0099:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: p044u0.C0604c.C0605a.m1909a():void");
        }

        /* renamed from: b */
        public C0574c next() {
            if (this.f1223d == -1) {
                m1909a();
            }
            if (this.f1223d != 0) {
                C0574c cVar = this.f1226g;
                if (cVar != null) {
                    this.f1226g = null;
                    this.f1223d = -1;
                    return cVar;
                }
                throw new NullPointerException("null cannot be cast to non-null type kotlin.ranges.IntRange");
            }
            throw new NoSuchElementException();
        }

        public boolean hasNext() {
            if (this.f1223d == -1) {
                m1909a();
            }
            return this.f1223d == 1;
        }

        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public C0604c(CharSequence charSequence, int i, int i2, C0547p<? super CharSequence, ? super Integer, C0132j<Integer, Integer>> pVar) {
        C0429i.m1496d(charSequence, "input");
        C0429i.m1496d(pVar, "getNextMatch");
        this.f1219a = charSequence;
        this.f1220b = i;
        this.f1221c = i2;
        this.f1222d = pVar;
    }

    public Iterator<C0574c> iterator() {
        return new C0605a(this);
    }
}
