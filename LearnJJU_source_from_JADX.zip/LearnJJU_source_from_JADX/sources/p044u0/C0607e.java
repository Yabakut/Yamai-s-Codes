package p044u0;

/* renamed from: u0.e */
class C0607e {
    /* JADX WARNING: type inference failed for: r3v0, types: [o0.l<? super T, ? extends java.lang.CharSequence>, o0.l] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static <T> void m1928a(java.lang.Appendable r1, T r2, p032o0.C0543l<? super T, ? extends java.lang.CharSequence> r3) {
        /*
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.C0429i.m1496d(r1, r0)
            if (r3 == 0) goto L_0x0011
            java.lang.Object r2 = r3.invoke(r2)
        L_0x000b:
            java.lang.CharSequence r2 = (java.lang.CharSequence) r2
        L_0x000d:
            r1.append(r2)
            goto L_0x002d
        L_0x0011:
            if (r2 != 0) goto L_0x0015
            r3 = 1
            goto L_0x0017
        L_0x0015:
            boolean r3 = r2 instanceof java.lang.CharSequence
        L_0x0017:
            if (r3 == 0) goto L_0x001a
            goto L_0x000b
        L_0x001a:
            boolean r3 = r2 instanceof java.lang.Character
            if (r3 == 0) goto L_0x0028
            java.lang.Character r2 = (java.lang.Character) r2
            char r2 = r2.charValue()
            r1.append(r2)
            goto L_0x002d
        L_0x0028:
            java.lang.String r2 = java.lang.String.valueOf(r2)
            goto L_0x000d
        L_0x002d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p044u0.C0607e.m1928a(java.lang.Appendable, java.lang.Object, o0.l):void");
    }
}
