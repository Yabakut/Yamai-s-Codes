package p044u0;

/* renamed from: u0.j */
class C0614j extends C0613i {
}
