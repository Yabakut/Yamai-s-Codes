package p044u0;

/* renamed from: u0.h */
class C0612h extends C0611g {
}
