package p044u0;

/* renamed from: u0.i */
class C0613i extends C0612h {
}
