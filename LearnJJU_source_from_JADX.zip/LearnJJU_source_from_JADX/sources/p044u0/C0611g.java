package p044u0;

/* renamed from: u0.g */
class C0611g extends C0608f {
}
