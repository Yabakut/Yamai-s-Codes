package p044u0;

import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.C0429i;
import kotlin.jvm.internal.C0430j;
import p032o0.C0543l;

/* renamed from: u0.f */
class C0608f extends C0607e {

    /* renamed from: u0.f$a */
    static final class C0609a extends C0430j implements C0543l<String, String> {

        /* renamed from: d */
        public static final C0609a f1229d = new C0609a();

        C0609a() {
            super(1);
        }

        /* renamed from: a */
        public final String invoke(String str) {
            C0429i.m1496d(str, "line");
            return str;
        }
    }

    /* renamed from: u0.f$b */
    static final class C0610b extends C0430j implements C0543l<String, String> {

        /* renamed from: d */
        final /* synthetic */ String f1230d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        C0610b(String str) {
            super(1);
            this.f1230d = str;
        }

        /* renamed from: a */
        public final String invoke(String str) {
            C0429i.m1496d(str, "line");
            return C0429i.m1501i(this.f1230d, str);
        }
    }

    /* renamed from: b */
    private static final C0543l<String, String> m1929b(String str) {
        return str.length() == 0 ? C0609a.f1229d : new C0610b(str);
    }

    /* renamed from: c */
    private static final int m1930c(String str) {
        int length = str.length();
        int i = 0;
        while (true) {
            if (i >= length) {
                i = -1;
                break;
            }
            int i2 = i + 1;
            if (!C0602a.m1903c(str.charAt(i))) {
                break;
            }
            i = i2;
        }
        return i == -1 ? str.length() : i;
    }

    /* renamed from: d */
    public static final String m1931d(String str, String str2) {
        C0429i.m1496d(str, "<this>");
        C0429i.m1496d(str2, "newIndent");
        List<String> I = C0618n.m1953I(str);
        ArrayList<String> arrayList = new ArrayList<>();
        for (T next : I) {
            if (!C0617m.m1941l((String) next)) {
                arrayList.add(next);
            }
        }
        ArrayList arrayList2 = new ArrayList(C0162j.m480g(arrayList, 10));
        for (String c : arrayList) {
            arrayList2.add(Integer.valueOf(m1930c(c)));
        }
        Integer num = (Integer) C0169q.m486m(arrayList2);
        int i = 0;
        int intValue = num == null ? 0 : num.intValue();
        int length = str.length() + (str2.length() * I.size());
        C0543l<String, String> b = m1929b(str2);
        int c2 = C0161i.m476c(I);
        ArrayList arrayList3 = new ArrayList();
        for (T next2 : I) {
            int i2 = i + 1;
            if (i < 0) {
                C0161i.m479f();
            }
            String str3 = (String) next2;
            if ((i == 0 || i == c2) && C0617m.m1941l(str3)) {
                str3 = null;
            } else {
                String b0 = C0622p.m1985b0(str3, intValue);
                if (b0 != null) {
                    str3 = b.invoke(b0);
                }
            }
            if (str3 != null) {
                arrayList3.add(str3);
            }
            i = i2;
        }
        String sb = ((StringBuilder) C0169q.m483j(arrayList3, new StringBuilder(length), "\n", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (C0543l) null, 124, (Object) null)).toString();
        C0429i.m1495c(sb, "mapIndexedNotNull { inde…\"\\n\")\n        .toString()");
        return sb;
    }

    /* renamed from: e */
    public static String m1932e(String str) {
        C0429i.m1496d(str, "<this>");
        return m1931d(str, "");
    }
}
