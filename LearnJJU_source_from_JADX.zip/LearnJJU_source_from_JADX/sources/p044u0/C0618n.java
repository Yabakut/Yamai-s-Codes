package p044u0;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.C0429i;
import kotlin.jvm.internal.C0430j;
import p011e0.C0132j;
import p011e0.C0138n;
import p032o0.C0543l;
import p032o0.C0547p;
import p038r0.C0571a;
import p038r0.C0574c;
import p042t0.C0590b;

/* renamed from: u0.n */
class C0618n extends C0617m {

    /* renamed from: u0.n$a */
    static final class C0619a extends C0430j implements C0547p<CharSequence, Integer, C0132j<? extends Integer, ? extends Integer>> {

        /* renamed from: d */
        final /* synthetic */ List<String> f1231d;

        /* renamed from: e */
        final /* synthetic */ boolean f1232e;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        C0619a(List<String> list, boolean z) {
            super(2);
            this.f1231d = list;
            this.f1232e = z;
        }

        /* renamed from: a */
        public final C0132j<Integer, Integer> mo1554a(CharSequence charSequence, int i) {
            C0429i.m1496d(charSequence, "$this$$receiver");
            C0132j p = C0618n.m1975s(charSequence, this.f1231d, i, this.f1232e, false);
            if (p == null) {
                return null;
            }
            return C0138n.m424a(p.mo541c(), Integer.valueOf(((String) p.mo542d()).length()));
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return mo1554a((CharSequence) obj, ((Number) obj2).intValue());
        }
    }

    /* renamed from: u0.n$b */
    static final class C0620b extends C0430j implements C0543l<C0574c, String> {

        /* renamed from: d */
        final /* synthetic */ CharSequence f1233d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        C0620b(CharSequence charSequence) {
            super(1);
            this.f1233d = charSequence;
        }

        /* renamed from: a */
        public final String invoke(C0574c cVar) {
            C0429i.m1496d(cVar, "it");
            return C0618n.m1960P(this.f1233d, cVar);
        }
    }

    /* renamed from: A */
    public static /* synthetic */ int m1945A(CharSequence charSequence, String str, int i, boolean z, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = 0;
        }
        if ((i2 & 4) != 0) {
            z = false;
        }
        return m1979w(charSequence, str, i, z);
    }

    /* renamed from: B */
    public static final int m1946B(CharSequence charSequence, char[] cArr, int i, boolean z) {
        boolean z2;
        C0429i.m1496d(charSequence, "<this>");
        C0429i.m1496d(cArr, "chars");
        if (z || cArr.length != 1 || !(charSequence instanceof String)) {
            int a = C0578f.m1876a(i, 0);
            int u = m1977u(charSequence);
            if (a > u) {
                return -1;
            }
            while (true) {
                int i2 = a + 1;
                char charAt = charSequence.charAt(a);
                int length = cArr.length;
                int i3 = 0;
                while (true) {
                    if (i3 >= length) {
                        z2 = false;
                        break;
                    }
                    char c = cArr[i3];
                    i3++;
                    if (C0603b.m1904d(c, charAt, z)) {
                        z2 = true;
                        break;
                    }
                }
                if (z2) {
                    return a;
                }
                if (a == u) {
                    return -1;
                }
                a = i2;
            }
        } else {
            return ((String) charSequence).indexOf(C0156e.m456g(cArr), i);
        }
    }

    /* renamed from: C */
    public static final int m1947C(CharSequence charSequence, char c, int i, boolean z) {
        C0429i.m1496d(charSequence, "<this>");
        if (!z && (charSequence instanceof String)) {
            return ((String) charSequence).lastIndexOf(c, i);
        }
        return m1951G(charSequence, new char[]{c}, i, z);
    }

    /* renamed from: D */
    public static final int m1948D(CharSequence charSequence, String str, int i, boolean z) {
        C0429i.m1496d(charSequence, "<this>");
        C0429i.m1496d(str, "string");
        return (z || !(charSequence instanceof String)) ? m1980x(charSequence, str, i, 0, z, true) : ((String) charSequence).lastIndexOf(str, i);
    }

    /* renamed from: E */
    public static /* synthetic */ int m1949E(CharSequence charSequence, char c, int i, boolean z, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = m1977u(charSequence);
        }
        if ((i2 & 4) != 0) {
            z = false;
        }
        return m1947C(charSequence, c, i, z);
    }

    /* renamed from: F */
    public static /* synthetic */ int m1950F(CharSequence charSequence, String str, int i, boolean z, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = m1977u(charSequence);
        }
        if ((i2 & 4) != 0) {
            z = false;
        }
        return m1948D(charSequence, str, i, z);
    }

    /* renamed from: G */
    public static final int m1951G(CharSequence charSequence, char[] cArr, int i, boolean z) {
        C0429i.m1496d(charSequence, "<this>");
        C0429i.m1496d(cArr, "chars");
        if (z || cArr.length != 1 || !(charSequence instanceof String)) {
            int c = C0578f.m1878c(i, m1977u(charSequence));
            if (c < 0) {
                return -1;
            }
            while (true) {
                int i2 = c - 1;
                char charAt = charSequence.charAt(c);
                int length = cArr.length;
                boolean z2 = false;
                int i3 = 0;
                while (true) {
                    if (i3 >= length) {
                        break;
                    }
                    char c2 = cArr[i3];
                    i3++;
                    if (C0603b.m1904d(c2, charAt, z)) {
                        z2 = true;
                        break;
                    }
                }
                if (z2) {
                    return c;
                }
                if (i2 < 0) {
                    return -1;
                }
                c = i2;
            }
        } else {
            return ((String) charSequence).lastIndexOf(C0156e.m456g(cArr), i);
        }
    }

    /* renamed from: H */
    public static final C0590b<String> m1952H(CharSequence charSequence) {
        C0429i.m1496d(charSequence, "<this>");
        return m1959O(charSequence, new String[]{"\r\n", "\n", "\r"}, false, 0, 6, (Object) null);
    }

    /* renamed from: I */
    public static final List<String> m1953I(CharSequence charSequence) {
        C0429i.m1496d(charSequence, "<this>");
        return C0597h.m1895e(m1952H(charSequence));
    }

    /* renamed from: J */
    private static final C0590b<C0574c> m1954J(CharSequence charSequence, String[] strArr, int i, boolean z, int i2) {
        m1957M(i2);
        return new C0604c(charSequence, i, i2, new C0619a(C0154d.m448a(strArr), z));
    }

    /* renamed from: K */
    static /* synthetic */ C0590b m1955K(CharSequence charSequence, String[] strArr, int i, boolean z, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i = 0;
        }
        if ((i3 & 4) != 0) {
            z = false;
        }
        if ((i3 & 8) != 0) {
            i2 = 0;
        }
        return m1954J(charSequence, strArr, i, z, i2);
    }

    /* renamed from: L */
    public static final boolean m1956L(CharSequence charSequence, int i, CharSequence charSequence2, int i2, int i3, boolean z) {
        C0429i.m1496d(charSequence, "<this>");
        C0429i.m1496d(charSequence2, "other");
        if (i2 < 0 || i < 0 || i > charSequence.length() - i3 || i2 > charSequence2.length() - i3) {
            return false;
        }
        int i4 = 0;
        while (i4 < i3) {
            int i5 = i4 + 1;
            if (!C0603b.m1904d(charSequence.charAt(i + i4), charSequence2.charAt(i4 + i2), z)) {
                return false;
            }
            i4 = i5;
        }
        return true;
    }

    /* renamed from: M */
    public static final void m1957M(int i) {
        if (!(i >= 0)) {
            throw new IllegalArgumentException(C0429i.m1501i("Limit must be non-negative, but was ", Integer.valueOf(i)).toString());
        }
    }

    /* renamed from: N */
    public static final C0590b<String> m1958N(CharSequence charSequence, String[] strArr, boolean z, int i) {
        C0429i.m1496d(charSequence, "<this>");
        C0429i.m1496d(strArr, "delimiters");
        return C0597h.m1893c(m1955K(charSequence, strArr, 0, z, i, 2, (Object) null), new C0620b(charSequence));
    }

    /* renamed from: O */
    public static /* synthetic */ C0590b m1959O(CharSequence charSequence, String[] strArr, boolean z, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z = false;
        }
        if ((i2 & 4) != 0) {
            i = 0;
        }
        return m1958N(charSequence, strArr, z, i);
    }

    /* renamed from: P */
    public static final String m1960P(CharSequence charSequence, C0574c cVar) {
        C0429i.m1496d(charSequence, "<this>");
        C0429i.m1496d(cVar, "range");
        return charSequence.subSequence(cVar.mo1538g().intValue(), cVar.mo1537f().intValue() + 1).toString();
    }

    /* renamed from: Q */
    public static final String m1961Q(String str, char c, String str2) {
        C0429i.m1496d(str, "<this>");
        C0429i.m1496d(str2, "missingDelimiterValue");
        int z = m1982z(str, c, 0, false, 6, (Object) null);
        if (z == -1) {
            return str2;
        }
        String substring = str.substring(z + 1, str.length());
        C0429i.m1495c(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    /* renamed from: R */
    public static final String m1962R(String str, String str2, String str3) {
        C0429i.m1496d(str, "<this>");
        C0429i.m1496d(str2, "delimiter");
        C0429i.m1496d(str3, "missingDelimiterValue");
        int A = m1945A(str, str2, 0, false, 6, (Object) null);
        if (A == -1) {
            return str3;
        }
        String substring = str.substring(A + str2.length(), str.length());
        C0429i.m1495c(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    /* renamed from: S */
    public static /* synthetic */ String m1963S(String str, char c, String str2, int i, Object obj) {
        if ((i & 2) != 0) {
            str2 = str;
        }
        return m1961Q(str, c, str2);
    }

    /* renamed from: T */
    public static /* synthetic */ String m1964T(String str, String str2, String str3, int i, Object obj) {
        if ((i & 2) != 0) {
            str3 = str;
        }
        return m1962R(str, str2, str3);
    }

    /* renamed from: U */
    public static final String m1965U(String str, char c, String str2) {
        C0429i.m1496d(str, "<this>");
        C0429i.m1496d(str2, "missingDelimiterValue");
        int E = m1949E(str, c, 0, false, 6, (Object) null);
        if (E == -1) {
            return str2;
        }
        String substring = str.substring(E + 1, str.length());
        C0429i.m1495c(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    /* renamed from: V */
    public static /* synthetic */ String m1966V(String str, char c, String str2, int i, Object obj) {
        if ((i & 2) != 0) {
            str2 = str;
        }
        return m1965U(str, c, str2);
    }

    /* renamed from: W */
    public static final String m1967W(String str, char c, String str2) {
        C0429i.m1496d(str, "<this>");
        C0429i.m1496d(str2, "missingDelimiterValue");
        int z = m1982z(str, c, 0, false, 6, (Object) null);
        if (z == -1) {
            return str2;
        }
        String substring = str.substring(0, z);
        C0429i.m1495c(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    /* renamed from: X */
    public static final String m1968X(String str, String str2, String str3) {
        C0429i.m1496d(str, "<this>");
        C0429i.m1496d(str2, "delimiter");
        C0429i.m1496d(str3, "missingDelimiterValue");
        int A = m1945A(str, str2, 0, false, 6, (Object) null);
        if (A == -1) {
            return str3;
        }
        String substring = str.substring(0, A);
        C0429i.m1495c(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    /* renamed from: Y */
    public static /* synthetic */ String m1969Y(String str, char c, String str2, int i, Object obj) {
        if ((i & 2) != 0) {
            str2 = str;
        }
        return m1967W(str, c, str2);
    }

    /* renamed from: Z */
    public static /* synthetic */ String m1970Z(String str, String str2, String str3, int i, Object obj) {
        if ((i & 2) != 0) {
            str3 = str;
        }
        return m1968X(str, str2, str3);
    }

    /* renamed from: a0 */
    public static CharSequence m1971a0(CharSequence charSequence) {
        C0429i.m1496d(charSequence, "<this>");
        int length = charSequence.length() - 1;
        int i = 0;
        boolean z = false;
        while (i <= length) {
            boolean c = C0602a.m1903c(charSequence.charAt(!z ? i : length));
            if (!z) {
                if (!c) {
                    z = true;
                } else {
                    i++;
                }
            } else if (!c) {
                break;
            } else {
                length--;
            }
        }
        return charSequence.subSequence(i, length + 1);
    }

    /* renamed from: q */
    public static final boolean m1973q(CharSequence charSequence, CharSequence charSequence2, boolean z) {
        C0429i.m1496d(charSequence, "<this>");
        C0429i.m1496d(charSequence2, "other");
        if (charSequence2 instanceof String) {
            if (m1945A(charSequence, (String) charSequence2, 0, z, 2, (Object) null) >= 0) {
                return true;
            }
        } else {
            if (m1981y(charSequence, charSequence2, 0, charSequence.length(), z, false, 16, (Object) null) >= 0) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: r */
    public static /* synthetic */ boolean m1974r(CharSequence charSequence, CharSequence charSequence2, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        return m1973q(charSequence, charSequence2, z);
    }

    /* access modifiers changed from: private */
    /* renamed from: s */
    public static final C0132j<Integer, String> m1975s(CharSequence charSequence, Collection<String> collection, int i, boolean z, boolean z2) {
        int i2;
        T t;
        String str;
        T t2;
        if (z || collection.size() != 1) {
            C0571a cVar = !z2 ? new C0574c(C0578f.m1876a(i, 0), charSequence.length()) : C0578f.m1881f(C0578f.m1878c(i, m1977u(charSequence)), 0);
            if (charSequence instanceof String) {
                i2 = cVar.mo1526a();
                int b = cVar.mo1527b();
                int c = cVar.mo1528c();
                if ((c > 0 && i2 <= b) || (c < 0 && b <= i2)) {
                    while (true) {
                        int i3 = i2 + c;
                        Iterator<T> it = collection.iterator();
                        while (true) {
                            if (!it.hasNext()) {
                                t2 = null;
                                break;
                            }
                            t2 = it.next();
                            String str2 = (String) t2;
                            if (C0617m.m1942m(str2, 0, (String) charSequence, i2, str2.length(), z)) {
                                break;
                            }
                        }
                        str = (String) t2;
                        if (str != null) {
                            break;
                        } else if (i2 == b) {
                            break;
                        } else {
                            i2 = i3;
                        }
                    }
                }
                return null;
            }
            int a = cVar.mo1526a();
            int b2 = cVar.mo1527b();
            int c2 = cVar.mo1528c();
            if ((c2 > 0 && a <= b2) || (c2 < 0 && b2 <= a)) {
                while (true) {
                    int i4 = i2 + c2;
                    Iterator<T> it2 = collection.iterator();
                    while (true) {
                        if (!it2.hasNext()) {
                            t = null;
                            break;
                        }
                        t = it2.next();
                        String str3 = (String) t;
                        if (m1956L(str3, 0, charSequence, i2, str3.length(), z)) {
                            break;
                        }
                    }
                    str = (String) t;
                    if (str != null) {
                        break;
                    } else if (i2 == b2) {
                        break;
                    } else {
                        a = i4;
                    }
                }
            }
            return null;
            return C0138n.m424a(Integer.valueOf(i2), str);
        }
        String str4 = (String) C0169q.m487n(collection);
        CharSequence charSequence2 = charSequence;
        String str5 = str4;
        int i5 = i;
        int A = !z2 ? m1945A(charSequence2, str5, i5, false, 4, (Object) null) : m1950F(charSequence2, str5, i5, false, 4, (Object) null);
        if (A < 0) {
            return null;
        }
        return C0138n.m424a(Integer.valueOf(A), str4);
    }

    /* renamed from: t */
    public static final C0574c m1976t(CharSequence charSequence) {
        C0429i.m1496d(charSequence, "<this>");
        return new C0574c(0, charSequence.length() - 1);
    }

    /* renamed from: u */
    public static final int m1977u(CharSequence charSequence) {
        C0429i.m1496d(charSequence, "<this>");
        return charSequence.length() - 1;
    }

    /* renamed from: v */
    public static final int m1978v(CharSequence charSequence, char c, int i, boolean z) {
        C0429i.m1496d(charSequence, "<this>");
        if (!z && (charSequence instanceof String)) {
            return ((String) charSequence).indexOf(c, i);
        }
        return m1946B(charSequence, new char[]{c}, i, z);
    }

    /* renamed from: w */
    public static final int m1979w(CharSequence charSequence, String str, int i, boolean z) {
        C0429i.m1496d(charSequence, "<this>");
        C0429i.m1496d(str, "string");
        if (!z && (charSequence instanceof String)) {
            return ((String) charSequence).indexOf(str, i);
        }
        return m1981y(charSequence, str, i, charSequence.length(), z, false, 16, (Object) null);
    }

    /* renamed from: x */
    private static final int m1980x(CharSequence charSequence, CharSequence charSequence2, int i, int i2, boolean z, boolean z2) {
        C0571a cVar = !z2 ? new C0574c(C0578f.m1876a(i, 0), C0578f.m1878c(i2, charSequence.length())) : C0578f.m1881f(C0578f.m1878c(i, m1977u(charSequence)), C0578f.m1876a(i2, 0));
        if (!(charSequence instanceof String) || !(charSequence2 instanceof String)) {
            int a = cVar.mo1526a();
            int b = cVar.mo1527b();
            int c = cVar.mo1528c();
            if ((c <= 0 || a > b) && (c >= 0 || b > a)) {
                return -1;
            }
            while (true) {
                int i3 = a + c;
                if (m1956L(charSequence2, 0, charSequence, a, charSequence2.length(), z)) {
                    return a;
                }
                if (a == b) {
                    return -1;
                }
                a = i3;
            }
        } else {
            int a2 = cVar.mo1526a();
            int b2 = cVar.mo1527b();
            int c2 = cVar.mo1528c();
            if ((c2 <= 0 || a2 > b2) && (c2 >= 0 || b2 > a2)) {
                return -1;
            }
            while (true) {
                int i4 = a2 + c2;
                if (C0617m.m1942m((String) charSequence2, 0, (String) charSequence, a2, charSequence2.length(), z)) {
                    return a2;
                }
                if (a2 == b2) {
                    return -1;
                }
                a2 = i4;
            }
        }
    }

    /* renamed from: y */
    static /* synthetic */ int m1981y(CharSequence charSequence, CharSequence charSequence2, int i, int i2, boolean z, boolean z2, int i3, Object obj) {
        return m1980x(charSequence, charSequence2, i, i2, z, (i3 & 16) != 0 ? false : z2);
    }

    /* renamed from: z */
    public static /* synthetic */ int m1982z(CharSequence charSequence, char c, int i, boolean z, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = 0;
        }
        if ((i2 & 4) != 0) {
            z = false;
        }
        return m1978v(charSequence, c, i, z);
    }
}
