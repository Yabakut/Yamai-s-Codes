package p044u0;

/* renamed from: u0.d */
public final class C0606d extends C0622p {
}
