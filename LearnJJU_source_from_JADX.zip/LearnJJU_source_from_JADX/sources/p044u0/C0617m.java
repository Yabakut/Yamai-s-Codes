package p044u0;

import kotlin.jvm.internal.C0429i;

/* renamed from: u0.m */
class C0617m extends C0616l {
    /* renamed from: j */
    public static final boolean m1939j(String str, String str2, boolean z) {
        C0429i.m1496d(str, "<this>");
        C0429i.m1496d(str2, "suffix");
        if (!z) {
            return str.endsWith(str2);
        }
        return m1942m(str, str.length() - str2.length(), str2, 0, str2.length(), true);
    }

    /* renamed from: k */
    public static /* synthetic */ boolean m1940k(String str, String str2, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        return m1939j(str, str2, z);
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:? A[RETURN, SYNTHETIC] */
    /* renamed from: l */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean m1941l(java.lang.CharSequence r4) {
        /*
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.C0429i.m1496d(r4, r0)
            int r0 = r4.length()
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x003e
            r0.c r0 = p044u0.C0618n.m1976t(r4)
            boolean r3 = r0 instanceof java.util.Collection
            if (r3 == 0) goto L_0x0020
            r3 = r0
            java.util.Collection r3 = (java.util.Collection) r3
            boolean r3 = r3.isEmpty()
            if (r3 == 0) goto L_0x0020
        L_0x001e:
            r4 = 1
            goto L_0x003c
        L_0x0020:
            java.util.Iterator r0 = r0.iterator()
        L_0x0024:
            boolean r3 = r0.hasNext()
            if (r3 == 0) goto L_0x001e
            r3 = r0
            f0.v r3 = (p013f0.C0174v) r3
            int r3 = r3.mo651a()
            char r3 = r4.charAt(r3)
            boolean r3 = p044u0.C0602a.m1903c(r3)
            if (r3 != 0) goto L_0x0024
            r4 = 0
        L_0x003c:
            if (r4 == 0) goto L_0x003f
        L_0x003e:
            r1 = 1
        L_0x003f:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p044u0.C0617m.m1941l(java.lang.CharSequence):boolean");
    }

    /* renamed from: m */
    public static final boolean m1942m(String str, int i, String str2, int i2, int i3, boolean z) {
        C0429i.m1496d(str, "<this>");
        C0429i.m1496d(str2, "other");
        return !z ? str.regionMatches(i, str2, i2, i3) : str.regionMatches(z, i, str2, i2, i3);
    }

    /* renamed from: n */
    public static final boolean m1943n(String str, String str2, boolean z) {
        C0429i.m1496d(str, "<this>");
        C0429i.m1496d(str2, "prefix");
        if (!z) {
            return str.startsWith(str2);
        }
        return m1942m(str, 0, str2, 0, str2.length(), z);
    }

    /* renamed from: o */
    public static /* synthetic */ boolean m1944o(String str, String str2, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        return m1943n(str, str2, z);
    }
}
