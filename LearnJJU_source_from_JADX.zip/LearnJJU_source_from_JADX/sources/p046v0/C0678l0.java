package p046v0;

import p017h0.C0195g;

/* renamed from: v0.l0 */
public interface C0678l0 {
    /* renamed from: q */
    C0195g mo1368q();
}
