package p046v0;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import kotlin.jvm.internal.C0425e;

/* renamed from: v0.y */
public class C0722y {

    /* renamed from: b */
    private static final /* synthetic */ AtomicIntegerFieldUpdater f1332b = AtomicIntegerFieldUpdater.newUpdater(C0722y.class, "_handled");
    private volatile /* synthetic */ int _handled;

    /* renamed from: a */
    public final Throwable f1333a;

    public C0722y(Throwable th, boolean z) {
        this.f1333a = th;
        this._handled = z ? 1 : 0;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0722y(Throwable th, boolean z, int i, C0425e eVar) {
        this(th, (i & 2) != 0 ? false : z);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [int, boolean] */
    /* renamed from: a */
    public final boolean mo1693a() {
        return this._handled;
    }

    /* renamed from: b */
    public final boolean mo1694b() {
        return f1332b.compareAndSet(this, 0, 1);
    }

    public String toString() {
        return C0696q0.m2160a(this) + '[' + this.f1333a + ']';
    }
}
