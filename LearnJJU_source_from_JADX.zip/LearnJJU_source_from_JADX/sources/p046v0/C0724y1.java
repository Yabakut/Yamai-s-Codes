package p046v0;

/* renamed from: v0.y1 */
public abstract class C0724y1 extends C0647f0 {
    /* renamed from: p */
    public abstract C0724y1 mo1424p();

    /* access modifiers changed from: protected */
    /* renamed from: q */
    public final String mo1697q() {
        C0724y1 y1Var;
        C0724y1 c = C0717w0.m2291c();
        if (this == c) {
            return "Dispatchers.Main";
        }
        try {
            y1Var = c.mo1424p();
        } catch (UnsupportedOperationException unused) {
            y1Var = null;
        }
        if (this == y1Var) {
            return "Dispatchers.Main.immediate";
        }
        return null;
    }

    public String toString() {
        String q = mo1697q();
        if (q != null) {
            return q;
        }
        return C0696q0.m2160a(this) + '@' + C0696q0.m2161b(this);
    }
}
