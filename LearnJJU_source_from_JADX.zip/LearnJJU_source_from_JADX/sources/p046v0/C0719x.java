package p046v0;

import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0429i;
import p011e0.C0141q;
import p032o0.C0543l;

/* renamed from: v0.x */
final class C0719x {

    /* renamed from: a */
    public final Object f1326a;

    /* renamed from: b */
    public final C0662i f1327b;

    /* renamed from: c */
    public final C0543l<Throwable, C0141q> f1328c;

    /* renamed from: d */
    public final Object f1329d;

    /* renamed from: e */
    public final Throwable f1330e;

    public C0719x(Object obj, C0662i iVar, C0543l<? super Throwable, C0141q> lVar, Object obj2, Throwable th) {
        this.f1326a = obj;
        this.f1327b = iVar;
        this.f1328c = lVar;
        this.f1329d = obj2;
        this.f1330e = th;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0719x(Object obj, C0662i iVar, C0543l lVar, Object obj2, Throwable th, int i, C0425e eVar) {
        this(obj, (i & 2) != 0 ? null : iVar, (i & 4) != 0 ? null : lVar, (i & 8) != 0 ? null : obj2, (i & 16) != 0 ? null : th);
    }

    /* renamed from: b */
    public static /* synthetic */ C0719x m2299b(C0719x xVar, Object obj, C0662i iVar, C0543l<Throwable, C0141q> lVar, Object obj2, Throwable th, int i, Object obj3) {
        if ((i & 1) != 0) {
            obj = xVar.f1326a;
        }
        if ((i & 2) != 0) {
            iVar = xVar.f1327b;
        }
        C0662i iVar2 = iVar;
        if ((i & 4) != 0) {
            lVar = xVar.f1328c;
        }
        C0543l<Throwable, C0141q> lVar2 = lVar;
        if ((i & 8) != 0) {
            obj2 = xVar.f1329d;
        }
        Object obj4 = obj2;
        if ((i & 16) != 0) {
            th = xVar.f1330e;
        }
        return xVar.mo1687a(obj, iVar2, lVar2, obj4, th);
    }

    /* renamed from: a */
    public final C0719x mo1687a(Object obj, C0662i iVar, C0543l<? super Throwable, C0141q> lVar, Object obj2, Throwable th) {
        return new C0719x(obj, iVar, lVar, obj2, th);
    }

    /* renamed from: c */
    public final boolean mo1688c() {
        return this.f1330e != null;
    }

    /* renamed from: d */
    public final void mo1689d(C0677l<?> lVar, Throwable th) {
        C0662i iVar = this.f1327b;
        if (iVar != null) {
            lVar.mo1626k(iVar, th);
        }
        C0543l<Throwable, C0141q> lVar2 = this.f1328c;
        if (lVar2 != null) {
            lVar.mo1627l(lVar2, th);
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0719x)) {
            return false;
        }
        C0719x xVar = (C0719x) obj;
        return C0429i.m1493a(this.f1326a, xVar.f1326a) && C0429i.m1493a(this.f1327b, xVar.f1327b) && C0429i.m1493a(this.f1328c, xVar.f1328c) && C0429i.m1493a(this.f1329d, xVar.f1329d) && C0429i.m1493a(this.f1330e, xVar.f1330e);
    }

    public int hashCode() {
        Object obj = this.f1326a;
        int i = 0;
        int hashCode = (obj == null ? 0 : obj.hashCode()) * 31;
        C0662i iVar = this.f1327b;
        int hashCode2 = (hashCode + (iVar == null ? 0 : iVar.hashCode())) * 31;
        C0543l<Throwable, C0141q> lVar = this.f1328c;
        int hashCode3 = (hashCode2 + (lVar == null ? 0 : lVar.hashCode())) * 31;
        Object obj2 = this.f1329d;
        int hashCode4 = (hashCode3 + (obj2 == null ? 0 : obj2.hashCode())) * 31;
        Throwable th = this.f1330e;
        if (th != null) {
            i = th.hashCode();
        }
        return hashCode4 + i;
    }

    public String toString() {
        return "CompletedContinuation(result=" + this.f1326a + ", cancelHandler=" + this.f1327b + ", onCancellation=" + this.f1328c + ", idempotentResume=" + this.f1329d + ", cancelCause=" + this.f1330e + ')';
    }
}
