package p046v0;

/* renamed from: v0.q1 */
public abstract class C0697q1 extends C0709u1 {
}
