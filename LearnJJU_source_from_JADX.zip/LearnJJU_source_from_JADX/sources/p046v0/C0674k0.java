package p046v0;

import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0429i;
import p017h0.C0186a;
import p017h0.C0195g;

/* renamed from: v0.k0 */
public final class C0674k0 extends C0186a {

    /* renamed from: e */
    public static final C0675a f1265e = new C0675a((C0425e) null);

    /* renamed from: d */
    private final String f1266d;

    /* renamed from: v0.k0$a */
    public static final class C0675a implements C0195g.C0200c<C0674k0> {
        private C0675a() {
        }

        public /* synthetic */ C0675a(C0425e eVar) {
            this();
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C0674k0) && C0429i.m1493a(this.f1266d, ((C0674k0) obj).f1266d);
    }

    public int hashCode() {
        return this.f1266d.hashCode();
    }

    /* renamed from: m */
    public final String mo1619m() {
        return this.f1266d;
    }

    public String toString() {
        return "CoroutineName(" + this.f1266d + ')';
    }
}
