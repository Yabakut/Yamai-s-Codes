package p046v0;

import kotlin.jvm.internal.C0429i;
import p017h0.C0190d;
import p017h0.C0195g;
import p032o0.C0543l;
import p032o0.C0547p;

/* renamed from: v0.a */
public abstract class C0624a<T> extends C0712v1 implements C0190d<T>, C0678l0 {

    /* renamed from: e */
    private final C0195g f1234e;

    public C0624a(C0195g gVar, boolean z, boolean z2) {
        super(z2);
        if (z) {
            mo1665S((C0689o1) gVar.get(C0689o1.f1285c));
        }
        this.f1234e = gVar.plus(this);
    }

    /* access modifiers changed from: protected */
    /* renamed from: C */
    public String mo1556C() {
        return C0429i.m1501i(C0696q0.m2160a(this), " was cancelled");
    }

    /* renamed from: R */
    public final void mo1557R(Throwable th) {
        C0659h0.m2067a(this.f1234e, th);
    }

    /* renamed from: Y */
    public String mo1558Y() {
        String b = C0643e0.m2040b(this.f1234e);
        if (b == null) {
            return super.mo1558Y();
        }
        return '\"' + b + "\":" + super.mo1558Y();
    }

    /* renamed from: a */
    public boolean mo1559a() {
        return super.mo1559a();
    }

    /* access modifiers changed from: protected */
    /* renamed from: d0 */
    public final void mo1560d0(Object obj) {
        if (obj instanceof C0722y) {
            C0722y yVar = (C0722y) obj;
            mo1561u0(yVar.f1333a, yVar.mo1693a());
            return;
        }
        mo1562v0(obj);
    }

    public final C0195g getContext() {
        return this.f1234e;
    }

    /* renamed from: q */
    public C0195g mo1368q() {
        return this.f1234e;
    }

    public final void resumeWith(Object obj) {
        Object W = mo1667W(C0635c0.m2032d(obj, (C0543l) null, 1, (Object) null));
        if (W != C0718w1.f1320b) {
            mo1432t0(W);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: t0 */
    public void mo1432t0(Object obj) {
        mo1433x(obj);
    }

    /* access modifiers changed from: protected */
    /* renamed from: u0 */
    public void mo1561u0(Throwable th, boolean z) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: v0 */
    public void mo1562v0(T t) {
    }

    /* renamed from: w0 */
    public final <R> void mo1563w0(C0684n0 n0Var, R r, C0547p<? super R, ? super C0190d<? super T>, ? extends Object> pVar) {
        n0Var.mo1635b(pVar, r, this);
    }
}
