package p046v0;

/* renamed from: v0.e */
public abstract class C0642e extends C0662i {
}
