package p046v0;

import p011e0.C0141q;
import p017h0.C0195g;

/* renamed from: v0.d2 */
class C0641d2 extends C0624a<C0141q> {
    public C0641d2(C0195g gVar, boolean z) {
        super(gVar, true, z);
    }

    /* access modifiers changed from: protected */
    /* renamed from: Q */
    public boolean mo1587Q(Throwable th) {
        C0659h0.m2067a(getContext(), th);
        return true;
    }
}
