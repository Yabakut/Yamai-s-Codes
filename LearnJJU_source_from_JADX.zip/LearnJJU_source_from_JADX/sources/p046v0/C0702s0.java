package p046v0;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import kotlinx.coroutines.internal.C0453h;
import kotlinx.coroutines.internal.C0482x;
import p032o0.C0543l;

/* renamed from: v0.s0 */
public final class C0702s0<T> extends C0482x<T> {

    /* renamed from: g */
    private static final /* synthetic */ AtomicIntegerFieldUpdater f1297g = AtomicIntegerFieldUpdater.newUpdater(C0702s0.class, "_decision");
    private volatile /* synthetic */ int _decision;

    /* renamed from: y0 */
    private final boolean m2174y0() {
        do {
            int i = this._decision;
            if (i != 0) {
                if (i == 1) {
                    return false;
                }
                throw new IllegalStateException("Already resumed".toString());
            }
        } while (!f1297g.compareAndSet(this, 0, 2));
        return true;
    }

    /* access modifiers changed from: protected */
    /* renamed from: t0 */
    public void mo1432t0(Object obj) {
        if (!m2174y0()) {
            C0453h.m1588c(C0207c.m563b(this.f1053f), C0635c0.m2029a(obj, this.f1053f), (C0543l) null, 2, (Object) null);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: x */
    public void mo1433x(Object obj) {
        mo1432t0(obj);
    }
}
