package p046v0;

import java.util.concurrent.Executor;
import p017h0.C0201h;

/* renamed from: v0.v0 */
final class C0711v0 implements Executor {

    /* renamed from: d */
    public final C0647f0 f1305d;

    public void execute(Runnable runnable) {
        this.f1305d.mo1422m(C0201h.f297d, runnable);
    }

    public String toString() {
        return this.f1305d.toString();
    }
}
