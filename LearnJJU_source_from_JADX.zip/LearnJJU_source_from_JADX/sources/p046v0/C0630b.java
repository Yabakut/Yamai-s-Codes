package p046v0;

/* renamed from: v0.b */
public abstract class C0630b {
}
