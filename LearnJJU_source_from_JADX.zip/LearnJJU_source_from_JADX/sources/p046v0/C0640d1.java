package p046v0;

import kotlinx.coroutines.internal.C0484z;

/* renamed from: v0.d1 */
public final class C0640d1 {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public static final C0484z f1244a = new C0484z("REMOVED_TASK");
    /* access modifiers changed from: private */

    /* renamed from: b */
    public static final C0484z f1245b = new C0484z("CLOSED_EMPTY");
}
