package p046v0;

import kotlin.jvm.internal.C0429i;

/* renamed from: v0.u1 */
public abstract class C0709u1 extends C0625a0 implements C0720x0, C0669j1 {

    /* renamed from: g */
    public C0712v1 f1301g;

    /* renamed from: A */
    public final void mo1656A(C0712v1 v1Var) {
        this.f1301g = v1Var;
    }

    /* renamed from: a */
    public boolean mo1601a() {
        return true;
    }

    /* renamed from: b */
    public void mo1572b() {
        mo1657z().mo1670h0(this);
    }

    /* renamed from: c */
    public C0727z1 mo1602c() {
        return null;
    }

    public String toString() {
        return C0696q0.m2160a(this) + '@' + C0696q0.m2161b(this) + "[job@" + C0696q0.m2161b(mo1657z()) + ']';
    }

    /* renamed from: z */
    public final C0712v1 mo1657z() {
        C0712v1 v1Var = this.f1301g;
        if (v1Var != null) {
            return v1Var;
        }
        C0429i.m1505m("job");
        return null;
    }
}
