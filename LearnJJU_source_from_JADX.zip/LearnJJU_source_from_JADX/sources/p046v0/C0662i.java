package p046v0;

/* renamed from: v0.i */
public abstract class C0662i extends C0666j implements C0633b2 {
}
