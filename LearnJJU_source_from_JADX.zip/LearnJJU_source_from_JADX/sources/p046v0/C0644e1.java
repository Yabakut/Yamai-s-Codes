package p046v0;

import java.util.concurrent.CancellationException;

/* renamed from: v0.e1 */
public final class C0644e1 {
    /* renamed from: a */
    public static final CancellationException m2044a(String str, Throwable th) {
        CancellationException cancellationException = new CancellationException(str);
        cancellationException.initCause(th);
        return cancellationException;
    }
}
