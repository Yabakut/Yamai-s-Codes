package p046v0;

import java.util.concurrent.locks.LockSupport;
import p046v0.C0626a1;

/* renamed from: v0.b1 */
public abstract class C0632b1 extends C0726z0 {
    /* access modifiers changed from: protected */
    /* renamed from: A */
    public abstract Thread mo1581A();

    /* access modifiers changed from: protected */
    /* renamed from: B */
    public final void mo1582B(long j, C0626a1.C0627a aVar) {
        if (C0693p0.m2153a()) {
            if (!(this != C0699r0.f1294j)) {
                throw new AssertionError();
            }
        }
        C0699r0.f1294j.mo1569N(j, aVar);
    }

    /* access modifiers changed from: protected */
    /* renamed from: C */
    public final void mo1583C() {
        Thread A = mo1581A();
        if (Thread.currentThread() != A) {
            C0634c.m2028a();
            LockSupport.unpark(A);
        }
    }
}
