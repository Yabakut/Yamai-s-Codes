package p046v0;

import kotlinx.coroutines.internal.C0451g;
import p017h0.C0190d;

/* renamed from: v0.n */
public final class C0683n {
    /* renamed from: a */
    public static final <T> C0677l<T> m2134a(C0190d<? super T> dVar) {
        if (!(dVar instanceof C0451g)) {
            return new C0677l<>(dVar, 1);
        }
        C0677l<T> j = ((C0451g) dVar).mo1378j();
        if (j == null || !j.mo1623G()) {
            j = null;
        }
        return j == null ? new C0677l<>(dVar, 2) : j;
    }
}
