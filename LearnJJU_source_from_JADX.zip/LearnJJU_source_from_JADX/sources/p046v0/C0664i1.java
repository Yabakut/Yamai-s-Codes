package p046v0;

/* renamed from: v0.i1 */
public final class C0664i1 implements C0669j1 {

    /* renamed from: d */
    private final C0727z1 f1259d;

    public C0664i1(C0727z1 z1Var) {
        this.f1259d = z1Var;
    }

    /* renamed from: a */
    public boolean mo1601a() {
        return false;
    }

    /* renamed from: c */
    public C0727z1 mo1602c() {
        return this.f1259d;
    }

    public String toString() {
        return C0693p0.m2155c() ? mo1602c().mo1707y("New") : super.toString();
    }
}
