package p046v0;

import p017h0.C0195g;

/* renamed from: v0.e2 */
public interface C0645e2<S> extends C0195g.C0198b {
    /* renamed from: l */
    S mo1588l(C0195g gVar);

    /* renamed from: s */
    void mo1589s(C0195g gVar, S s);
}
