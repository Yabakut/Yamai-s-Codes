package p046v0;

/* renamed from: v0.f */
public final class C0646f extends C0626a1 {

    /* renamed from: j */
    private final Thread f1247j;

    public C0646f(Thread thread) {
        this.f1247j = thread;
    }

    /* access modifiers changed from: protected */
    /* renamed from: A */
    public Thread mo1581A() {
        return this.f1247j;
    }
}
