package p046v0;

import kotlin.jvm.internal.C0429i;
import kotlinx.coroutines.internal.C0466m;
import kotlinx.coroutines.internal.C0468o;

/* renamed from: v0.z1 */
public final class C0727z1 extends C0466m implements C0669j1 {
    /* renamed from: a */
    public boolean mo1601a() {
        return true;
    }

    /* renamed from: c */
    public C0727z1 mo1602c() {
        return this;
    }

    public String toString() {
        return C0693p0.m2155c() ? mo1707y("Active") : super.toString();
    }

    /* renamed from: y */
    public final String mo1707y(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append("List{");
        sb.append(str);
        sb.append("}[");
        boolean z = true;
        for (C0468o oVar = (C0468o) mo1398o(); !C0429i.m1493a(oVar, this); oVar = oVar.mo1399p()) {
            if (oVar instanceof C0709u1) {
                C0709u1 u1Var = (C0709u1) oVar;
                if (z) {
                    z = false;
                } else {
                    sb.append(", ");
                }
                sb.append(u1Var);
            }
        }
        sb.append("]");
        String sb2 = sb.toString();
        C0429i.m1495c(sb2, "StringBuilder().apply(builderAction).toString()");
        return sb2;
    }
}
