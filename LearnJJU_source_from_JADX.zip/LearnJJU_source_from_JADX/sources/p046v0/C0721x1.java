package p046v0;

import p002a1.C0010a;
import p011e0.C0141q;
import p017h0.C0190d;
import p017h0.C0195g;
import p032o0.C0547p;

/* renamed from: v0.x1 */
final class C0721x1 extends C0641d2 {

    /* renamed from: f */
    private final C0190d<C0141q> f1331f;

    public C0721x1(C0195g gVar, C0547p<? super C0678l0, ? super C0190d<? super C0141q>, ? extends Object> pVar) {
        super(gVar, false);
        this.f1331f = C0207c.m562a(pVar, this, this);
    }

    /* access modifiers changed from: protected */
    /* renamed from: e0 */
    public void mo1669e0() {
        C0010a.m19c(this.f1331f, this);
    }
}
