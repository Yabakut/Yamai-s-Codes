package p046v0;

import java.util.concurrent.CancellationException;

/* renamed from: v0.c2 */
public interface C0637c2 extends C0689o1 {
    /* renamed from: e */
    CancellationException mo1584e();
}
