package p046v0;

import kotlinx.coroutines.CoroutineExceptionHandler;
import p017h0.C0195g;

/* renamed from: v0.h0 */
public final class C0659h0 {
    /* renamed from: a */
    public static final void m2067a(C0195g gVar, Throwable th) {
        try {
            CoroutineExceptionHandler coroutineExceptionHandler = (CoroutineExceptionHandler) gVar.get(CoroutineExceptionHandler.f985b);
            if (coroutineExceptionHandler == null) {
                C0655g0.m2059a(gVar, th);
            } else {
                coroutineExceptionHandler.handleException(gVar, th);
            }
        } catch (Throwable th2) {
            C0655g0.m2059a(gVar, m2068b(th, th2));
        }
    }

    /* renamed from: b */
    public static final Throwable m2068b(Throwable th, Throwable th2) {
        if (th == th2) {
            return th;
        }
        RuntimeException runtimeException = new RuntimeException("Exception while trying to handle coroutine exception", th2);
        C0124b.m410a(runtimeException, th);
        return runtimeException;
    }
}
