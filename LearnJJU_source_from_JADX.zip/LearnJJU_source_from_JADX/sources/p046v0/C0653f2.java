package p046v0;

/* renamed from: v0.f2 */
public final class C0653f2 {

    /* renamed from: a */
    public static final C0653f2 f1252a = new C0653f2();

    /* renamed from: b */
    private static final ThreadLocal<C0726z0> f1253b = new ThreadLocal<>();

    private C0653f2() {
    }

    /* renamed from: a */
    public final C0726z0 mo1592a() {
        ThreadLocal<C0726z0> threadLocal = f1253b;
        C0726z0 z0Var = threadLocal.get();
        if (z0Var != null) {
            return z0Var;
        }
        C0726z0 a = C0636c1.m2033a();
        threadLocal.set(a);
        return a;
    }

    /* renamed from: b */
    public final void mo1593b() {
        f1253b.set((Object) null);
    }

    /* renamed from: c */
    public final void mo1594c(C0726z0 z0Var) {
        f1253b.set(z0Var);
    }
}
