package p046v0;

import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0429i;
import p011e0.C0141q;
import p017h0.C0186a;
import p017h0.C0195g;

/* renamed from: v0.j0 */
public final class C0667j0 extends C0186a implements C0645e2<String> {

    /* renamed from: e */
    public static final C0668a f1261e = new C0668a((C0425e) null);

    /* renamed from: d */
    private final long f1262d;

    /* renamed from: v0.j0$a */
    public static final class C0668a implements C0195g.C0200c<C0667j0> {
        private C0668a() {
        }

        public /* synthetic */ C0668a(C0425e eVar) {
            this();
        }
    }

    public C0667j0(long j) {
        super(f1261e);
        this.f1262d = j;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C0667j0) && this.f1262d == ((C0667j0) obj).f1262d;
    }

    public int hashCode() {
        return C0663i0.m2073a(this.f1262d);
    }

    /* renamed from: m */
    public final long mo1607m() {
        return this.f1262d;
    }

    /* renamed from: n */
    public void mo1589s(C0195g gVar, String str) {
        Thread.currentThread().setName(str);
    }

    /* renamed from: p */
    public String mo1588l(C0195g gVar) {
        String m;
        C0674k0 k0Var = (C0674k0) gVar.get(C0674k0.f1265e);
        String str = "coroutine";
        if (!(k0Var == null || (m = k0Var.mo1619m()) == null)) {
            str = m;
        }
        Thread currentThread = Thread.currentThread();
        String name = currentThread.getName();
        int F = C0618n.m1950F(name, " @", 0, false, 6, (Object) null);
        if (F < 0) {
            F = name.length();
        }
        StringBuilder sb = new StringBuilder(str.length() + F + 10);
        if (name != null) {
            String substring = name.substring(0, F);
            C0429i.m1495c(substring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            sb.append(substring);
            sb.append(" @");
            sb.append(str);
            sb.append('#');
            sb.append(mo1607m());
            C0141q qVar = C0141q.f277a;
            String sb2 = sb.toString();
            C0429i.m1495c(sb2, "StringBuilder(capacity).…builderAction).toString()");
            currentThread.setName(sb2);
            return name;
        }
        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
    }

    public String toString() {
        return "CoroutineId(" + this.f1262d + ')';
    }
}
