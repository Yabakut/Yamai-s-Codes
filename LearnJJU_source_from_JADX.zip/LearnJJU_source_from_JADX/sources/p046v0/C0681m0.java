package p046v0;

import kotlinx.coroutines.internal.C0449f;
import p017h0.C0195g;

/* renamed from: v0.m0 */
public final class C0681m0 {
    /* renamed from: a */
    public static final C0678l0 m2132a(C0195g gVar) {
        if (gVar.get(C0689o1.f1285c) == null) {
            gVar = gVar.plus(C0706t1.m2189b((C0689o1) null, 1, (Object) null));
        }
        return new C0449f(gVar);
    }
}
