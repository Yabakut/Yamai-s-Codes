package p046v0;

import kotlinx.coroutines.internal.C0468o;
import p011e0.C0141q;
import p032o0.C0543l;

/* renamed from: v0.a0 */
public abstract class C0625a0 extends C0468o implements C0543l<Throwable, C0141q> {
    /* renamed from: y */
    public abstract void mo1564y(Throwable th);
}
