package p046v0;

import kotlinx.coroutines.internal.C0436a;

/* renamed from: v0.z0 */
public abstract class C0726z0 extends C0647f0 {

    /* renamed from: e */
    private long f1337e;

    /* renamed from: f */
    private boolean f1338f;

    /* renamed from: g */
    private C0436a<C0705t0<?>> f1339g;

    /* renamed from: q */
    private final long m2311q(boolean z) {
        return z ? 4294967296L : 1;
    }

    /* renamed from: v */
    public static /* synthetic */ void m2312v(C0726z0 z0Var, boolean z, int i, Object obj) {
        if (obj == null) {
            if ((i & 1) != 0) {
                z = false;
            }
            z0Var.mo1703u(z);
            return;
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: incrementUseCount");
    }

    /* renamed from: p */
    public final void mo1701p(boolean z) {
        long q = this.f1337e - m2311q(z);
        this.f1337e = q;
        if (q <= 0) {
            if (C0693p0.m2153a()) {
                if (!(this.f1337e == 0)) {
                    throw new AssertionError();
                }
            }
            if (this.f1338f) {
                mo1571z();
            }
        }
    }

    /* renamed from: r */
    public final void mo1702r(C0705t0<?> t0Var) {
        C0436a<C0705t0<?>> aVar = this.f1339g;
        if (aVar == null) {
            aVar = new C0436a<>();
            this.f1339g = aVar;
        }
        aVar.mo1348a(t0Var);
    }

    /* access modifiers changed from: protected */
    /* renamed from: t */
    public long mo1570t() {
        C0436a<C0705t0<?>> aVar = this.f1339g;
        return (aVar != null && !aVar.mo1349c()) ? 0 : Long.MAX_VALUE;
    }

    /* renamed from: u */
    public final void mo1703u(boolean z) {
        this.f1337e += m2311q(z);
        if (!z) {
            this.f1338f = true;
        }
    }

    /* renamed from: w */
    public final boolean mo1704w() {
        return this.f1337e >= m2311q(true);
    }

    /* renamed from: x */
    public final boolean mo1705x() {
        C0436a<C0705t0<?>> aVar = this.f1339g;
        if (aVar == null) {
            return true;
        }
        return aVar.mo1349c();
    }

    /* renamed from: y */
    public final boolean mo1706y() {
        C0705t0 d;
        C0436a<C0705t0<?>> aVar = this.f1339g;
        if (aVar == null || (d = aVar.mo1350d()) == null) {
            return false;
        }
        d.run();
        return true;
    }

    /* access modifiers changed from: protected */
    /* renamed from: z */
    public void mo1571z() {
    }
}
