package p046v0;

import p011e0.C0141q;
import p032o0.C0543l;

/* renamed from: v0.n1 */
final class C0686n1 extends C0709u1 {

    /* renamed from: h */
    private final C0543l<Throwable, C0141q> f1283h;

    public C0686n1(C0543l<? super Throwable, C0141q> lVar) {
        this.f1283h = lVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        mo1564y((Throwable) obj);
        return C0141q.f277a;
    }

    /* renamed from: y */
    public void mo1564y(Throwable th) {
        this.f1283h.invoke(th);
    }
}
