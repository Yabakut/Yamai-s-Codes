package p046v0;

import java.util.concurrent.CancellationException;
import p017h0.C0195g;

/* renamed from: v0.t1 */
final /* synthetic */ class C0706t1 {
    /* renamed from: a */
    public static final C0716w m2188a(C0689o1 o1Var) {
        return new C0700r1(o1Var);
    }

    /* renamed from: b */
    public static /* synthetic */ C0716w m2189b(C0689o1 o1Var, int i, Object obj) {
        if ((i & 1) != 0) {
            o1Var = null;
        }
        return C0703s1.m2177a(o1Var);
    }

    /* renamed from: c */
    public static final void m2190c(C0195g gVar, CancellationException cancellationException) {
        C0689o1 o1Var = (C0689o1) gVar.get(C0689o1.f1285c);
        if (o1Var != null) {
            o1Var.mo1638d(cancellationException);
        }
    }

    /* renamed from: d */
    public static final void m2191d(C0195g gVar) {
        C0689o1 o1Var = (C0689o1) gVar.get(C0689o1.f1285c);
        if (o1Var != null) {
            C0703s1.m2181e(o1Var);
        }
    }

    /* renamed from: e */
    public static final void m2192e(C0689o1 o1Var) {
        if (!o1Var.mo1559a()) {
            throw o1Var.mo1639h();
        }
    }
}
