package p046v0;

/* renamed from: v0.j1 */
public interface C0669j1 {
    /* renamed from: a */
    boolean mo1601a();

    /* renamed from: c */
    C0727z1 mo1602c();
}
