package p046v0;

import p017h0.C0195g;

/* renamed from: v0.g2 */
public final class C0657g2 extends C0647f0 {

    /* renamed from: e */
    public static final C0657g2 f1256e = new C0657g2();

    private C0657g2() {
    }

    /* renamed from: m */
    public void mo1422m(C0195g gVar, Runnable runnable) {
        C0670j2 j2Var = (C0670j2) gVar.get(C0670j2.f1263e);
        if (j2Var != null) {
            j2Var.f1264d = true;
            return;
        }
        throw new UnsupportedOperationException("Dispatchers.Unconfined.dispatch function can only be used by the yield function. If you wrap Unconfined dispatcher in your code, make sure you properly delegate isDispatchNeeded and dispatch calls.");
    }

    /* renamed from: n */
    public boolean mo1423n(C0195g gVar) {
        return false;
    }

    public String toString() {
        return "Dispatchers.Unconfined";
    }
}
