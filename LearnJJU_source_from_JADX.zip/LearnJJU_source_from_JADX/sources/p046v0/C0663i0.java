package p046v0;

/* renamed from: v0.i0 */
public final /* synthetic */ class C0663i0 {
    /* renamed from: a */
    public static /* synthetic */ int m2073a(long j) {
        return (int) (j ^ (j >>> 32));
    }
}
