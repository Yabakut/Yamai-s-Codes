package p046v0;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.coroutines.jvm.internal.C0411e;
import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0429i;
import kotlinx.coroutines.internal.C0440c;
import kotlinx.coroutines.internal.C0451g;
import kotlinx.coroutines.internal.C0483y;
import kotlinx.coroutines.internal.C0484z;
import p011e0.C0126d;
import p011e0.C0141q;
import p017h0.C0190d;
import p017h0.C0195g;
import p032o0.C0543l;
import p046v0.C0689o1;

/* renamed from: v0.l */
public class C0677l<T> extends C0705t0<T> implements C0672k<T>, C0411e {

    /* renamed from: j */
    private static final /* synthetic */ AtomicIntegerFieldUpdater f1268j = AtomicIntegerFieldUpdater.newUpdater(C0677l.class, "_decision");

    /* renamed from: k */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f1269k = AtomicReferenceFieldUpdater.newUpdater(C0677l.class, Object.class, "_state");
    private volatile /* synthetic */ int _decision;
    private volatile /* synthetic */ Object _state;

    /* renamed from: g */
    private final C0190d<T> f1270g;

    /* renamed from: h */
    private final C0195g f1271h;

    /* renamed from: i */
    private C0720x0 f1272i;

    public C0677l(C0190d<? super T> dVar, int i) {
        super(i);
        this.f1270g = dVar;
        if (C0693p0.m2153a()) {
            if (!(i != -1)) {
                throw new AssertionError();
            }
        }
        this.f1271h = dVar.getContext();
        this._decision = 0;
        this._state = C0638d.f1243d;
    }

    /* renamed from: A */
    private final boolean m2092A() {
        return C0708u0.m2195c(this.f1299f) && ((C0451g) this.f1270g).mo1379l();
    }

    /* renamed from: B */
    private final C0662i m2093B(C0543l<? super Throwable, C0141q> lVar) {
        return lVar instanceof C0662i ? (C0662i) lVar : new C0679l1(lVar);
    }

    /* renamed from: C */
    private final void m2094C(C0543l<? super Throwable, C0141q> lVar, Object obj) {
        throw new IllegalStateException(("It's prohibited to register multiple handlers, tried to register " + lVar + ", already has " + obj).toString());
    }

    /* renamed from: F */
    private final void m2095F() {
        C0190d<T> dVar = this.f1270g;
        Throwable th = null;
        C0451g gVar = dVar instanceof C0451g ? (C0451g) dVar : null;
        if (gVar != null) {
            th = gVar.mo1382s(this);
        }
        if (th != null) {
            mo1629s();
            mo1628o(th);
        }
    }

    /* renamed from: H */
    private final void m2096H(Object obj, int i, C0543l<? super Throwable, C0141q> lVar) {
        Object obj2;
        do {
            obj2 = this._state;
            if (obj2 instanceof C0633b2) {
            } else {
                if (obj2 instanceof C0687o) {
                    C0687o oVar = (C0687o) obj2;
                    if (oVar.mo1637c()) {
                        if (lVar != null) {
                            mo1627l(lVar, oVar.f1333a);
                            return;
                        }
                        return;
                    }
                }
                m2102i(obj);
                throw new C0126d();
            }
        } while (!C0440c.m1537a(f1269k, this, obj2, m2098J((C0633b2) obj2, obj, i, lVar, (Object) null)));
        m2105t();
        m2106u(i);
    }

    /* renamed from: I */
    static /* synthetic */ void m2097I(C0677l lVar, Object obj, int i, C0543l lVar2, int i2, Object obj2) {
        if (obj2 == null) {
            if ((i2 & 4) != 0) {
                lVar2 = null;
            }
            lVar.m2096H(obj, i, lVar2);
            return;
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: resumeImpl");
    }

    /* renamed from: J */
    private final Object m2098J(C0633b2 b2Var, Object obj, int i, C0543l<? super Throwable, C0141q> lVar, Object obj2) {
        if (obj instanceof C0722y) {
            boolean z = true;
            if (C0693p0.m2153a()) {
                if (!(obj2 == null)) {
                    throw new AssertionError();
                }
            }
            if (!C0693p0.m2153a()) {
                return obj;
            }
            if (lVar != null) {
                z = false;
            }
            if (z) {
                return obj;
            }
            throw new AssertionError();
        } else if (!C0708u0.m2194b(i) && obj2 == null) {
            return obj;
        } else {
            if (lVar == null && ((!(b2Var instanceof C0662i) || (b2Var instanceof C0642e)) && obj2 == null)) {
                return obj;
            }
            return new C0719x(obj, b2Var instanceof C0662i ? (C0662i) b2Var : null, lVar, obj2, (Throwable) null, 16, (C0425e) null);
        }
    }

    /* renamed from: K */
    private final boolean m2099K() {
        do {
            int i = this._decision;
            if (i != 0) {
                if (i == 1) {
                    return false;
                }
                throw new IllegalStateException("Already resumed".toString());
            }
        } while (!f1268j.compareAndSet(this, 0, 2));
        return true;
    }

    /* renamed from: L */
    private final C0484z m2100L(Object obj, Object obj2, C0543l<? super Throwable, C0141q> lVar) {
        Object obj3;
        do {
            obj3 = this._state;
            if (obj3 instanceof C0633b2) {
            } else if (!(obj3 instanceof C0719x) || obj2 == null) {
                return null;
            } else {
                C0719x xVar = (C0719x) obj3;
                if (xVar.f1329d != obj2) {
                    return null;
                }
                if (!C0693p0.m2153a() || C0429i.m1493a(xVar.f1326a, obj)) {
                    return C0680m.f1274a;
                }
                throw new AssertionError();
            }
        } while (!C0440c.m1537a(f1269k, this, obj3, m2098J((C0633b2) obj3, obj, this.f1299f, lVar, obj2)));
        m2105t();
        return C0680m.f1274a;
    }

    /* renamed from: M */
    private final boolean m2101M() {
        do {
            int i = this._decision;
            if (i != 0) {
                if (i == 2) {
                    return false;
                }
                throw new IllegalStateException("Already suspended".toString());
            }
        } while (!f1268j.compareAndSet(this, 0, 1));
        return true;
    }

    /* renamed from: i */
    private final Void m2102i(Object obj) {
        throw new IllegalStateException(C0429i.m1501i("Already resumed, but proposed with update ", obj).toString());
    }

    /* renamed from: j */
    private final void m2103j(C0543l<? super Throwable, C0141q> lVar, Throwable th) {
        try {
            lVar.invoke(th);
        } catch (Throwable th2) {
            C0659h0.m2067a(getContext(), new C0631b0(C0429i.m1501i("Exception in invokeOnCancellation handler for ", this), th2));
        }
    }

    /* renamed from: q */
    private final boolean m2104q(Throwable th) {
        if (!m2092A()) {
            return false;
        }
        return ((C0451g) this.f1270g).mo1380o(th);
    }

    /* renamed from: t */
    private final void m2105t() {
        if (!m2092A()) {
            mo1629s();
        }
    }

    /* renamed from: u */
    private final void m2106u(int i) {
        if (!m2099K()) {
            C0708u0.m2193a(this, i);
        }
    }

    /* renamed from: y */
    private final String m2107y() {
        Object x = mo1633x();
        return x instanceof C0633b2 ? "Active" : x instanceof C0687o ? "Cancelled" : "Completed";
    }

    /* renamed from: z */
    private final C0720x0 m2108z() {
        C0689o1 o1Var = (C0689o1) getContext().get(C0689o1.f1285c);
        if (o1Var == null) {
            return null;
        }
        C0720x0 d = C0689o1.C0690a.m2149d(o1Var, true, false, new C0692p(this), 2, (Object) null);
        this.f1272i = d;
        return d;
    }

    /* access modifiers changed from: protected */
    /* renamed from: D */
    public String mo1621D() {
        return "CancellableContinuation";
    }

    /* renamed from: E */
    public final void mo1622E(Throwable th) {
        if (!m2104q(th)) {
            mo1628o(th);
            m2105t();
        }
    }

    /* renamed from: G */
    public final boolean mo1623G() {
        if (C0693p0.m2153a()) {
            if (!(this.f1299f == 2)) {
                throw new AssertionError();
            }
        }
        if (C0693p0.m2153a()) {
            if (!(this.f1272i != C0629a2.f1241d)) {
                throw new AssertionError();
            }
        }
        Object obj = this._state;
        if (C0693p0.m2153a() && !(!(obj instanceof C0633b2))) {
            throw new AssertionError();
        } else if (!(obj instanceof C0719x) || ((C0719x) obj).f1329d == null) {
            this._decision = 0;
            this._state = C0638d.f1243d;
            return true;
        } else {
            mo1629s();
            return false;
        }
    }

    /* renamed from: a */
    public void mo1374a(Object obj, Throwable th) {
        while (true) {
            Object obj2 = this._state;
            if (obj2 instanceof C0633b2) {
                throw new IllegalStateException("Not completed".toString());
            } else if (!(obj2 instanceof C0722y)) {
                if (obj2 instanceof C0719x) {
                    C0719x xVar = (C0719x) obj2;
                    if (!xVar.mo1688c()) {
                        if (C0440c.m1537a(f1269k, this, obj2, C0719x.m2299b(xVar, (Object) null, (C0662i) null, (C0543l) null, (Object) null, th, 15, (Object) null))) {
                            xVar.mo1689d(this, th);
                            return;
                        }
                    } else {
                        throw new IllegalStateException("Must be called at most once".toString());
                    }
                } else if (C0440c.m1537a(f1269k, this, obj2, new C0719x(obj2, (C0662i) null, (C0543l) null, (Object) null, th, 14, (C0425e) null))) {
                    return;
                }
            } else {
                return;
            }
        }
    }

    /* renamed from: b */
    public final C0190d<T> mo1375b() {
        return this.f1270g;
    }

    /* renamed from: c */
    public void mo1611c(C0543l<? super Throwable, C0141q> lVar) {
        C0662i B = m2093B(lVar);
        while (true) {
            Object obj = this._state;
            if (obj instanceof C0638d) {
                if (C0440c.m1537a(f1269k, this, obj, B)) {
                    return;
                }
            } else if (obj instanceof C0662i) {
                m2094C(lVar, obj);
            } else {
                boolean z = obj instanceof C0722y;
                if (z) {
                    C0722y yVar = (C0722y) obj;
                    if (!yVar.mo1694b()) {
                        m2094C(lVar, obj);
                    }
                    if (obj instanceof C0687o) {
                        Throwable th = null;
                        if (!z) {
                            yVar = null;
                        }
                        if (yVar != null) {
                            th = yVar.f1333a;
                        }
                        m2103j(lVar, th);
                        return;
                    }
                    return;
                } else if (obj instanceof C0719x) {
                    C0719x xVar = (C0719x) obj;
                    if (xVar.f1327b != null) {
                        m2094C(lVar, obj);
                    }
                    if (!(B instanceof C0642e)) {
                        if (xVar.mo1688c()) {
                            m2103j(lVar, xVar.f1330e);
                            return;
                        }
                        if (C0440c.m1537a(f1269k, this, obj, C0719x.m2299b(xVar, (Object) null, B, (C0543l) null, (Object) null, (Throwable) null, 29, (Object) null))) {
                            return;
                        }
                    } else {
                        return;
                    }
                } else if (!(B instanceof C0642e)) {
                    if (C0440c.m1537a(f1269k, this, obj, new C0719x(obj, B, (C0543l) null, (Object) null, (Throwable) null, 28, (C0425e) null))) {
                        return;
                    }
                } else {
                    return;
                }
            }
        }
    }

    /* renamed from: d */
    public Throwable mo1624d(Object obj) {
        Throwable d = super.mo1624d(obj);
        if (d == null) {
            return null;
        }
        C0190d b = mo1375b();
        return (!C0693p0.m2156d() || !(b instanceof C0411e)) ? d : C0483y.m1681j(d, (C0411e) b);
    }

    /* renamed from: e */
    public <T> T mo1625e(Object obj) {
        return obj instanceof C0719x ? ((C0719x) obj).f1326a : obj;
    }

    /* renamed from: g */
    public Object mo1612g(T t, Object obj) {
        return m2100L(t, obj, (C0543l<? super Throwable, C0141q>) null);
    }

    public C0411e getCallerFrame() {
        C0190d<T> dVar = this.f1270g;
        if (dVar instanceof C0411e) {
            return (C0411e) dVar;
        }
        return null;
    }

    public C0195g getContext() {
        return this.f1271h;
    }

    public StackTraceElement getStackTraceElement() {
        return null;
    }

    /* renamed from: h */
    public Object mo1376h() {
        return mo1633x();
    }

    /* renamed from: k */
    public final void mo1626k(C0662i iVar, Throwable th) {
        try {
            iVar.mo1604a(th);
        } catch (Throwable th2) {
            C0659h0.m2067a(getContext(), new C0631b0(C0429i.m1501i("Exception in invokeOnCancellation handler for ", this), th2));
        }
    }

    /* renamed from: l */
    public final void mo1627l(C0543l<? super Throwable, C0141q> lVar, Throwable th) {
        try {
            lVar.invoke(th);
        } catch (Throwable th2) {
            C0659h0.m2067a(getContext(), new C0631b0(C0429i.m1501i("Exception in resume onCancellation handler for ", this), th2));
        }
    }

    /* renamed from: m */
    public Object mo1613m(Throwable th) {
        return m2100L(new C0722y(th, false, 2, (C0425e) null), (Object) null, (C0543l<? super Throwable, C0141q>) null);
    }

    /* renamed from: n */
    public Object mo1614n(T t, Object obj, C0543l<? super Throwable, C0141q> lVar) {
        return m2100L(t, obj, lVar);
    }

    /* renamed from: o */
    public boolean mo1628o(Throwable th) {
        Object obj;
        boolean z;
        do {
            obj = this._state;
            if (!(obj instanceof C0633b2)) {
                return false;
            }
            z = obj instanceof C0662i;
        } while (!C0440c.m1537a(f1269k, this, obj, new C0687o(this, th, z)));
        C0662i iVar = z ? (C0662i) obj : null;
        if (iVar != null) {
            mo1626k(iVar, th);
        }
        m2105t();
        m2106u(this.f1299f);
        return true;
    }

    /* renamed from: p */
    public void mo1615p(Object obj) {
        if (C0693p0.m2153a()) {
            if (!(obj == C0680m.f1274a)) {
                throw new AssertionError();
            }
        }
        m2106u(this.f1299f);
    }

    /* renamed from: r */
    public void mo1616r(T t, C0543l<? super Throwable, C0141q> lVar) {
        m2096H(t, this.f1299f, lVar);
    }

    public void resumeWith(Object obj) {
        m2097I(this, C0635c0.m2031c(obj, this), this.f1299f, (C0543l) null, 4, (Object) null);
    }

    /* renamed from: s */
    public final void mo1629s() {
        C0720x0 x0Var = this.f1272i;
        if (x0Var != null) {
            x0Var.mo1572b();
            this.f1272i = C0629a2.f1241d;
        }
    }

    public String toString() {
        return mo1621D() + '(' + C0696q0.m2162c(this.f1270g) + "){" + m2107y() + "}@" + C0696q0.m2161b(this);
    }

    /* renamed from: v */
    public Throwable mo1631v(C0689o1 o1Var) {
        return o1Var.mo1639h();
    }

    /* renamed from: w */
    public final Object mo1632w() {
        C0689o1 o1Var;
        boolean A = m2092A();
        if (m2101M()) {
            if (this.f1272i == null) {
                m2108z();
            }
            if (A) {
                m2095F();
            }
            return C0210d.m564c();
        }
        if (A) {
            m2095F();
        }
        Object x = mo1633x();
        if (x instanceof C0722y) {
            Throwable th = ((C0722y) x).f1333a;
            if (C0693p0.m2156d()) {
                th = C0483y.m1681j(th, this);
            }
            throw th;
        } else if (!C0708u0.m2194b(this.f1299f) || (o1Var = (C0689o1) getContext().get(C0689o1.f1285c)) == null || o1Var.mo1559a()) {
            return mo1625e(x);
        } else {
            Throwable h = o1Var.mo1639h();
            mo1374a(x, h);
            if (C0693p0.m2156d()) {
                h = C0483y.m1681j(h, this);
            }
            throw h;
        }
    }

    /* renamed from: x */
    public final Object mo1633x() {
        return this._state;
    }
}
