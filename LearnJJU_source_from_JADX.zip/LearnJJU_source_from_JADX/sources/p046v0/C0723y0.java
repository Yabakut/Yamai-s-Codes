package p046v0;

/* renamed from: v0.y0 */
final class C0723y0 implements C0669j1 {

    /* renamed from: d */
    private final boolean f1334d;

    public C0723y0(boolean z) {
        this.f1334d = z;
    }

    /* renamed from: a */
    public boolean mo1601a() {
        return this.f1334d;
    }

    /* renamed from: c */
    public C0727z1 mo1602c() {
        return null;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Empty{");
        sb.append(mo1601a() ? "Active" : "New");
        sb.append('}');
        return sb.toString();
    }
}
