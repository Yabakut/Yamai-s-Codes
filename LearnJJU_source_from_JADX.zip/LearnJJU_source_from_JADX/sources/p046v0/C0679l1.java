package p046v0;

import p011e0.C0141q;
import p032o0.C0543l;

/* renamed from: v0.l1 */
final class C0679l1 extends C0662i {

    /* renamed from: d */
    private final C0543l<Throwable, C0141q> f1273d;

    public C0679l1(C0543l<? super Throwable, C0141q> lVar) {
        this.f1273d = lVar;
    }

    /* renamed from: a */
    public void mo1604a(Throwable th) {
        this.f1273d.invoke(th);
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        mo1604a((Throwable) obj);
        return C0141q.f277a;
    }

    public String toString() {
        return "InvokeOnCancel[" + C0696q0.m2160a(this.f1273d) + '@' + C0696q0.m2161b(this) + ']';
    }
}
