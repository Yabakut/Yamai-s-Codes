package p046v0;

import kotlinx.coroutines.internal.C0443d0;
import kotlinx.coroutines.internal.C0451g;
import p011e0.C0133k;
import p011e0.C0136l;
import p011e0.C0141q;
import p017h0.C0190d;
import p017h0.C0195g;

/* renamed from: v0.u0 */
public final class C0708u0 {
    /* renamed from: a */
    public static final <T> void m2193a(C0705t0<? super T> t0Var, int i) {
        boolean z = true;
        if (C0693p0.m2153a()) {
            if (!(i != -1)) {
                throw new AssertionError();
            }
        }
        C0190d<? super T> b = t0Var.mo1375b();
        if (i != 4) {
            z = false;
        }
        if (z || !(b instanceof C0451g) || m2194b(i) != m2194b(t0Var.f1299f)) {
            m2196d(t0Var, b, z);
            return;
        }
        C0647f0 f0Var = ((C0451g) b).f1005g;
        C0195g context = b.getContext();
        if (f0Var.mo1423n(context)) {
            f0Var.mo1422m(context, t0Var);
        } else {
            m2197e(t0Var);
        }
    }

    /* renamed from: b */
    public static final boolean m2194b(int i) {
        return i == 1 || i == 2;
    }

    /* renamed from: c */
    public static final boolean m2195c(int i) {
        return i == 2;
    }

    /* renamed from: d */
    public static final <T> void m2196d(C0705t0<? super T> t0Var, C0190d<? super T> dVar, boolean z) {
        Object obj;
        Object h = t0Var.mo1376h();
        Throwable d = t0Var.mo1624d(h);
        if (d != null) {
            C0133k.C0134a aVar = C0133k.f271d;
            obj = C0136l.m421a(d);
        } else {
            C0133k.C0134a aVar2 = C0133k.f271d;
            obj = t0Var.mo1625e(h);
        }
        Object a = C0133k.m417a(obj);
        if (z) {
            C0451g gVar = (C0451g) dVar;
            C0190d<T> dVar2 = gVar.f1006h;
            Object obj2 = gVar.f1008j;
            C0195g context = dVar2.getContext();
            Object c = C0443d0.m1551c(context, obj2);
            C0661h2<?> e = c != C0443d0.f994a ? C0643e0.m2043e(dVar2, context, c) : null;
            try {
                gVar.f1006h.resumeWith(a);
                C0141q qVar = C0141q.f277a;
            } finally {
                if (e == null || e.mo1599y0()) {
                    C0443d0.m1549a(context, c);
                }
            }
        } else {
            dVar.resumeWith(a);
        }
    }

    /* renamed from: e */
    private static final void m2197e(C0705t0<?> t0Var) {
        C0726z0 a = C0653f2.f1252a.mo1592a();
        if (a.mo1704w()) {
            a.mo1702r(t0Var);
            return;
        }
        a.mo1703u(true);
        try {
            m2196d(t0Var, t0Var.mo1375b(), true);
            do {
            } while (a.mo1706y());
        } catch (Throwable th) {
            a.mo1701p(true);
            throw th;
        }
        a.mo1701p(true);
    }
}
