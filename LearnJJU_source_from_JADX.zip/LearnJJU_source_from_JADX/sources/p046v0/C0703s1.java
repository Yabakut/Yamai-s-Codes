package p046v0;

import java.util.concurrent.CancellationException;
import p017h0.C0195g;

/* renamed from: v0.s1 */
public final class C0703s1 {
    /* renamed from: a */
    public static final C0716w m2177a(C0689o1 o1Var) {
        return C0706t1.m2188a(o1Var);
    }

    /* renamed from: c */
    public static final void m2179c(C0195g gVar, CancellationException cancellationException) {
        C0706t1.m2190c(gVar, cancellationException);
    }

    /* renamed from: d */
    public static final void m2180d(C0195g gVar) {
        C0706t1.m2191d(gVar);
    }

    /* renamed from: e */
    public static final void m2181e(C0689o1 o1Var) {
        C0706t1.m2192e(o1Var);
    }
}
