package p046v0;

import kotlin.jvm.internal.C0429i;
import kotlinx.coroutines.scheduling.C0497i;
import p017h0.C0190d;

/* renamed from: v0.t0 */
public abstract class C0705t0<T> extends C0497i {

    /* renamed from: f */
    public int f1299f;

    public C0705t0(int i) {
        this.f1299f = i;
    }

    /* renamed from: a */
    public void mo1374a(Object obj, Throwable th) {
    }

    /* renamed from: b */
    public abstract C0190d<T> mo1375b();

    /* renamed from: d */
    public Throwable mo1624d(Object obj) {
        C0722y yVar = obj instanceof C0722y ? (C0722y) obj : null;
        if (yVar == null) {
            return null;
        }
        return yVar.f1333a;
    }

    /* renamed from: e */
    public <T> T mo1625e(Object obj) {
        return obj;
    }

    /* renamed from: f */
    public final void mo1653f(Throwable th, Throwable th2) {
        if (th != null || th2 != null) {
            if (!(th == null || th2 == null)) {
                C0124b.m410a(th, th2);
            }
            if (th == null) {
                th = th2;
            }
            C0429i.m1494b(th);
            C0659h0.m2067a(mo1375b().getContext(), new C0688o0("Fatal exception in coroutines machinery for " + this + ". Please read KDoc to 'handleFatalException' method and report this incident to maintainers", th));
        }
    }

    /* renamed from: h */
    public abstract Object mo1376h();

    /* JADX WARNING: Code restructure failed: missing block: B:40:0x00a5, code lost:
        if (r4.mo1599y0() != false) goto L_0x00a7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x00ce, code lost:
        if (r4.mo1599y0() != false) goto L_0x00d0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
            r10 = this;
            boolean r0 = p046v0.C0693p0.m2153a()
            if (r0 == 0) goto L_0x0017
            int r0 = r10.f1299f
            r1 = -1
            if (r0 == r1) goto L_0x000d
            r0 = 1
            goto L_0x000e
        L_0x000d:
            r0 = 0
        L_0x000e:
            if (r0 == 0) goto L_0x0011
            goto L_0x0017
        L_0x0011:
            java.lang.AssertionError r0 = new java.lang.AssertionError
            r0.<init>()
            throw r0
        L_0x0017:
            kotlinx.coroutines.scheduling.j r0 = r10.f1101e
            h0.d r1 = r10.mo1375b()     // Catch:{ all -> 0x00d4 }
            kotlinx.coroutines.internal.g r1 = (kotlinx.coroutines.internal.C0451g) r1     // Catch:{ all -> 0x00d4 }
            h0.d<T> r2 = r1.f1006h     // Catch:{ all -> 0x00d4 }
            java.lang.Object r1 = r1.f1008j     // Catch:{ all -> 0x00d4 }
            h0.g r3 = r2.getContext()     // Catch:{ all -> 0x00d4 }
            java.lang.Object r1 = kotlinx.coroutines.internal.C0443d0.m1551c(r3, r1)     // Catch:{ all -> 0x00d4 }
            kotlinx.coroutines.internal.z r4 = kotlinx.coroutines.internal.C0443d0.f994a     // Catch:{ all -> 0x00d4 }
            r5 = 0
            if (r1 == r4) goto L_0x0035
            v0.h2 r4 = p046v0.C0643e0.m2043e(r2, r3, r1)     // Catch:{ all -> 0x00d4 }
            goto L_0x0036
        L_0x0035:
            r4 = r5
        L_0x0036:
            h0.g r6 = r2.getContext()     // Catch:{ all -> 0x00c7 }
            java.lang.Object r7 = r10.mo1376h()     // Catch:{ all -> 0x00c7 }
            java.lang.Throwable r8 = r10.mo1624d(r7)     // Catch:{ all -> 0x00c7 }
            if (r8 != 0) goto L_0x0055
            int r9 = r10.f1299f     // Catch:{ all -> 0x00c7 }
            boolean r9 = p046v0.C0708u0.m2194b(r9)     // Catch:{ all -> 0x00c7 }
            if (r9 == 0) goto L_0x0055
            v0.o1$b r9 = p046v0.C0689o1.f1285c     // Catch:{ all -> 0x00c7 }
            h0.g$b r6 = r6.get(r9)     // Catch:{ all -> 0x00c7 }
            v0.o1 r6 = (p046v0.C0689o1) r6     // Catch:{ all -> 0x00c7 }
            goto L_0x0056
        L_0x0055:
            r6 = r5
        L_0x0056:
            if (r6 == 0) goto L_0x0085
            boolean r9 = r6.mo1559a()     // Catch:{ all -> 0x00c7 }
            if (r9 != 0) goto L_0x0085
            java.util.concurrent.CancellationException r6 = r6.mo1639h()     // Catch:{ all -> 0x00c7 }
            r10.mo1374a(r7, r6)     // Catch:{ all -> 0x00c7 }
            e0.k$a r7 = p011e0.C0133k.f271d     // Catch:{ all -> 0x00c7 }
            boolean r7 = p046v0.C0693p0.m2156d()     // Catch:{ all -> 0x00c7 }
            if (r7 == 0) goto L_0x0079
            boolean r7 = r2 instanceof kotlin.coroutines.jvm.internal.C0411e     // Catch:{ all -> 0x00c7 }
            if (r7 != 0) goto L_0x0072
            goto L_0x0079
        L_0x0072:
            r7 = r2
            kotlin.coroutines.jvm.internal.e r7 = (kotlin.coroutines.jvm.internal.C0411e) r7     // Catch:{ all -> 0x00c7 }
            java.lang.Throwable r6 = kotlinx.coroutines.internal.C0483y.m1681j(r6, r7)     // Catch:{ all -> 0x00c7 }
        L_0x0079:
            java.lang.Object r6 = p011e0.C0136l.m421a(r6)     // Catch:{ all -> 0x00c7 }
            java.lang.Object r6 = p011e0.C0133k.m417a(r6)     // Catch:{ all -> 0x00c7 }
        L_0x0081:
            r2.resumeWith(r6)     // Catch:{ all -> 0x00c7 }
            goto L_0x009d
        L_0x0085:
            if (r8 == 0) goto L_0x0092
            e0.k$a r6 = p011e0.C0133k.f271d     // Catch:{ all -> 0x00c7 }
            java.lang.Object r6 = p011e0.C0136l.m421a(r8)     // Catch:{ all -> 0x00c7 }
            java.lang.Object r6 = p011e0.C0133k.m417a(r6)     // Catch:{ all -> 0x00c7 }
            goto L_0x0081
        L_0x0092:
            java.lang.Object r6 = r10.mo1625e(r7)     // Catch:{ all -> 0x00c7 }
            e0.k$a r7 = p011e0.C0133k.f271d     // Catch:{ all -> 0x00c7 }
            java.lang.Object r6 = p011e0.C0133k.m417a(r6)     // Catch:{ all -> 0x00c7 }
            goto L_0x0081
        L_0x009d:
            e0.q r2 = p011e0.C0141q.f277a     // Catch:{ all -> 0x00c7 }
            if (r4 == 0) goto L_0x00a7
            boolean r4 = r4.mo1599y0()     // Catch:{ all -> 0x00d4 }
            if (r4 == 0) goto L_0x00aa
        L_0x00a7:
            kotlinx.coroutines.internal.C0443d0.m1549a(r3, r1)     // Catch:{ all -> 0x00d4 }
        L_0x00aa:
            e0.k$a r1 = p011e0.C0133k.f271d     // Catch:{ all -> 0x00b4 }
            r0.mo1461g()     // Catch:{ all -> 0x00b4 }
            java.lang.Object r0 = p011e0.C0133k.m417a(r2)     // Catch:{ all -> 0x00b4 }
            goto L_0x00bf
        L_0x00b4:
            r0 = move-exception
            e0.k$a r1 = p011e0.C0133k.f271d
            java.lang.Object r0 = p011e0.C0136l.m421a(r0)
            java.lang.Object r0 = p011e0.C0133k.m417a(r0)
        L_0x00bf:
            java.lang.Throwable r0 = p011e0.C0133k.m418b(r0)
            r10.mo1653f(r5, r0)
            goto L_0x00f3
        L_0x00c7:
            r2 = move-exception
            if (r4 == 0) goto L_0x00d0
            boolean r4 = r4.mo1599y0()     // Catch:{ all -> 0x00d4 }
            if (r4 == 0) goto L_0x00d3
        L_0x00d0:
            kotlinx.coroutines.internal.C0443d0.m1549a(r3, r1)     // Catch:{ all -> 0x00d4 }
        L_0x00d3:
            throw r2     // Catch:{ all -> 0x00d4 }
        L_0x00d4:
            r1 = move-exception
            e0.k$a r2 = p011e0.C0133k.f271d     // Catch:{ all -> 0x00e1 }
            r0.mo1461g()     // Catch:{ all -> 0x00e1 }
            e0.q r0 = p011e0.C0141q.f277a     // Catch:{ all -> 0x00e1 }
            java.lang.Object r0 = p011e0.C0133k.m417a(r0)     // Catch:{ all -> 0x00e1 }
            goto L_0x00ec
        L_0x00e1:
            r0 = move-exception
            e0.k$a r2 = p011e0.C0133k.f271d
            java.lang.Object r0 = p011e0.C0136l.m421a(r0)
            java.lang.Object r0 = p011e0.C0133k.m417a(r0)
        L_0x00ec:
            java.lang.Throwable r0 = p011e0.C0133k.m418b(r0)
            r10.mo1653f(r1, r0)
        L_0x00f3:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p046v0.C0705t0.run():void");
    }
}
