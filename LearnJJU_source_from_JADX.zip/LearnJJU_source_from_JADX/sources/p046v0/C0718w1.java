package p046v0;

import kotlinx.coroutines.internal.C0484z;

/* renamed from: v0.w1 */
public final class C0718w1 {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public static final C0484z f1319a = new C0484z("COMPLETING_ALREADY");

    /* renamed from: b */
    public static final C0484z f1320b = new C0484z("COMPLETING_WAITING_CHILDREN");
    /* access modifiers changed from: private */

    /* renamed from: c */
    public static final C0484z f1321c = new C0484z("COMPLETING_RETRY");
    /* access modifiers changed from: private */

    /* renamed from: d */
    public static final C0484z f1322d = new C0484z("TOO_LATE_TO_CANCEL");
    /* access modifiers changed from: private */

    /* renamed from: e */
    public static final C0484z f1323e = new C0484z("SEALED");
    /* access modifiers changed from: private */

    /* renamed from: f */
    public static final C0723y0 f1324f = new C0723y0(false);
    /* access modifiers changed from: private */

    /* renamed from: g */
    public static final C0723y0 f1325g = new C0723y0(true);

    /* renamed from: g */
    public static final Object m2298g(Object obj) {
        return obj instanceof C0669j1 ? new C0676k1((C0669j1) obj) : obj;
    }
}
