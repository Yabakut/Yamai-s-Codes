package p046v0;

/* renamed from: v0.w */
public interface C0716w extends C0689o1 {
}
