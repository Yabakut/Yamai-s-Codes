package p046v0;

import p011e0.C0141q;

/* renamed from: v0.r */
public final class C0698r extends C0697q1 implements C0695q {

    /* renamed from: h */
    public final C0701s f1293h;

    public C0698r(C0701s sVar) {
        this.f1293h = sVar;
    }

    /* renamed from: g */
    public boolean mo1578g(Throwable th) {
        return mo1657z().mo1662D(th);
    }

    public C0689o1 getParent() {
        return mo1657z();
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        mo1564y((Throwable) obj);
        return C0141q.f277a;
    }

    /* renamed from: y */
    public void mo1564y(Throwable th) {
        this.f1293h.mo1651f(mo1657z());
    }
}
