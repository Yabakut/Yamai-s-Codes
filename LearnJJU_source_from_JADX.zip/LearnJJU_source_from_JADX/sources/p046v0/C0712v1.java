package p046v0;

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0429i;
import kotlinx.coroutines.internal.C0440c;
import kotlinx.coroutines.internal.C0467n;
import kotlinx.coroutines.internal.C0468o;
import kotlinx.coroutines.internal.C0480v;
import kotlinx.coroutines.internal.C0483y;
import p011e0.C0141q;
import p017h0.C0195g;
import p032o0.C0543l;
import p032o0.C0547p;
import p046v0.C0689o1;

/* renamed from: v0.v1 */
public class C0712v1 implements C0689o1, C0701s, C0637c2 {

    /* renamed from: d */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f1306d = AtomicReferenceFieldUpdater.newUpdater(C0712v1.class, Object.class, "_state");
    private volatile /* synthetic */ Object _parentHandle;
    private volatile /* synthetic */ Object _state;

    /* renamed from: v0.v1$a */
    private static final class C0713a extends C0709u1 {

        /* renamed from: h */
        private final C0712v1 f1307h;

        /* renamed from: i */
        private final C0714b f1308i;

        /* renamed from: j */
        private final C0698r f1309j;

        /* renamed from: k */
        private final Object f1310k;

        public C0713a(C0712v1 v1Var, C0714b bVar, C0698r rVar, Object obj) {
            this.f1307h = v1Var;
            this.f1308i = bVar;
            this.f1309j = rVar;
            this.f1310k = obj;
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            mo1564y((Throwable) obj);
            return C0141q.f277a;
        }

        /* renamed from: y */
        public void mo1564y(Throwable th) {
            this.f1307h.m2216F(this.f1308i, this.f1309j, this.f1310k);
        }
    }

    /* renamed from: v0.v1$b */
    private static final class C0714b implements C0669j1 {
        private volatile /* synthetic */ Object _exceptionsHolder = null;
        private volatile /* synthetic */ int _isCompleting;
        private volatile /* synthetic */ Object _rootCause;

        /* renamed from: d */
        private final C0727z1 f1311d;

        public C0714b(C0727z1 z1Var, boolean z, Throwable th) {
            this.f1311d = z1Var;
            this._isCompleting = z ? 1 : 0;
            this._rootCause = th;
        }

        /* renamed from: d */
        private final ArrayList<Throwable> m2274d() {
            return new ArrayList<>(4);
        }

        /* renamed from: e */
        private final Object m2275e() {
            return this._exceptionsHolder;
        }

        /* renamed from: l */
        private final void m2276l(Object obj) {
            this._exceptionsHolder = obj;
        }

        /* renamed from: a */
        public boolean mo1601a() {
            return mo1678f() == null;
        }

        /* renamed from: b */
        public final void mo1677b(Throwable th) {
            Throwable f = mo1678f();
            if (f == null) {
                mo1684m(th);
            } else if (th != f) {
                Object e = m2275e();
                if (e == null) {
                    m2276l(th);
                } else if (e instanceof Throwable) {
                    if (th != e) {
                        ArrayList<Throwable> d = m2274d();
                        d.add(e);
                        d.add(th);
                        C0141q qVar = C0141q.f277a;
                        m2276l(d);
                    }
                } else if (e instanceof ArrayList) {
                    ((ArrayList) e).add(th);
                } else {
                    throw new IllegalStateException(C0429i.m1501i("State is ", e).toString());
                }
            }
        }

        /* renamed from: c */
        public C0727z1 mo1602c() {
            return this.f1311d;
        }

        /* renamed from: f */
        public final Throwable mo1678f() {
            return (Throwable) this._rootCause;
        }

        /* renamed from: g */
        public final boolean mo1679g() {
            return mo1678f() != null;
        }

        /* JADX WARNING: type inference failed for: r0v0, types: [int, boolean] */
        /* renamed from: h */
        public final boolean mo1680h() {
            return this._isCompleting;
        }

        /* renamed from: i */
        public final boolean mo1681i() {
            return m2275e() == C0718w1.f1323e;
        }

        /* renamed from: j */
        public final List<Throwable> mo1682j(Throwable th) {
            ArrayList<Throwable> arrayList;
            Object e = m2275e();
            if (e == null) {
                arrayList = m2274d();
            } else if (e instanceof Throwable) {
                ArrayList<Throwable> d = m2274d();
                d.add(e);
                arrayList = d;
            } else if (e instanceof ArrayList) {
                arrayList = (ArrayList) e;
            } else {
                throw new IllegalStateException(C0429i.m1501i("State is ", e).toString());
            }
            Throwable f = mo1678f();
            if (f != null) {
                arrayList.add(0, f);
            }
            if (th != null && !C0429i.m1493a(th, f)) {
                arrayList.add(th);
            }
            m2276l(C0718w1.f1323e);
            return arrayList;
        }

        /* renamed from: k */
        public final void mo1683k(boolean z) {
            this._isCompleting = z ? 1 : 0;
        }

        /* renamed from: m */
        public final void mo1684m(Throwable th) {
            this._rootCause = th;
        }

        public String toString() {
            return "Finishing[cancelling=" + mo1679g() + ", completing=" + mo1680h() + ", rootCause=" + mo1678f() + ", exceptions=" + m2275e() + ", list=" + mo1602c() + ']';
        }
    }

    /* renamed from: v0.v1$c */
    public static final class C0715c extends C0468o.C0469a {

        /* renamed from: d */
        final /* synthetic */ C0468o f1312d;

        /* renamed from: e */
        final /* synthetic */ C0712v1 f1313e;

        /* renamed from: f */
        final /* synthetic */ Object f1314f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0715c(C0468o oVar, C0712v1 v1Var, Object obj) {
            super(oVar);
            this.f1312d = oVar;
            this.f1313e = v1Var;
            this.f1314f = obj;
        }

        /* renamed from: i */
        public Object mo1356g(C0468o oVar) {
            if (this.f1313e.mo1664P() == this.f1314f) {
                return null;
            }
            return C0467n.m1611a();
        }
    }

    public C0712v1(boolean z) {
        this._state = z ? C0718w1.f1325g : C0718w1.f1324f;
        this._parentHandle = null;
    }

    /* renamed from: A */
    private final Object m2213A(Object obj) {
        Object q0;
        do {
            Object P = mo1664P();
            if (!(P instanceof C0669j1) || ((P instanceof C0714b) && ((C0714b) P).mo1680h())) {
                return C0718w1.f1319a;
            }
            q0 = m2235q0(P, new C0722y(m2217G(obj), false, 2, (C0425e) null));
        } while (q0 == C0718w1.f1321c);
        return q0;
    }

    /* renamed from: B */
    private final boolean m2214B(Throwable th) {
        if (mo1431U()) {
            return true;
        }
        boolean z = th instanceof CancellationException;
        C0695q O = mo1663O();
        return (O == null || O == C0629a2.f1241d) ? z : O.mo1578g(th) || z;
    }

    /* renamed from: E */
    private final void m2215E(C0669j1 j1Var, Object obj) {
        C0695q O = mo1663O();
        if (O != null) {
            O.mo1572b();
            mo1671i0(C0629a2.f1241d);
        }
        Throwable th = null;
        C0722y yVar = obj instanceof C0722y ? (C0722y) obj : null;
        if (yVar != null) {
            th = yVar.f1333a;
        }
        if (j1Var instanceof C0709u1) {
            try {
                ((C0709u1) j1Var).mo1564y(th);
            } catch (Throwable th2) {
                mo1557R(new C0631b0("Exception in completion handler " + j1Var + " for " + this, th2));
            }
        } else {
            C0727z1 c = j1Var.mo1602c();
            if (c != null) {
                m2227b0(c, th);
            }
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: F */
    public final void m2216F(C0714b bVar, C0698r rVar, Object obj) {
        if (C0693p0.m2153a()) {
            if (!(mo1664P() == bVar)) {
                throw new AssertionError();
            }
        }
        C0698r Z = m2225Z(rVar);
        if (Z == null || !m2237s0(bVar, Z, obj)) {
            mo1433x(m2218H(bVar, obj));
        }
    }

    /* renamed from: G */
    private final Throwable m2217G(Object obj) {
        if (obj == null ? true : obj instanceof Throwable) {
            Throwable th = (Throwable) obj;
            return th == null ? new C0694p1(mo1556C(), (Throwable) null, this) : th;
        } else if (obj != null) {
            return ((C0637c2) obj).mo1584e();
        } else {
            throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.ParentJob");
        }
    }

    /* renamed from: H */
    private final Object m2218H(C0714b bVar, Object obj) {
        boolean g;
        Throwable K;
        boolean z = true;
        if (C0693p0.m2153a()) {
            if (!(mo1664P() == bVar)) {
                throw new AssertionError();
            }
        }
        if (C0693p0.m2153a() && !(!bVar.mo1681i())) {
            throw new AssertionError();
        } else if (!C0693p0.m2153a() || bVar.mo1680h()) {
            C0722y yVar = obj instanceof C0722y ? (C0722y) obj : null;
            Throwable th = yVar == null ? null : yVar.f1333a;
            synchronized (bVar) {
                g = bVar.mo1679g();
                List<Throwable> j = bVar.mo1682j(th);
                K = m2221K(bVar, j);
                if (K != null) {
                    m2241w(K, j);
                }
            }
            if (!(K == null || K == th)) {
                obj = new C0722y(K, false, 2, (C0425e) null);
            }
            if (K != null) {
                if (!m2214B(K) && !mo1587Q(K)) {
                    z = false;
                }
                if (z) {
                    if (obj != null) {
                        ((C0722y) obj).mo1694b();
                    } else {
                        throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.CompletedExceptionally");
                    }
                }
            }
            if (!g) {
                mo1668c0(K);
            }
            mo1560d0(obj);
            boolean a = C0440c.m1537a(f1306d, this, bVar, C0718w1.m2298g(obj));
            if (!C0693p0.m2153a() || a) {
                m2215E(bVar, obj);
                return obj;
            }
            throw new AssertionError();
        } else {
            throw new AssertionError();
        }
    }

    /* renamed from: I */
    private final C0698r m2219I(C0669j1 j1Var) {
        C0698r rVar = j1Var instanceof C0698r ? (C0698r) j1Var : null;
        if (rVar != null) {
            return rVar;
        }
        C0727z1 c = j1Var.mo1602c();
        if (c == null) {
            return null;
        }
        return m2225Z(c);
    }

    /* renamed from: J */
    private final Throwable m2220J(Object obj) {
        C0722y yVar = obj instanceof C0722y ? (C0722y) obj : null;
        if (yVar == null) {
            return null;
        }
        return yVar.f1333a;
    }

    /* renamed from: K */
    private final Throwable m2221K(C0714b bVar, List<? extends Throwable> list) {
        T t = null;
        if (!list.isEmpty()) {
            Iterator<T> it = list.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                T next = it.next();
                if (!(((Throwable) next) instanceof CancellationException)) {
                    t = next;
                    break;
                }
            }
            Throwable th = (Throwable) t;
            return th != null ? th : (Throwable) list.get(0);
        } else if (bVar.mo1679g()) {
            return new C0694p1(mo1556C(), (Throwable) null, this);
        } else {
            return null;
        }
    }

    /* renamed from: N */
    private final C0727z1 m2222N(C0669j1 j1Var) {
        C0727z1 c = j1Var.mo1602c();
        if (c != null) {
            return c;
        }
        if (j1Var instanceof C0723y0) {
            return new C0727z1();
        }
        if (j1Var instanceof C0709u1) {
            m2229g0((C0709u1) j1Var);
            return null;
        }
        throw new IllegalStateException(C0429i.m1501i("State should have list: ", j1Var).toString());
    }

    /* JADX WARNING: Code restructure failed: missing block: B:24:0x003e, code lost:
        if (r0 != null) goto L_0x0041;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0041, code lost:
        m2226a0(((p046v0.C0712v1.C0714b) r2).mo1602c(), r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x004e, code lost:
        return p046v0.C0718w1.m2292a();
     */
    /* renamed from: V */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final java.lang.Object m2223V(java.lang.Object r7) {
        /*
            r6 = this;
            r0 = 0
            r1 = r0
        L_0x0002:
            java.lang.Object r2 = r6.mo1664P()
            boolean r3 = r2 instanceof p046v0.C0712v1.C0714b
            if (r3 == 0) goto L_0x0052
            monitor-enter(r2)
            r3 = r2
            v0.v1$b r3 = (p046v0.C0712v1.C0714b) r3     // Catch:{ all -> 0x004f }
            boolean r3 = r3.mo1681i()     // Catch:{ all -> 0x004f }
            if (r3 == 0) goto L_0x001a
            kotlinx.coroutines.internal.z r7 = p046v0.C0718w1.f1322d     // Catch:{ all -> 0x004f }
            monitor-exit(r2)
            return r7
        L_0x001a:
            r3 = r2
            v0.v1$b r3 = (p046v0.C0712v1.C0714b) r3     // Catch:{ all -> 0x004f }
            boolean r3 = r3.mo1679g()     // Catch:{ all -> 0x004f }
            if (r7 != 0) goto L_0x0025
            if (r3 != 0) goto L_0x0031
        L_0x0025:
            if (r1 != 0) goto L_0x002b
            java.lang.Throwable r1 = r6.m2217G(r7)     // Catch:{ all -> 0x004f }
        L_0x002b:
            r7 = r2
            v0.v1$b r7 = (p046v0.C0712v1.C0714b) r7     // Catch:{ all -> 0x004f }
            r7.mo1677b(r1)     // Catch:{ all -> 0x004f }
        L_0x0031:
            r7 = r2
            v0.v1$b r7 = (p046v0.C0712v1.C0714b) r7     // Catch:{ all -> 0x004f }
            java.lang.Throwable r7 = r7.mo1678f()     // Catch:{ all -> 0x004f }
            r1 = r3 ^ 1
            if (r1 == 0) goto L_0x003d
            r0 = r7
        L_0x003d:
            monitor-exit(r2)
            if (r0 != 0) goto L_0x0041
            goto L_0x004a
        L_0x0041:
            v0.v1$b r2 = (p046v0.C0712v1.C0714b) r2
            v0.z1 r7 = r2.mo1602c()
            r6.m2226a0(r7, r0)
        L_0x004a:
            kotlinx.coroutines.internal.z r7 = p046v0.C0718w1.f1319a
            return r7
        L_0x004f:
            r7 = move-exception
            monitor-exit(r2)
            throw r7
        L_0x0052:
            boolean r3 = r2 instanceof p046v0.C0669j1
            if (r3 == 0) goto L_0x009a
            if (r1 != 0) goto L_0x005c
            java.lang.Throwable r1 = r6.m2217G(r7)
        L_0x005c:
            r3 = r2
            v0.j1 r3 = (p046v0.C0669j1) r3
            boolean r4 = r3.mo1601a()
            if (r4 == 0) goto L_0x0070
            boolean r2 = r6.m2234p0(r3, r1)
            if (r2 == 0) goto L_0x0002
            kotlinx.coroutines.internal.z r7 = p046v0.C0718w1.f1319a
            return r7
        L_0x0070:
            v0.y r3 = new v0.y
            r4 = 0
            r5 = 2
            r3.<init>(r1, r4, r5, r0)
            java.lang.Object r3 = r6.m2235q0(r2, r3)
            kotlinx.coroutines.internal.z r4 = p046v0.C0718w1.f1319a
            if (r3 == r4) goto L_0x008a
            kotlinx.coroutines.internal.z r2 = p046v0.C0718w1.f1321c
            if (r3 != r2) goto L_0x0089
            goto L_0x0002
        L_0x0089:
            return r3
        L_0x008a:
            java.lang.String r7 = "Cannot happen in "
            java.lang.String r7 = kotlin.jvm.internal.C0429i.m1501i(r7, r2)
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r7 = r7.toString()
            r0.<init>(r7)
            throw r0
        L_0x009a:
            kotlinx.coroutines.internal.z r7 = p046v0.C0718w1.f1322d
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: p046v0.C0712v1.m2223V(java.lang.Object):java.lang.Object");
    }

    /* renamed from: X */
    private final C0709u1 m2224X(C0543l<? super Throwable, C0141q> lVar, boolean z) {
        C0709u1 u1Var = null;
        if (z) {
            if (lVar instanceof C0697q1) {
                u1Var = (C0697q1) lVar;
            }
            if (u1Var == null) {
                u1Var = new C0682m1(lVar);
            }
        } else {
            C0709u1 u1Var2 = lVar instanceof C0709u1 ? (C0709u1) lVar : null;
            if (u1Var2 != null) {
                if (!C0693p0.m2153a() || (!(u1Var2 instanceof C0697q1))) {
                    u1Var = u1Var2;
                } else {
                    throw new AssertionError();
                }
            }
            if (u1Var == null) {
                u1Var = new C0686n1(lVar);
            }
        }
        u1Var.mo1656A(this);
        return u1Var;
    }

    /* renamed from: Z */
    private final C0698r m2225Z(C0468o oVar) {
        while (oVar.mo1395t()) {
            oVar = oVar.mo1400q();
        }
        while (true) {
            oVar = oVar.mo1399p();
            if (!oVar.mo1395t()) {
                if (oVar instanceof C0698r) {
                    return (C0698r) oVar;
                }
                if (oVar instanceof C0727z1) {
                    return null;
                }
            }
        }
    }

    /* renamed from: a0 */
    private final void m2226a0(C0727z1 z1Var, Throwable th) {
        C0631b0 b0Var;
        mo1668c0(th);
        C0631b0 b0Var2 = null;
        for (C0468o oVar = (C0468o) z1Var.mo1398o(); !C0429i.m1493a(oVar, z1Var); oVar = oVar.mo1399p()) {
            if (oVar instanceof C0697q1) {
                C0709u1 u1Var = (C0709u1) oVar;
                try {
                    u1Var.mo1564y(th);
                } catch (Throwable th2) {
                    if (b0Var2 == null) {
                        b0Var = null;
                    } else {
                        C0124b.m410a(b0Var2, th2);
                        b0Var = b0Var2;
                    }
                    if (b0Var == null) {
                        b0Var2 = new C0631b0("Exception in completion handler " + u1Var + " for " + this, th2);
                    }
                }
            }
        }
        if (b0Var2 != null) {
            mo1557R(b0Var2);
        }
        m2214B(th);
    }

    /* renamed from: b0 */
    private final void m2227b0(C0727z1 z1Var, Throwable th) {
        C0631b0 b0Var;
        C0631b0 b0Var2 = null;
        for (C0468o oVar = (C0468o) z1Var.mo1398o(); !C0429i.m1493a(oVar, z1Var); oVar = oVar.mo1399p()) {
            if (oVar instanceof C0709u1) {
                C0709u1 u1Var = (C0709u1) oVar;
                try {
                    u1Var.mo1564y(th);
                } catch (Throwable th2) {
                    if (b0Var2 == null) {
                        b0Var = null;
                    } else {
                        C0124b.m410a(b0Var2, th2);
                        b0Var = b0Var2;
                    }
                    if (b0Var == null) {
                        b0Var2 = new C0631b0("Exception in completion handler " + u1Var + " for " + this, th2);
                    }
                }
            }
        }
        if (b0Var2 != null) {
            mo1557R(b0Var2);
        }
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [v0.i1] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* renamed from: f0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void m2228f0(p046v0.C0723y0 r3) {
        /*
            r2 = this;
            v0.z1 r0 = new v0.z1
            r0.<init>()
            boolean r1 = r3.mo1601a()
            if (r1 == 0) goto L_0x000c
            goto L_0x0012
        L_0x000c:
            v0.i1 r1 = new v0.i1
            r1.<init>(r0)
            r0 = r1
        L_0x0012:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r1 = f1306d
            kotlinx.coroutines.internal.C0440c.m1537a(r1, r2, r3, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p046v0.C0712v1.m2228f0(v0.y0):void");
    }

    /* renamed from: g0 */
    private final void m2229g0(C0709u1 u1Var) {
        u1Var.mo1397k(new C0727z1());
        C0440c.m1537a(f1306d, this, u1Var, u1Var.mo1399p());
    }

    /* renamed from: j0 */
    private final int m2230j0(Object obj) {
        if (obj instanceof C0723y0) {
            if (((C0723y0) obj).mo1601a()) {
                return 0;
            }
            if (!C0440c.m1537a(f1306d, this, obj, C0718w1.f1325g)) {
                return -1;
            }
            mo1669e0();
            return 1;
        } else if (!(obj instanceof C0664i1)) {
            return 0;
        } else {
            if (!C0440c.m1537a(f1306d, this, obj, ((C0664i1) obj).mo1602c())) {
                return -1;
            }
            mo1669e0();
            return 1;
        }
    }

    /* renamed from: k0 */
    private final String m2231k0(Object obj) {
        if (!(obj instanceof C0714b)) {
            return obj instanceof C0669j1 ? ((C0669j1) obj).mo1601a() ? "Active" : "New" : obj instanceof C0722y ? "Cancelled" : "Completed";
        }
        C0714b bVar = (C0714b) obj;
        return bVar.mo1679g() ? "Cancelling" : bVar.mo1680h() ? "Completing" : "Active";
    }

    /* renamed from: m0 */
    public static /* synthetic */ CancellationException m2232m0(C0712v1 v1Var, Throwable th, String str, int i, Object obj) {
        if (obj == null) {
            if ((i & 1) != 0) {
                str = null;
            }
            return v1Var.mo1672l0(th, str);
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: toCancellationException");
    }

    /* renamed from: o0 */
    private final boolean m2233o0(C0669j1 j1Var, Object obj) {
        if (C0693p0.m2153a()) {
            if (!((j1Var instanceof C0723y0) || (j1Var instanceof C0709u1))) {
                throw new AssertionError();
            }
        }
        if (C0693p0.m2153a() && !(!(obj instanceof C0722y))) {
            throw new AssertionError();
        } else if (!C0440c.m1537a(f1306d, this, j1Var, C0718w1.m2298g(obj))) {
            return false;
        } else {
            mo1668c0((Throwable) null);
            mo1560d0(obj);
            m2215E(j1Var, obj);
            return true;
        }
    }

    /* renamed from: p0 */
    private final boolean m2234p0(C0669j1 j1Var, Throwable th) {
        if (C0693p0.m2153a() && !(!(j1Var instanceof C0714b))) {
            throw new AssertionError();
        } else if (!C0693p0.m2153a() || j1Var.mo1601a()) {
            C0727z1 N = m2222N(j1Var);
            if (N == null) {
                return false;
            }
            if (!C0440c.m1537a(f1306d, this, j1Var, new C0714b(N, false, th))) {
                return false;
            }
            m2226a0(N, th);
            return true;
        } else {
            throw new AssertionError();
        }
    }

    /* renamed from: q0 */
    private final Object m2235q0(Object obj, Object obj2) {
        return !(obj instanceof C0669j1) ? C0718w1.f1319a : (((obj instanceof C0723y0) || (obj instanceof C0709u1)) && !(obj instanceof C0698r) && !(obj2 instanceof C0722y)) ? m2233o0((C0669j1) obj, obj2) ? obj2 : C0718w1.f1321c : m2236r0((C0669j1) obj, obj2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:46:0x0072, code lost:
        if (r2 != null) goto L_0x0075;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x0075, code lost:
        m2226a0(r0, r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x0078, code lost:
        r7 = m2219I(r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x007c, code lost:
        if (r7 == null) goto L_0x0087;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x0082, code lost:
        if (m2237s0(r1, r7, r8) == false) goto L_0x0087;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0086, code lost:
        return p046v0.C0718w1.f1320b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x008b, code lost:
        return m2218H(r1, r8);
     */
    /* renamed from: r0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final java.lang.Object m2236r0(p046v0.C0669j1 r7, java.lang.Object r8) {
        /*
            r6 = this;
            v0.z1 r0 = r6.m2222N(r7)
            if (r0 != 0) goto L_0x000b
            kotlinx.coroutines.internal.z r7 = p046v0.C0718w1.f1321c
            return r7
        L_0x000b:
            boolean r1 = r7 instanceof p046v0.C0712v1.C0714b
            r2 = 0
            if (r1 == 0) goto L_0x0014
            r1 = r7
            v0.v1$b r1 = (p046v0.C0712v1.C0714b) r1
            goto L_0x0015
        L_0x0014:
            r1 = r2
        L_0x0015:
            if (r1 != 0) goto L_0x001d
            v0.v1$b r1 = new v0.v1$b
            r3 = 0
            r1.<init>(r0, r3, r2)
        L_0x001d:
            monitor-enter(r1)
            boolean r3 = r1.mo1680h()     // Catch:{ all -> 0x008c }
            if (r3 == 0) goto L_0x002a
            kotlinx.coroutines.internal.z r7 = p046v0.C0718w1.f1319a     // Catch:{ all -> 0x008c }
            monitor-exit(r1)
            return r7
        L_0x002a:
            r3 = 1
            r1.mo1683k(r3)     // Catch:{ all -> 0x008c }
            if (r1 == r7) goto L_0x003e
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r4 = f1306d     // Catch:{ all -> 0x008c }
            boolean r4 = kotlinx.coroutines.internal.C0440c.m1537a(r4, r6, r7, r1)     // Catch:{ all -> 0x008c }
            if (r4 != 0) goto L_0x003e
            kotlinx.coroutines.internal.z r7 = p046v0.C0718w1.f1321c     // Catch:{ all -> 0x008c }
            monitor-exit(r1)
            return r7
        L_0x003e:
            boolean r4 = p046v0.C0693p0.m2153a()     // Catch:{ all -> 0x008c }
            if (r4 == 0) goto L_0x0052
            boolean r4 = r1.mo1681i()     // Catch:{ all -> 0x008c }
            r4 = r4 ^ r3
            if (r4 == 0) goto L_0x004c
            goto L_0x0052
        L_0x004c:
            java.lang.AssertionError r7 = new java.lang.AssertionError     // Catch:{ all -> 0x008c }
            r7.<init>()     // Catch:{ all -> 0x008c }
            throw r7     // Catch:{ all -> 0x008c }
        L_0x0052:
            boolean r4 = r1.mo1679g()     // Catch:{ all -> 0x008c }
            boolean r5 = r8 instanceof p046v0.C0722y     // Catch:{ all -> 0x008c }
            if (r5 == 0) goto L_0x005e
            r5 = r8
            v0.y r5 = (p046v0.C0722y) r5     // Catch:{ all -> 0x008c }
            goto L_0x005f
        L_0x005e:
            r5 = r2
        L_0x005f:
            if (r5 != 0) goto L_0x0062
            goto L_0x0067
        L_0x0062:
            java.lang.Throwable r5 = r5.f1333a     // Catch:{ all -> 0x008c }
            r1.mo1677b(r5)     // Catch:{ all -> 0x008c }
        L_0x0067:
            java.lang.Throwable r5 = r1.mo1678f()     // Catch:{ all -> 0x008c }
            r3 = r3 ^ r4
            if (r3 == 0) goto L_0x006f
            r2 = r5
        L_0x006f:
            e0.q r3 = p011e0.C0141q.f277a     // Catch:{ all -> 0x008c }
            monitor-exit(r1)
            if (r2 != 0) goto L_0x0075
            goto L_0x0078
        L_0x0075:
            r6.m2226a0(r0, r2)
        L_0x0078:
            v0.r r7 = r6.m2219I(r7)
            if (r7 == 0) goto L_0x0087
            boolean r7 = r6.m2237s0(r1, r7, r8)
            if (r7 == 0) goto L_0x0087
            kotlinx.coroutines.internal.z r7 = p046v0.C0718w1.f1320b
            return r7
        L_0x0087:
            java.lang.Object r7 = r6.m2218H(r1, r8)
            return r7
        L_0x008c:
            r7 = move-exception
            monitor-exit(r1)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: p046v0.C0712v1.m2236r0(v0.j1, java.lang.Object):java.lang.Object");
    }

    /* renamed from: s0 */
    private final boolean m2237s0(C0714b bVar, C0698r rVar, Object obj) {
        while (C0689o1.C0690a.m2149d(rVar.f1293h, false, false, new C0713a(this, bVar, rVar, obj), 1, (Object) null) == C0629a2.f1241d) {
            rVar = m2225Z(rVar);
            if (rVar == null) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: v */
    private final boolean m2240v(Object obj, C0727z1 z1Var, C0709u1 u1Var) {
        int x;
        C0715c cVar = new C0715c(u1Var, this, obj);
        do {
            x = z1Var.mo1400q().mo1406x(u1Var, z1Var, cVar);
            if (x == 1) {
                return true;
            }
        } while (x != 2);
        return false;
    }

    /* renamed from: w */
    private final void m2241w(Throwable th, List<? extends Throwable> list) {
        if (list.size() > 1) {
            Set newSetFromMap = Collections.newSetFromMap(new IdentityHashMap(list.size()));
            Throwable n = !C0693p0.m2156d() ? th : C0483y.m1685n(th);
            for (Throwable th2 : list) {
                if (C0693p0.m2156d()) {
                    th2 = C0483y.m1685n(th2);
                }
                if (th2 != th && th2 != n && !(th2 instanceof CancellationException) && newSetFromMap.add(th2)) {
                    C0124b.m410a(th, th2);
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: C */
    public String mo1556C() {
        return "Job was cancelled";
    }

    /* renamed from: D */
    public boolean mo1662D(Throwable th) {
        if (th instanceof CancellationException) {
            return true;
        }
        return mo1675y(th) && mo1649L();
    }

    /* renamed from: L */
    public boolean mo1649L() {
        return true;
    }

    /* renamed from: M */
    public boolean mo1650M() {
        return false;
    }

    /* renamed from: O */
    public final C0695q mo1663O() {
        return (C0695q) this._parentHandle;
    }

    /* renamed from: P */
    public final Object mo1664P() {
        while (true) {
            Object obj = this._state;
            if (!(obj instanceof C0480v)) {
                return obj;
            }
            ((C0480v) obj).mo1352c(this);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: Q */
    public boolean mo1587Q(Throwable th) {
        return false;
    }

    /* renamed from: R */
    public void mo1557R(Throwable th) {
        throw th;
    }

    /* access modifiers changed from: protected */
    /* renamed from: S */
    public final void mo1665S(C0689o1 o1Var) {
        if (C0693p0.m2153a()) {
            if (!(mo1663O() == null)) {
                throw new AssertionError();
            }
        }
        if (o1Var == null) {
            mo1671i0(C0629a2.f1241d);
            return;
        }
        o1Var.mo1640i();
        C0695q o = o1Var.mo1642o(this);
        mo1671i0(o);
        if (mo1666T()) {
            o.mo1572b();
            mo1671i0(C0629a2.f1241d);
        }
    }

    /* renamed from: T */
    public final boolean mo1666T() {
        return !(mo1664P() instanceof C0669j1);
    }

    /* access modifiers changed from: protected */
    /* renamed from: U */
    public boolean mo1431U() {
        return false;
    }

    /* renamed from: W */
    public final Object mo1667W(Object obj) {
        Object q0;
        do {
            q0 = m2235q0(mo1664P(), obj);
            if (q0 == C0718w1.f1319a) {
                throw new IllegalStateException("Job " + this + " is already complete or completing, but is being completed with " + obj, m2220J(obj));
            }
        } while (q0 == C0718w1.f1321c);
        return q0;
    }

    /* renamed from: Y */
    public String mo1558Y() {
        return C0696q0.m2160a(this);
    }

    /* renamed from: a */
    public boolean mo1559a() {
        Object P = mo1664P();
        return (P instanceof C0669j1) && ((C0669j1) P).mo1601a();
    }

    /* access modifiers changed from: protected */
    /* renamed from: c0 */
    public void mo1668c0(Throwable th) {
    }

    /* renamed from: d */
    public void mo1638d(CancellationException cancellationException) {
        if (cancellationException == null) {
            cancellationException = new C0694p1(mo1556C(), (Throwable) null, this);
        }
        mo1676z(cancellationException);
    }

    /* access modifiers changed from: protected */
    /* renamed from: d0 */
    public void mo1560d0(Object obj) {
    }

    /* renamed from: e */
    public CancellationException mo1584e() {
        Throwable th;
        Object P = mo1664P();
        CancellationException cancellationException = null;
        if (P instanceof C0714b) {
            th = ((C0714b) P).mo1678f();
        } else if (P instanceof C0722y) {
            th = ((C0722y) P).f1333a;
        } else if (!(P instanceof C0669j1)) {
            th = null;
        } else {
            throw new IllegalStateException(C0429i.m1501i("Cannot be cancelling child in this state: ", P).toString());
        }
        if (th instanceof CancellationException) {
            cancellationException = (CancellationException) th;
        }
        return cancellationException == null ? new C0694p1(C0429i.m1501i("Parent job is ", m2231k0(P)), th, this) : cancellationException;
    }

    /* access modifiers changed from: protected */
    /* renamed from: e0 */
    public void mo1669e0() {
    }

    /* renamed from: f */
    public final void mo1651f(C0637c2 c2Var) {
        mo1675y(c2Var);
    }

    public <R> R fold(R r, C0547p<? super R, ? super C0195g.C0198b, ? extends R> pVar) {
        return C0689o1.C0690a.m2147b(this, r, pVar);
    }

    public <E extends C0195g.C0198b> E get(C0195g.C0200c<E> cVar) {
        return C0689o1.C0690a.m2148c(this, cVar);
    }

    public final C0195g.C0200c<?> getKey() {
        return C0689o1.f1285c;
    }

    /* renamed from: h */
    public final CancellationException mo1639h() {
        Object P = mo1664P();
        if (P instanceof C0714b) {
            Throwable f = ((C0714b) P).mo1678f();
            if (f != null) {
                return mo1672l0(f, C0429i.m1501i(C0696q0.m2160a(this), " is cancelling"));
            }
            throw new IllegalStateException(C0429i.m1501i("Job is still new or active: ", this).toString());
        } else if (!(P instanceof C0669j1)) {
            return P instanceof C0722y ? m2232m0(this, ((C0722y) P).f1333a, (String) null, 1, (Object) null) : new C0694p1(C0429i.m1501i(C0696q0.m2160a(this), " has completed normally"), (Throwable) null, this);
        } else {
            throw new IllegalStateException(C0429i.m1501i("Job is still new or active: ", this).toString());
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:0:0x0000 A[LOOP_START, MTH_ENTER_BLOCK] */
    /* renamed from: h0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo1670h0(p046v0.C0709u1 r4) {
        /*
            r3 = this;
        L_0x0000:
            java.lang.Object r0 = r3.mo1664P()
            boolean r1 = r0 instanceof p046v0.C0709u1
            if (r1 == 0) goto L_0x0018
            if (r0 == r4) goto L_0x000b
            return
        L_0x000b:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r1 = f1306d
            v0.y0 r2 = p046v0.C0718w1.f1325g
            boolean r0 = kotlinx.coroutines.internal.C0440c.m1537a(r1, r3, r0, r2)
            if (r0 == 0) goto L_0x0000
            return
        L_0x0018:
            boolean r1 = r0 instanceof p046v0.C0669j1
            if (r1 == 0) goto L_0x0027
            v0.j1 r0 = (p046v0.C0669j1) r0
            v0.z1 r0 = r0.mo1602c()
            if (r0 == 0) goto L_0x0027
            r4.mo1404u()
        L_0x0027:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p046v0.C0712v1.mo1670h0(v0.u1):void");
    }

    /* renamed from: i */
    public final boolean mo1640i() {
        int j0;
        do {
            j0 = m2230j0(mo1664P());
            if (j0 == 0) {
                return false;
            }
        } while (j0 != 1);
        return true;
    }

    /* renamed from: i0 */
    public final void mo1671i0(C0695q qVar) {
        this._parentHandle = qVar;
    }

    /* renamed from: j */
    public final C0720x0 mo1641j(boolean z, boolean z2, C0543l<? super Throwable, C0141q> lVar) {
        C0709u1 X = m2224X(lVar, z);
        while (true) {
            Object P = mo1664P();
            if (P instanceof C0723y0) {
                C0723y0 y0Var = (C0723y0) P;
                if (!y0Var.mo1601a()) {
                    m2228f0(y0Var);
                } else if (C0440c.m1537a(f1306d, this, P, X)) {
                    return X;
                }
            } else {
                Throwable th = null;
                if (P instanceof C0669j1) {
                    C0727z1 c = ((C0669j1) P).mo1602c();
                    if (c != null) {
                        C0720x0 x0Var = C0629a2.f1241d;
                        if (z && (P instanceof C0714b)) {
                            synchronized (P) {
                                th = ((C0714b) P).mo1678f();
                                if (th == null || ((lVar instanceof C0698r) && !((C0714b) P).mo1680h())) {
                                    if (m2240v(P, c, X)) {
                                        if (th == null) {
                                            return X;
                                        }
                                        x0Var = X;
                                    }
                                }
                                C0141q qVar = C0141q.f277a;
                            }
                        }
                        if (th != null) {
                            if (z2) {
                                lVar.invoke(th);
                            }
                            return x0Var;
                        } else if (m2240v(P, c, X)) {
                            return X;
                        }
                    } else if (P != null) {
                        m2229g0((C0709u1) P);
                    } else {
                        throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.JobNode");
                    }
                } else {
                    if (z2) {
                        C0722y yVar = P instanceof C0722y ? (C0722y) P : null;
                        if (yVar != null) {
                            th = yVar.f1333a;
                        }
                        lVar.invoke(th);
                    }
                    return C0629a2.f1241d;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: l0 */
    public final CancellationException mo1672l0(Throwable th, String str) {
        CancellationException cancellationException = th instanceof CancellationException ? (CancellationException) th : null;
        if (cancellationException == null) {
            if (str == null) {
                str = mo1556C();
            }
            cancellationException = new C0694p1(str, th, this);
        }
        return cancellationException;
    }

    public C0195g minusKey(C0195g.C0200c<?> cVar) {
        return C0689o1.C0690a.m2150e(this, cVar);
    }

    /* renamed from: n0 */
    public final String mo1673n0() {
        return mo1558Y() + '{' + m2231k0(mo1664P()) + '}';
    }

    /* renamed from: o */
    public final C0695q mo1642o(C0701s sVar) {
        return (C0695q) C0689o1.C0690a.m2149d(this, true, false, new C0698r(sVar), 2, (Object) null);
    }

    public C0195g plus(C0195g gVar) {
        return C0689o1.C0690a.m2151f(this, gVar);
    }

    public String toString() {
        return mo1673n0() + '@' + C0696q0.m2161b(this);
    }

    /* access modifiers changed from: protected */
    /* renamed from: x */
    public void mo1433x(Object obj) {
    }

    /* renamed from: y */
    public final boolean mo1675y(Object obj) {
        Object a = C0718w1.f1319a;
        if (mo1650M() && (a = m2213A(obj)) == C0718w1.f1320b) {
            return true;
        }
        if (a == C0718w1.f1319a) {
            a = m2223V(obj);
        }
        if (a == C0718w1.f1319a || a == C0718w1.f1320b) {
            return true;
        }
        if (a == C0718w1.f1322d) {
            return false;
        }
        mo1433x(a);
        return true;
    }

    /* renamed from: z */
    public void mo1676z(Throwable th) {
        mo1675y(th);
    }
}
