package p046v0;

import p002a1.C0010a;
import p002a1.C0011b;
import p011e0.C0131i;
import p017h0.C0190d;
import p017h0.C0194f;
import p032o0.C0543l;
import p032o0.C0547p;

/* renamed from: v0.n0 */
public enum C0684n0 {
    DEFAULT,
    LAZY,
    ATOMIC,
    UNDISPATCHED;

    /* renamed from: v0.n0$a */
    public /* synthetic */ class C0685a {

        /* renamed from: a */
        public static final /* synthetic */ int[] f1282a = null;

        static {
            int[] iArr = new int[C0684n0.values().length];
            iArr[C0684n0.DEFAULT.ordinal()] = 1;
            iArr[C0684n0.ATOMIC.ordinal()] = 2;
            iArr[C0684n0.UNDISPATCHED.ordinal()] = 3;
            iArr[C0684n0.LAZY.ordinal()] = 4;
            f1282a = iArr;
        }
    }

    /* renamed from: b */
    public final <R, T> void mo1635b(C0547p<? super R, ? super C0190d<? super T>, ? extends Object> pVar, R r, C0190d<? super T> dVar) {
        int i = C0685a.f1282a[ordinal()];
        if (i == 1) {
            C0010a.m21e(pVar, r, dVar, (C0543l) null, 4, (Object) null);
        } else if (i == 2) {
            C0194f.m544a(pVar, r, dVar);
        } else if (i == 3) {
            C0011b.m22a(pVar, r, dVar);
        } else if (i != 4) {
            throw new C0131i();
        }
    }

    /* renamed from: c */
    public final boolean mo1636c() {
        return this == LAZY;
    }
}
