package p046v0;

import kotlin.jvm.internal.C0429i;
import p011e0.C0141q;
import p032o0.C0543l;

/* renamed from: v0.z */
public final class C0725z {

    /* renamed from: a */
    public final Object f1335a;

    /* renamed from: b */
    public final C0543l<Throwable, C0141q> f1336b;

    public C0725z(Object obj, C0543l<? super Throwable, C0141q> lVar) {
        this.f1335a = obj;
        this.f1336b = lVar;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0725z)) {
            return false;
        }
        C0725z zVar = (C0725z) obj;
        return C0429i.m1493a(this.f1335a, zVar.f1335a) && C0429i.m1493a(this.f1336b, zVar.f1336b);
    }

    public int hashCode() {
        Object obj = this.f1335a;
        return ((obj == null ? 0 : obj.hashCode()) * 31) + this.f1336b.hashCode();
    }

    public String toString() {
        return "CompletedWithCancellation(result=" + this.f1335a + ", onCancellation=" + this.f1336b + ')';
    }
}
