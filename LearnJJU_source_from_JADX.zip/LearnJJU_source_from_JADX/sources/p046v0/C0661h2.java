package p046v0;

import kotlinx.coroutines.internal.C0443d0;
import kotlinx.coroutines.internal.C0482x;
import p011e0.C0141q;
import p017h0.C0190d;
import p017h0.C0195g;

/* renamed from: v0.h2 */
public final class C0661h2<T> extends C0482x<T> {

    /* renamed from: g */
    private C0195g f1257g;

    /* renamed from: h */
    private Object f1258h;

    /* access modifiers changed from: protected */
    /* renamed from: t0 */
    public void mo1432t0(Object obj) {
        C0195g gVar = this.f1257g;
        C0661h2<?> h2Var = null;
        if (gVar != null) {
            C0443d0.m1549a(gVar, this.f1258h);
            this.f1257g = h2Var;
            this.f1258h = h2Var;
        }
        Object a = C0635c0.m2029a(obj, this.f1053f);
        C0190d<T> dVar = this.f1053f;
        C0195g context = dVar.getContext();
        Object c = C0443d0.m1551c(context, h2Var);
        if (c != C0443d0.f994a) {
            h2Var = C0643e0.m2043e(dVar, context, c);
        }
        try {
            this.f1053f.resumeWith(a);
            C0141q qVar = C0141q.f277a;
        } finally {
            if (h2Var == null || h2Var.mo1599y0()) {
                C0443d0.m1549a(context, c);
            }
        }
    }

    /* renamed from: y0 */
    public final boolean mo1599y0() {
        if (this.f1257g == null) {
            return false;
        }
        this.f1257g = null;
        this.f1258h = null;
        return true;
    }

    /* renamed from: z0 */
    public final void mo1600z0(C0195g gVar, Object obj) {
        this.f1257g = gVar;
        this.f1258h = obj;
    }
}
