package p046v0;

import kotlinx.coroutines.internal.C0451g;
import p011e0.C0133k;
import p011e0.C0136l;
import p017h0.C0190d;

/* renamed from: v0.q0 */
public final class C0696q0 {
    /* renamed from: a */
    public static final String m2160a(Object obj) {
        return obj.getClass().getSimpleName();
    }

    /* renamed from: b */
    public static final String m2161b(Object obj) {
        return Integer.toHexString(System.identityHashCode(obj));
    }

    /* renamed from: c */
    public static final String m2162c(C0190d<?> dVar) {
        Object obj;
        if (dVar instanceof C0451g) {
            return dVar.toString();
        }
        try {
            C0133k.C0134a aVar = C0133k.f271d;
            obj = C0133k.m417a(dVar + '@' + m2161b(dVar));
        } catch (Throwable th) {
            C0133k.C0134a aVar2 = C0133k.f271d;
            obj = C0133k.m417a(C0136l.m421a(th));
        }
        Throwable b = C0133k.m418b(obj);
        String str = obj;
        if (b != null) {
            str = dVar.getClass().getName() + '@' + m2161b(dVar);
        }
        return (String) str;
    }
}
