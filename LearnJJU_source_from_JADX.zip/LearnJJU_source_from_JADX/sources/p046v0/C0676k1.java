package p046v0;

/* renamed from: v0.k1 */
final class C0676k1 {

    /* renamed from: a */
    public final C0669j1 f1267a;

    public C0676k1(C0669j1 j1Var) {
        this.f1267a = j1Var;
    }
}
