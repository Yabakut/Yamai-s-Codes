package p046v0;

import java.util.List;
import java.util.ServiceLoader;
import kotlinx.coroutines.CoroutineExceptionHandler;
import p017h0.C0195g;

/* renamed from: v0.g0 */
public final class C0655g0 {

    /* renamed from: a */
    private static final List<CoroutineExceptionHandler> f1254a;

    static {
        Class<CoroutineExceptionHandler> cls = CoroutineExceptionHandler.class;
        f1254a = C0597h.m1895e(C0594f.m1891a(ServiceLoader.load(cls, cls.getClassLoader()).iterator()));
    }

    /* renamed from: a */
    public static final void m2059a(C0195g gVar, Throwable th) {
        for (CoroutineExceptionHandler handleException : f1254a) {
            try {
                handleException.handleException(gVar, th);
            } catch (Throwable th2) {
                Thread currentThread = Thread.currentThread();
                currentThread.getUncaughtExceptionHandler().uncaughtException(currentThread, C0659h0.m2068b(th, th2));
            }
        }
        Thread currentThread2 = Thread.currentThread();
        currentThread2.getUncaughtExceptionHandler().uncaughtException(currentThread2, th);
    }
}
