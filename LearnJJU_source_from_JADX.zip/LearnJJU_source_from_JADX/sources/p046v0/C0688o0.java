package p046v0;

/* renamed from: v0.o0 */
public final class C0688o0 extends Error {
    public C0688o0(String str, Throwable th) {
        super(str, th);
    }
}
