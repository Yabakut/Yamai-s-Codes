package p046v0;

import java.util.concurrent.CancellationException;
import p011e0.C0141q;
import p017h0.C0195g;
import p032o0.C0543l;
import p032o0.C0547p;

/* renamed from: v0.o1 */
public interface C0689o1 extends C0195g.C0198b {

    /* renamed from: c */
    public static final C0691b f1285c = C0691b.f1286d;

    /* renamed from: v0.o1$a */
    public static final class C0690a {
        /* renamed from: a */
        public static /* synthetic */ void m2146a(C0689o1 o1Var, CancellationException cancellationException, int i, Object obj) {
            if (obj == null) {
                if ((i & 1) != 0) {
                    cancellationException = null;
                }
                o1Var.mo1638d(cancellationException);
                return;
            }
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: cancel");
        }

        /* renamed from: b */
        public static <R> R m2147b(C0689o1 o1Var, R r, C0547p<? super R, ? super C0195g.C0198b, ? extends R> pVar) {
            return C0195g.C0198b.C0199a.m547a(o1Var, r, pVar);
        }

        /* renamed from: c */
        public static <E extends C0195g.C0198b> E m2148c(C0689o1 o1Var, C0195g.C0200c<E> cVar) {
            return C0195g.C0198b.C0199a.m548b(o1Var, cVar);
        }

        /* renamed from: d */
        public static /* synthetic */ C0720x0 m2149d(C0689o1 o1Var, boolean z, boolean z2, C0543l lVar, int i, Object obj) {
            if (obj == null) {
                if ((i & 1) != 0) {
                    z = false;
                }
                if ((i & 2) != 0) {
                    z2 = true;
                }
                return o1Var.mo1641j(z, z2, lVar);
            }
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: invokeOnCompletion");
        }

        /* renamed from: e */
        public static C0195g m2150e(C0689o1 o1Var, C0195g.C0200c<?> cVar) {
            return C0195g.C0198b.C0199a.m549c(o1Var, cVar);
        }

        /* renamed from: f */
        public static C0195g m2151f(C0689o1 o1Var, C0195g gVar) {
            return C0195g.C0198b.C0199a.m550d(o1Var, gVar);
        }
    }

    /* renamed from: v0.o1$b */
    public static final class C0691b implements C0195g.C0200c<C0689o1> {

        /* renamed from: d */
        static final /* synthetic */ C0691b f1286d = new C0691b();

        private C0691b() {
        }
    }

    /* renamed from: a */
    boolean mo1559a();

    /* renamed from: d */
    void mo1638d(CancellationException cancellationException);

    /* renamed from: h */
    CancellationException mo1639h();

    /* renamed from: i */
    boolean mo1640i();

    /* renamed from: j */
    C0720x0 mo1641j(boolean z, boolean z2, C0543l<? super Throwable, C0141q> lVar);

    /* renamed from: o */
    C0695q mo1642o(C0701s sVar);
}
