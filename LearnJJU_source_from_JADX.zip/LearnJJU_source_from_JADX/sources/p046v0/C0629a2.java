package p046v0;

/* renamed from: v0.a2 */
public final class C0629a2 implements C0720x0, C0695q {

    /* renamed from: d */
    public static final C0629a2 f1241d = new C0629a2();

    private C0629a2() {
    }

    /* renamed from: b */
    public void mo1572b() {
    }

    /* renamed from: g */
    public boolean mo1578g(Throwable th) {
        return false;
    }

    public C0689o1 getParent() {
        return null;
    }

    public String toString() {
        return "NonDisposableHandle";
    }
}
