package p046v0;

import p011e0.C0141q;
import p032o0.C0543l;

/* renamed from: v0.j */
public abstract class C0666j implements C0543l<Throwable, C0141q> {
    /* renamed from: a */
    public abstract void mo1604a(Throwable th);
}
