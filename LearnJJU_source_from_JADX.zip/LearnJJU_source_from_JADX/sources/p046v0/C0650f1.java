package p046v0;

import java.io.Closeable;
import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0430j;
import p017h0.C0187b;
import p017h0.C0195g;
import p032o0.C0543l;

/* renamed from: v0.f1 */
public abstract class C0650f1 extends C0647f0 implements Closeable {

    /* renamed from: e */
    public static final C0651a f1250e = new C0651a((C0425e) null);

    /* renamed from: v0.f1$a */
    public static final class C0651a extends C0187b<C0647f0, C0650f1> {

        /* renamed from: v0.f1$a$a */
        static final class C0652a extends C0430j implements C0543l<C0195g.C0198b, C0650f1> {

            /* renamed from: d */
            public static final C0652a f1251d = new C0652a();

            C0652a() {
                super(1);
            }

            /* renamed from: a */
            public final C0650f1 invoke(C0195g.C0198b bVar) {
                if (bVar instanceof C0650f1) {
                    return (C0650f1) bVar;
                }
                return null;
            }
        }

        private C0651a() {
            super(C0647f0.f1248d, C0652a.f1251d);
        }

        public /* synthetic */ C0651a(C0425e eVar) {
            this();
        }
    }
}
