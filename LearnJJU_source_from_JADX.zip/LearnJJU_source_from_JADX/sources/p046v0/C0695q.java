package p046v0;

/* renamed from: v0.q */
public interface C0695q extends C0720x0 {
    /* renamed from: g */
    boolean mo1578g(Throwable th);

    C0689o1 getParent();
}
