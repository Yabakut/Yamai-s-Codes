package p046v0;

/* renamed from: v0.x0 */
public interface C0720x0 {
    /* renamed from: b */
    void mo1572b();
}
