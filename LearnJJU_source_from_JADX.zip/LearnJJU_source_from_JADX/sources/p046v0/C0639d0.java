package p046v0;

import java.lang.Throwable;
import p046v0.C0639d0;

/* renamed from: v0.d0 */
public interface C0639d0<T extends Throwable & C0639d0<T>> {
    /* renamed from: a */
    T mo1586a();
}
