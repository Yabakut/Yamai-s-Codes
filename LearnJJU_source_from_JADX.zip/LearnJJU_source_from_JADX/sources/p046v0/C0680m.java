package p046v0;

import kotlinx.coroutines.internal.C0484z;

/* renamed from: v0.m */
public final class C0680m {

    /* renamed from: a */
    public static final C0484z f1274a = new C0484z("RESUME_TOKEN");
}
