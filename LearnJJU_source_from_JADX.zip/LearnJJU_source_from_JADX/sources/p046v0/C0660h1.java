package p046v0;

import java.util.concurrent.Executor;

/* renamed from: v0.h1 */
public final class C0660h1 {
    /* renamed from: a */
    public static final C0647f0 m2069a(Executor executor) {
        C0711v0 v0Var = executor instanceof C0711v0 ? (C0711v0) executor : null;
        return v0Var == null ? new C0656g1(executor) : v0Var.f1305d;
    }
}
