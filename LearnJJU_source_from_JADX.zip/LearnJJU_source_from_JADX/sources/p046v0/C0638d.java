package p046v0;

/* renamed from: v0.d */
final class C0638d implements C0633b2 {

    /* renamed from: d */
    public static final C0638d f1243d = new C0638d();

    private C0638d() {
    }

    public String toString() {
        return "Active";
    }
}
