package p046v0;

/* renamed from: v0.s */
public interface C0701s extends C0689o1 {
    /* renamed from: f */
    void mo1651f(C0637c2 c2Var);
}
