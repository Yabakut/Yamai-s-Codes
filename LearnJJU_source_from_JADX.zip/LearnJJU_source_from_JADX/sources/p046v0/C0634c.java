package p046v0;

/* renamed from: v0.c */
public final class C0634c {

    /* renamed from: a */
    private static C0630b f1242a;

    /* renamed from: a */
    public static final C0630b m2028a() {
        return f1242a;
    }
}
