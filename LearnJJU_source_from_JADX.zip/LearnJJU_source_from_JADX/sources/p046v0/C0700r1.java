package p046v0;

/* renamed from: v0.r1 */
public class C0700r1 extends C0712v1 implements C0716w {

    /* renamed from: e */
    private final boolean f1296e = m2170t0();

    public C0700r1(C0689o1 o1Var) {
        super(true);
        mo1665S(o1Var);
    }

    /* renamed from: t0 */
    private final boolean m2170t0() {
        C0698r rVar;
        C0695q O = mo1663O();
        C0698r rVar2 = O instanceof C0698r ? (C0698r) O : null;
        if (rVar2 == null) {
            return false;
        }
        do {
            C0712v1 z = rVar2.mo1657z();
            if (z.mo1649L()) {
                return true;
            }
            C0695q O2 = z.mo1663O();
            if (O2 instanceof C0698r) {
                rVar = (C0698r) O2;
                continue;
            } else {
                rVar = null;
                continue;
            }
        } while (rVar2 != null);
        return false;
    }

    /* renamed from: L */
    public boolean mo1649L() {
        return this.f1296e;
    }

    /* renamed from: M */
    public boolean mo1650M() {
        return true;
    }
}
