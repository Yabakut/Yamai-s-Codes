package p046v0;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: v0.u */
public final /* synthetic */ class C0707u implements ThreadFactory {

    /* renamed from: a */
    public final /* synthetic */ AtomicInteger f1300a;

    public /* synthetic */ C0707u(AtomicInteger atomicInteger) {
        this.f1300a = atomicInteger;
    }

    public final Thread newThread(Runnable runnable) {
        return C0710v.m2206t(this.f1300a, runnable);
    }
}
