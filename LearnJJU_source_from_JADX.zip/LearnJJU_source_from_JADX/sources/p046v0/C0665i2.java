package p046v0;

import p017h0.C0195g;
import p032o0.C0547p;

/* renamed from: v0.i2 */
final class C0665i2 implements C0195g.C0198b, C0195g.C0200c<C0665i2> {

    /* renamed from: d */
    public static final C0665i2 f1260d = new C0665i2();

    private C0665i2() {
    }

    public <R> R fold(R r, C0547p<? super R, ? super C0195g.C0198b, ? extends R> pVar) {
        return C0195g.C0198b.C0199a.m547a(this, r, pVar);
    }

    public <E extends C0195g.C0198b> E get(C0195g.C0200c<E> cVar) {
        return C0195g.C0198b.C0199a.m548b(this, cVar);
    }

    public C0195g.C0200c<?> getKey() {
        return this;
    }

    public C0195g minusKey(C0195g.C0200c<?> cVar) {
        return C0195g.C0198b.C0199a.m549c(this, cVar);
    }

    public C0195g plus(C0195g gVar) {
        return C0195g.C0198b.C0199a.m550d(this, gVar);
    }
}
