package p046v0;

import p011e0.C0141q;
import p017h0.C0190d;
import p032o0.C0543l;

/* renamed from: v0.k */
public interface C0672k<T> extends C0190d<T> {

    /* renamed from: v0.k$a */
    public static final class C0673a {
        /* renamed from: a */
        public static /* synthetic */ Object m2090a(C0672k kVar, Object obj, Object obj2, int i, Object obj3) {
            if (obj3 == null) {
                if ((i & 2) != 0) {
                    obj2 = null;
                }
                return kVar.mo1612g(obj, obj2);
            }
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: tryResume");
        }
    }

    /* renamed from: c */
    void mo1611c(C0543l<? super Throwable, C0141q> lVar);

    /* renamed from: g */
    Object mo1612g(T t, Object obj);

    /* renamed from: m */
    Object mo1613m(Throwable th);

    /* renamed from: n */
    Object mo1614n(T t, Object obj, C0543l<? super Throwable, C0141q> lVar);

    /* renamed from: p */
    void mo1615p(Object obj);

    /* renamed from: r */
    void mo1616r(T t, C0543l<? super Throwable, C0141q> lVar);
}
