package p046v0;

import p011e0.C0141q;
import p017h0.C0190d;
import p017h0.C0195g;
import p017h0.C0201h;
import p032o0.C0547p;

/* renamed from: v0.h */
final /* synthetic */ class C0658h {
    /* renamed from: a */
    public static final C0689o1 m2065a(C0678l0 l0Var, C0195g gVar, C0684n0 n0Var, C0547p<? super C0678l0, ? super C0190d<? super C0141q>, ? extends Object> pVar) {
        C0195g c = C0643e0.m2041c(l0Var, gVar);
        C0624a x1Var = n0Var.mo1636c() ? new C0721x1(c, pVar) : new C0641d2(c, true);
        x1Var.mo1563w0(n0Var, x1Var, pVar);
        return x1Var;
    }

    /* renamed from: b */
    public static /* synthetic */ C0689o1 m2066b(C0678l0 l0Var, C0195g gVar, C0684n0 n0Var, C0547p pVar, int i, Object obj) {
        if ((i & 1) != 0) {
            gVar = C0201h.f297d;
        }
        if ((i & 2) != 0) {
            n0Var = C0684n0.DEFAULT;
        }
        return C0654g.m2057a(l0Var, gVar, n0Var, pVar);
    }
}
