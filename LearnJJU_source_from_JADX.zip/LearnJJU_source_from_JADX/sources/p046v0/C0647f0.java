package p046v0;

import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0430j;
import kotlinx.coroutines.internal.C0451g;
import p017h0.C0186a;
import p017h0.C0187b;
import p017h0.C0190d;
import p017h0.C0191e;
import p017h0.C0195g;
import p032o0.C0543l;

/* renamed from: v0.f0 */
public abstract class C0647f0 extends C0186a implements C0191e {

    /* renamed from: d */
    public static final C0648a f1248d = new C0648a((C0425e) null);

    /* renamed from: v0.f0$a */
    public static final class C0648a extends C0187b<C0191e, C0647f0> {

        /* renamed from: v0.f0$a$a */
        static final class C0649a extends C0430j implements C0543l<C0195g.C0198b, C0647f0> {

            /* renamed from: d */
            public static final C0649a f1249d = new C0649a();

            C0649a() {
                super(1);
            }

            /* renamed from: a */
            public final C0647f0 invoke(C0195g.C0198b bVar) {
                if (bVar instanceof C0647f0) {
                    return (C0647f0) bVar;
                }
                return null;
            }
        }

        private C0648a() {
            super(C0191e.f294a, C0649a.f1249d);
        }

        public /* synthetic */ C0648a(C0425e eVar) {
            this();
        }
    }

    public C0647f0() {
        super(C0191e.f294a);
    }

    /* renamed from: b */
    public final <T> C0190d<T> mo667b(C0190d<? super T> dVar) {
        return new C0451g(this, dVar);
    }

    public <E extends C0195g.C0198b> E get(C0195g.C0200c<E> cVar) {
        return C0191e.C0192a.m542a(this, cVar);
    }

    /* renamed from: k */
    public final void mo668k(C0190d<?> dVar) {
        ((C0451g) dVar).mo1381q();
    }

    /* renamed from: m */
    public abstract void mo1422m(C0195g gVar, Runnable runnable);

    public C0195g minusKey(C0195g.C0200c<?> cVar) {
        return C0191e.C0192a.m543b(this, cVar);
    }

    /* renamed from: n */
    public boolean mo1423n(C0195g gVar) {
        return true;
    }

    public String toString() {
        return C0696q0.m2160a(this) + '@' + C0696q0.m2161b(this);
    }
}
