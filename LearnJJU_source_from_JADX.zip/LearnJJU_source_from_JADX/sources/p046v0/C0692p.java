package p046v0;

import p011e0.C0141q;

/* renamed from: v0.p */
public final class C0692p extends C0697q1 {

    /* renamed from: h */
    public final C0677l<?> f1287h;

    public C0692p(C0677l<?> lVar) {
        this.f1287h = lVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        mo1564y((Throwable) obj);
        return C0141q.f277a;
    }

    /* renamed from: y */
    public void mo1564y(Throwable th) {
        C0677l<?> lVar = this.f1287h;
        lVar.mo1622E(lVar.mo1631v(mo1657z()));
    }
}
