package p046v0;

/* renamed from: v0.t */
public final /* synthetic */ class C0704t implements Runnable {

    /* renamed from: d */
    public static final /* synthetic */ C0704t f1298d = new C0704t();

    private /* synthetic */ C0704t() {
    }

    public final void run() {
        C0710v.m2210y();
    }
}
