package p046v0;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

/* renamed from: v0.r0 */
public final class C0699r0 extends C0626a1 implements Runnable {
    private static volatile Thread _thread;
    private static volatile int debugStatus;

    /* renamed from: j */
    public static final C0699r0 f1294j;

    /* renamed from: k */
    private static final long f1295k;

    static {
        Long l;
        C0699r0 r0Var = new C0699r0();
        f1294j = r0Var;
        C0726z0.m2312v(r0Var, false, 1, (Object) null);
        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
        try {
            l = Long.getLong("kotlinx.coroutines.DefaultExecutor.keepAlive", 1000);
        } catch (SecurityException unused) {
            l = 1000L;
        }
        f1295k = timeUnit.toNanos(l.longValue());
    }

    private C0699r0() {
    }

    /* renamed from: R */
    private final synchronized void m2165R() {
        if (m2167T()) {
            debugStatus = 3;
            mo1568M();
            notifyAll();
        }
    }

    /* renamed from: S */
    private final synchronized Thread m2166S() {
        Thread thread;
        thread = _thread;
        if (thread == null) {
            thread = new Thread(this, "kotlinx.coroutines.DefaultExecutor");
            _thread = thread;
            thread.setDaemon(true);
            thread.start();
        }
        return thread;
    }

    /* renamed from: T */
    private final boolean m2167T() {
        int i = debugStatus;
        return i == 2 || i == 3;
    }

    /* renamed from: U */
    private final synchronized boolean m2168U() {
        if (m2167T()) {
            return false;
        }
        debugStatus = 1;
        notifyAll();
        return true;
    }

    /* access modifiers changed from: protected */
    /* renamed from: A */
    public Thread mo1581A() {
        Thread thread = _thread;
        return thread == null ? m2166S() : thread;
    }

    public void run() {
        C0653f2.f1252a.mo1594c(this);
        C0634c.m2028a();
        try {
            if (m2168U()) {
                long j = Long.MAX_VALUE;
                while (true) {
                    Thread.interrupted();
                    long K = mo1567K();
                    if (K == Long.MAX_VALUE) {
                        C0634c.m2028a();
                        long nanoTime = System.nanoTime();
                        if (j == Long.MAX_VALUE) {
                            j = f1295k + nanoTime;
                        }
                        long j2 = j - nanoTime;
                        if (j2 <= 0) {
                            _thread = null;
                            m2165R();
                            C0634c.m2028a();
                            if (!mo1566J()) {
                                mo1581A();
                                return;
                            }
                            return;
                        }
                        K = C0578f.m1879d(K, j2);
                    } else {
                        j = Long.MAX_VALUE;
                    }
                    if (K > 0) {
                        if (m2167T()) {
                            _thread = null;
                            m2165R();
                            C0634c.m2028a();
                            if (!mo1566J()) {
                                mo1581A();
                                return;
                            }
                            return;
                        }
                        C0634c.m2028a();
                        LockSupport.parkNanos(this, K);
                    }
                }
            }
        } finally {
            _thread = null;
            m2165R();
            C0634c.m2028a();
            if (!mo1566J()) {
                mo1581A();
            }
        }
    }
}
