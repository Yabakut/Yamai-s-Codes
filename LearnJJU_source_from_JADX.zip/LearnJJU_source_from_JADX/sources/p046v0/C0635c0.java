package p046v0;

import kotlin.coroutines.jvm.internal.C0411e;
import kotlin.jvm.internal.C0425e;
import kotlinx.coroutines.internal.C0483y;
import p011e0.C0133k;
import p011e0.C0136l;
import p011e0.C0141q;
import p017h0.C0190d;
import p032o0.C0543l;

/* renamed from: v0.c0 */
public final class C0635c0 {
    /* renamed from: a */
    public static final <T> Object m2029a(Object obj, C0190d<? super T> dVar) {
        if (obj instanceof C0722y) {
            C0133k.C0134a aVar = C0133k.f271d;
            Throwable th = ((C0722y) obj).f1333a;
            if (C0693p0.m2156d() && (dVar instanceof C0411e)) {
                th = C0483y.m1681j(th, (C0411e) dVar);
            }
            obj = C0136l.m421a(th);
        } else {
            C0133k.C0134a aVar2 = C0133k.f271d;
        }
        return C0133k.m417a(obj);
    }

    /* renamed from: b */
    public static final <T> Object m2030b(Object obj, C0543l<? super Throwable, C0141q> lVar) {
        Throwable b = C0133k.m418b(obj);
        return b == null ? lVar != null ? new C0725z(obj, lVar) : obj : new C0722y(b, false, 2, (C0425e) null);
    }

    /* renamed from: c */
    public static final <T> Object m2031c(Object obj, C0672k<?> kVar) {
        Throwable b = C0133k.m418b(obj);
        if (b != null) {
            if (C0693p0.m2156d() && (kVar instanceof C0411e)) {
                b = C0483y.m1681j(b, (C0411e) kVar);
            }
            obj = new C0722y(b, false, 2, (C0425e) null);
        }
        return obj;
    }

    /* renamed from: d */
    public static /* synthetic */ Object m2032d(Object obj, C0543l lVar, int i, Object obj2) {
        if ((i & 1) != 0) {
            lVar = null;
        }
        return m2030b(obj, lVar);
    }
}
