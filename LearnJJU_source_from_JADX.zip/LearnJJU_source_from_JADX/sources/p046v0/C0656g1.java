package p046v0;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import kotlinx.coroutines.internal.C0447e;
import p017h0.C0195g;

/* renamed from: v0.g1 */
public final class C0656g1 extends C0650f1 {

    /* renamed from: f */
    private final Executor f1255f;

    public C0656g1(Executor executor) {
        this.f1255f = executor;
        C0447e.m1555a(mo1598q());
    }

    /* renamed from: p */
    private final void m2060p(C0195g gVar, RejectedExecutionException rejectedExecutionException) {
        C0703s1.m2179c(gVar, C0644e1.m2044a("The task was rejected", rejectedExecutionException));
    }

    public void close() {
        Executor q = mo1598q();
        ExecutorService executorService = q instanceof ExecutorService ? (ExecutorService) q : null;
        if (executorService != null) {
            executorService.shutdown();
        }
    }

    public boolean equals(Object obj) {
        return (obj instanceof C0656g1) && ((C0656g1) obj).mo1598q() == mo1598q();
    }

    public int hashCode() {
        return System.identityHashCode(mo1598q());
    }

    /* renamed from: m */
    public void mo1422m(C0195g gVar, Runnable runnable) {
        try {
            Executor q = mo1598q();
            C0634c.m2028a();
            q.execute(runnable);
        } catch (RejectedExecutionException e) {
            C0634c.m2028a();
            m2060p(gVar, e);
            C0717w0.m2290b().mo1422m(gVar, runnable);
        }
    }

    /* renamed from: q */
    public Executor mo1598q() {
        return this.f1255f;
    }

    public String toString() {
        return mo1598q().toString();
    }
}
