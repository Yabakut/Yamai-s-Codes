package p046v0;

/* renamed from: v0.c1 */
public final class C0636c1 {
    /* renamed from: a */
    public static final C0726z0 m2033a() {
        return new C0646f(Thread.currentThread());
    }
}
