package p046v0;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import p011e0.C0141q;
import p032o0.C0543l;

/* renamed from: v0.m1 */
final class C0682m1 extends C0697q1 {

    /* renamed from: i */
    private static final /* synthetic */ AtomicIntegerFieldUpdater f1275i = AtomicIntegerFieldUpdater.newUpdater(C0682m1.class, "_invoked");
    private volatile /* synthetic */ int _invoked = 0;

    /* renamed from: h */
    private final C0543l<Throwable, C0141q> f1276h;

    public C0682m1(C0543l<? super Throwable, C0141q> lVar) {
        this.f1276h = lVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        mo1564y((Throwable) obj);
        return C0141q.f277a;
    }

    /* renamed from: y */
    public void mo1564y(Throwable th) {
        if (f1275i.compareAndSet(this, 0, 1)) {
            this.f1276h.invoke(th);
        }
    }
}
