package p046v0;

/* renamed from: v0.b0 */
public final class C0631b0 extends RuntimeException {
    public C0631b0(String str, Throwable th) {
        super(str, th);
    }
}
