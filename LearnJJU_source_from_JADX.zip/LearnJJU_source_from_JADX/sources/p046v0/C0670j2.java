package p046v0;

import kotlin.jvm.internal.C0425e;
import p017h0.C0186a;
import p017h0.C0195g;

/* renamed from: v0.j2 */
public final class C0670j2 extends C0186a {

    /* renamed from: e */
    public static final C0671a f1263e = new C0671a((C0425e) null);

    /* renamed from: d */
    public boolean f1264d;

    /* renamed from: v0.j2$a */
    public static final class C0671a implements C0195g.C0200c<C0670j2> {
        private C0671a() {
        }

        public /* synthetic */ C0671a(C0425e eVar) {
            this();
        }
    }

    public C0670j2() {
        super(f1263e);
    }
}
