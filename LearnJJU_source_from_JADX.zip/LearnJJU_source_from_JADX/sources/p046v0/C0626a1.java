package p046v0;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.jvm.internal.C0429i;
import kotlinx.coroutines.internal.C0440c;
import kotlinx.coroutines.internal.C0448e0;
import kotlinx.coroutines.internal.C0450f0;
import kotlinx.coroutines.internal.C0472q;
import p017h0.C0195g;

/* renamed from: v0.a1 */
public abstract class C0626a1 extends C0632b1 {

    /* renamed from: h */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f1235h;

    /* renamed from: i */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f1236i;
    private volatile /* synthetic */ Object _delayed = null;
    private volatile /* synthetic */ int _isCompleted = 0;
    private volatile /* synthetic */ Object _queue = null;

    /* renamed from: v0.a1$a */
    public static abstract class C0627a implements Runnable, Comparable<C0627a>, C0720x0, C0450f0 {

        /* renamed from: d */
        public long f1237d;

        /* renamed from: e */
        private Object f1238e;

        /* renamed from: f */
        private int f1239f;

        /* renamed from: a */
        public C0448e0<?> mo1370a() {
            Object obj = this.f1238e;
            if (obj instanceof C0448e0) {
                return (C0448e0) obj;
            }
            return null;
        }

        /* renamed from: b */
        public final synchronized void mo1572b() {
            Object obj = this.f1238e;
            if (obj != C0640d1.f1244a) {
                C0628b bVar = obj instanceof C0628b ? (C0628b) obj : null;
                if (bVar != null) {
                    bVar.mo1365g(this);
                }
                this.f1238e = C0640d1.f1244a;
            }
        }

        /* renamed from: c */
        public void mo1371c(int i) {
            this.f1239f = i;
        }

        /* renamed from: d */
        public void mo1372d(C0448e0<?> e0Var) {
            if (this.f1238e != C0640d1.f1244a) {
                this.f1238e = e0Var;
                return;
            }
            throw new IllegalArgumentException("Failed requirement.".toString());
        }

        /* renamed from: e */
        public int mo1373e() {
            return this.f1239f;
        }

        /* renamed from: f */
        public int compareTo(C0627a aVar) {
            long j = this.f1237d - aVar.f1237d;
            if (j > 0) {
                return 1;
            }
            return j < 0 ? -1 : 0;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:34:0x0046, code lost:
            r8 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:6:0x000b, code lost:
            return r8;
         */
        /* JADX WARNING: Removed duplicated region for block: B:30:0x0040  */
        /* renamed from: h */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final synchronized int mo1575h(long r8, p046v0.C0626a1.C0628b r10, p046v0.C0626a1 r11) {
            /*
                r7 = this;
                monitor-enter(r7)
                java.lang.Object r0 = r7.f1238e     // Catch:{ all -> 0x004b }
                kotlinx.coroutines.internal.z r1 = p046v0.C0640d1.f1244a     // Catch:{ all -> 0x004b }
                if (r0 != r1) goto L_0x000c
                r8 = 2
            L_0x000a:
                monitor-exit(r7)
                return r8
            L_0x000c:
                monitor-enter(r10)     // Catch:{ all -> 0x004b }
                kotlinx.coroutines.internal.f0 r0 = r10.mo1361b()     // Catch:{ all -> 0x0048 }
                v0.a1$a r0 = (p046v0.C0626a1.C0627a) r0     // Catch:{ all -> 0x0048 }
                boolean r11 = r11.m2002I()     // Catch:{ all -> 0x0048 }
                if (r11 == 0) goto L_0x001d
                r8 = 1
                monitor-exit(r10)     // Catch:{ all -> 0x004b }
                monitor-exit(r7)
                return r8
            L_0x001d:
                r1 = 0
                if (r0 != 0) goto L_0x0024
            L_0x0021:
                r10.f1240b = r8     // Catch:{ all -> 0x0048 }
                goto L_0x0037
            L_0x0024:
                long r3 = r0.f1237d     // Catch:{ all -> 0x0048 }
                long r5 = r3 - r8
                int r11 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1))
                if (r11 < 0) goto L_0x002d
                goto L_0x002e
            L_0x002d:
                r8 = r3
            L_0x002e:
                long r3 = r10.f1240b     // Catch:{ all -> 0x0048 }
                long r3 = r8 - r3
                int r11 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
                if (r11 <= 0) goto L_0x0037
                goto L_0x0021
            L_0x0037:
                long r8 = r7.f1237d     // Catch:{ all -> 0x0048 }
                long r3 = r10.f1240b     // Catch:{ all -> 0x0048 }
                long r8 = r8 - r3
                int r11 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1))
                if (r11 >= 0) goto L_0x0042
                r7.f1237d = r3     // Catch:{ all -> 0x0048 }
            L_0x0042:
                r10.mo1360a(r7)     // Catch:{ all -> 0x0048 }
                monitor-exit(r10)     // Catch:{ all -> 0x004b }
                r8 = 0
                goto L_0x000a
            L_0x0048:
                r8 = move-exception
                monitor-exit(r10)     // Catch:{ all -> 0x004b }
                throw r8     // Catch:{ all -> 0x004b }
            L_0x004b:
                r8 = move-exception
                monitor-exit(r7)
                goto L_0x004f
            L_0x004e:
                throw r8
            L_0x004f:
                goto L_0x004e
            */
            throw new UnsupportedOperationException("Method not decompiled: p046v0.C0626a1.C0627a.mo1575h(long, v0.a1$b, v0.a1):int");
        }

        /* renamed from: i */
        public final boolean mo1576i(long j) {
            return j - this.f1237d >= 0;
        }

        public String toString() {
            return "Delayed[nanos=" + this.f1237d + ']';
        }
    }

    /* renamed from: v0.a1$b */
    public static final class C0628b extends C0448e0<C0627a> {

        /* renamed from: b */
        public long f1240b;

        public C0628b(long j) {
            this.f1240b = j;
        }
    }

    static {
        Class<Object> cls = Object.class;
        Class<C0626a1> cls2 = C0626a1.class;
        f1235h = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_queue");
        f1236i = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_delayed");
    }

    /* renamed from: E */
    private final void m1999E() {
        if (!C0693p0.m2153a() || m2002I()) {
            while (true) {
                Object obj = this._queue;
                if (obj == null) {
                    if (C0440c.m1537a(f1235h, this, (Object) null, C0640d1.f1245b)) {
                        return;
                    }
                } else if (obj instanceof C0472q) {
                    ((C0472q) obj).mo1413d();
                    return;
                } else if (obj != C0640d1.f1245b) {
                    C0472q qVar = new C0472q(8, true);
                    qVar.mo1412a((Runnable) obj);
                    if (C0440c.m1537a(f1235h, this, obj, qVar)) {
                        return;
                    }
                } else {
                    return;
                }
            }
        } else {
            throw new AssertionError();
        }
    }

    /* renamed from: F */
    private final Runnable m2000F() {
        while (true) {
            Object obj = this._queue;
            if (obj == null) {
                return null;
            }
            if (obj instanceof C0472q) {
                C0472q qVar = (C0472q) obj;
                Object j = qVar.mo1417j();
                if (j != C0472q.f1037h) {
                    return (Runnable) j;
                }
                C0440c.m1537a(f1235h, this, obj, qVar.mo1416i());
            } else if (obj == C0640d1.f1245b) {
                return null;
            } else {
                if (C0440c.m1537a(f1235h, this, obj, (Object) null)) {
                    return (Runnable) obj;
                }
            }
        }
    }

    /* renamed from: H */
    private final boolean m2001H(Runnable runnable) {
        while (true) {
            Object obj = this._queue;
            if (m2002I()) {
                return false;
            }
            if (obj == null) {
                if (C0440c.m1537a(f1235h, this, (Object) null, runnable)) {
                    return true;
                }
            } else if (obj instanceof C0472q) {
                C0472q qVar = (C0472q) obj;
                int a = qVar.mo1412a(runnable);
                if (a == 0) {
                    return true;
                }
                if (a == 1) {
                    C0440c.m1537a(f1235h, this, obj, qVar.mo1416i());
                } else if (a == 2) {
                    return false;
                }
            } else if (obj == C0640d1.f1245b) {
                return false;
            } else {
                C0472q qVar2 = new C0472q(8, true);
                qVar2.mo1412a((Runnable) obj);
                qVar2.mo1412a(runnable);
                if (C0440c.m1537a(f1235h, this, obj, qVar2)) {
                    return true;
                }
            }
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [int, boolean] */
    /* access modifiers changed from: private */
    /* renamed from: I */
    public final boolean m2002I() {
        return this._isCompleted;
    }

    /* renamed from: L */
    private final void m2003L() {
        C0634c.m2028a();
        long nanoTime = System.nanoTime();
        while (true) {
            C0628b bVar = (C0628b) this._delayed;
            C0627a aVar = bVar == null ? null : (C0627a) bVar.mo1367i();
            if (aVar != null) {
                mo1582B(nanoTime, aVar);
            } else {
                return;
            }
        }
    }

    /* renamed from: O */
    private final int m2004O(long j, C0627a aVar) {
        if (m2002I()) {
            return 1;
        }
        C0628b bVar = (C0628b) this._delayed;
        if (bVar == null) {
            C0440c.m1537a(f1236i, this, (Object) null, new C0628b(j));
            Object obj = this._delayed;
            C0429i.m1494b(obj);
            bVar = (C0628b) obj;
        }
        return aVar.mo1575h(j, bVar, this);
    }

    /* renamed from: P */
    private final void m2005P(boolean z) {
        this._isCompleted = z ? 1 : 0;
    }

    /* renamed from: Q */
    private final boolean m2006Q(C0627a aVar) {
        C0628b bVar = (C0628b) this._delayed;
        return (bVar == null ? null : (C0627a) bVar.mo1364e()) == aVar;
    }

    /* renamed from: G */
    public final void mo1565G(Runnable runnable) {
        if (m2001H(runnable)) {
            mo1583C();
        } else {
            C0699r0.f1294j.mo1565G(runnable);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: J */
    public boolean mo1566J() {
        if (!mo1705x()) {
            return false;
        }
        C0628b bVar = (C0628b) this._delayed;
        if (bVar != null && !bVar.mo1363d()) {
            return false;
        }
        Object obj = this._queue;
        if (obj != null) {
            return obj instanceof C0472q ? ((C0472q) obj).mo1415g() : obj == C0640d1.f1245b;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:29:0x004b  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x004f  */
    /* renamed from: K */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public long mo1567K() {
        /*
            r9 = this;
            boolean r0 = r9.mo1706y()
            r1 = 0
            if (r0 == 0) goto L_0x0009
            return r1
        L_0x0009:
            java.lang.Object r0 = r9._delayed
            v0.a1$b r0 = (p046v0.C0626a1.C0628b) r0
            if (r0 == 0) goto L_0x0045
            boolean r3 = r0.mo1363d()
            if (r3 != 0) goto L_0x0045
            p046v0.C0634c.m2028a()
            long r3 = java.lang.System.nanoTime()
        L_0x001c:
            monitor-enter(r0)
            kotlinx.coroutines.internal.f0 r5 = r0.mo1361b()     // Catch:{ all -> 0x0042 }
            r6 = 0
            if (r5 != 0) goto L_0x0026
        L_0x0024:
            monitor-exit(r0)
            goto L_0x003d
        L_0x0026:
            v0.a1$a r5 = (p046v0.C0626a1.C0627a) r5     // Catch:{ all -> 0x0042 }
            boolean r7 = r5.mo1576i(r3)     // Catch:{ all -> 0x0042 }
            r8 = 0
            if (r7 == 0) goto L_0x0034
            boolean r5 = r9.m2001H(r5)     // Catch:{ all -> 0x0042 }
            goto L_0x0035
        L_0x0034:
            r5 = 0
        L_0x0035:
            if (r5 == 0) goto L_0x0024
            kotlinx.coroutines.internal.f0 r5 = r0.mo1366h(r8)     // Catch:{ all -> 0x0042 }
            r6 = r5
            goto L_0x0024
        L_0x003d:
            v0.a1$a r6 = (p046v0.C0626a1.C0627a) r6
            if (r6 != 0) goto L_0x001c
            goto L_0x0045
        L_0x0042:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
        L_0x0045:
            java.lang.Runnable r0 = r9.m2000F()
            if (r0 == 0) goto L_0x004f
            r0.run()
            return r1
        L_0x004f:
            long r0 = r9.mo1570t()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p046v0.C0626a1.mo1567K():long");
    }

    /* access modifiers changed from: protected */
    /* renamed from: M */
    public final void mo1568M() {
        this._queue = null;
        this._delayed = null;
    }

    /* renamed from: N */
    public final void mo1569N(long j, C0627a aVar) {
        int O = m2004O(j, aVar);
        if (O != 0) {
            if (O == 1) {
                mo1582B(j, aVar);
            } else if (O != 2) {
                throw new IllegalStateException("unexpected result".toString());
            }
        } else if (m2006Q(aVar)) {
            mo1583C();
        }
    }

    /* renamed from: m */
    public final void mo1422m(C0195g gVar, Runnable runnable) {
        mo1565G(runnable);
    }

    /* access modifiers changed from: protected */
    /* renamed from: t */
    public long mo1570t() {
        if (super.mo1570t() == 0) {
            return 0;
        }
        Object obj = this._queue;
        if (obj != null) {
            if (!(obj instanceof C0472q)) {
                return obj == C0640d1.f1245b ? Long.MAX_VALUE : 0;
            }
            if (!((C0472q) obj).mo1415g()) {
                return 0;
            }
        }
        C0628b bVar = (C0628b) this._delayed;
        C0627a aVar = bVar == null ? null : (C0627a) bVar.mo1364e();
        if (aVar == null) {
            return Long.MAX_VALUE;
        }
        long j = aVar.f1237d;
        C0634c.m2028a();
        return C0578f.m1877b(j - System.nanoTime(), 0);
    }

    /* access modifiers changed from: protected */
    /* renamed from: z */
    public void mo1571z() {
        C0653f2.f1252a.mo1593b();
        m2005P(true);
        m1999E();
        do {
        } while (mo1567K() <= 0);
        m2003L();
    }
}
