package p046v0;

import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.C0429i;

/* renamed from: v0.p1 */
public final class C0694p1 extends CancellationException implements C0639d0<C0694p1> {

    /* renamed from: d */
    public final C0689o1 f1292d;

    public C0694p1(String str, Throwable th, C0689o1 o1Var) {
        super(str);
        this.f1292d = o1Var;
        if (th != null) {
            initCause(th);
        }
    }

    /* renamed from: b */
    public C0694p1 mo1586a() {
        if (!C0693p0.m2155c()) {
            return null;
        }
        String message = getMessage();
        C0429i.m1494b(message);
        return new C0694p1(message, this, this.f1292d);
    }

    public boolean equals(Object obj) {
        if (obj != this) {
            if (obj instanceof C0694p1) {
                C0694p1 p1Var = (C0694p1) obj;
                if (!C0429i.m1493a(p1Var.getMessage(), getMessage()) || !C0429i.m1493a(p1Var.f1292d, this.f1292d) || !C0429i.m1493a(p1Var.getCause(), getCause())) {
                    return false;
                }
            }
            return false;
        }
        return true;
    }

    public Throwable fillInStackTrace() {
        if (C0693p0.m2155c()) {
            return super.fillInStackTrace();
        }
        setStackTrace(new StackTraceElement[0]);
        return this;
    }

    public int hashCode() {
        String message = getMessage();
        C0429i.m1494b(message);
        int hashCode = ((message.hashCode() * 31) + this.f1292d.hashCode()) * 31;
        Throwable cause = getCause();
        return hashCode + (cause == null ? 0 : cause.hashCode());
    }

    public String toString() {
        return super.toString() + "; job=" + this.f1292d;
    }
}
