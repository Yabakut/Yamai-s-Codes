package p046v0;

/* renamed from: v0.b2 */
public interface C0633b2 {
}
