package p046v0;

import kotlinx.coroutines.internal.C0475r;
import kotlinx.coroutines.scheduling.C0490b;

/* renamed from: v0.w0 */
public final class C0717w0 {

    /* renamed from: a */
    public static final C0717w0 f1315a = new C0717w0();

    /* renamed from: b */
    private static final C0647f0 f1316b = C0643e0.m2039a();

    /* renamed from: c */
    private static final C0647f0 f1317c = C0657g2.f1256e;

    /* renamed from: d */
    private static final C0647f0 f1318d = C0490b.f1084k.mo1456r();

    private C0717w0() {
    }

    /* renamed from: a */
    public static final C0647f0 m2289a() {
        return f1316b;
    }

    /* renamed from: b */
    public static final C0647f0 m2290b() {
        return f1318d;
    }

    /* renamed from: c */
    public static final C0724y1 m2291c() {
        return C0475r.f1045c;
    }
}
