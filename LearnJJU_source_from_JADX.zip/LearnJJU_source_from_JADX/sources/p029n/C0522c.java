package p029n;

import p029n.C0523d;

/* renamed from: n.c */
public final /* synthetic */ class C0522c implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ C0523d.C0524a f1164d;

    public /* synthetic */ C0522c(C0523d.C0524a aVar) {
        this.f1164d = aVar;
    }

    public final void run() {
        this.f1164d.m1815c();
    }
}
