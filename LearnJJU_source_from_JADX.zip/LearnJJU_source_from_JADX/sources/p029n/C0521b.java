package p029n;

/* renamed from: n.b */
public final class C0521b {

    /* renamed from: a */
    public final String f1157a;

    /* renamed from: b */
    public final String f1158b;

    /* renamed from: c */
    public final String f1159c;

    /* renamed from: d */
    public final String f1160d;

    /* renamed from: e */
    public final String f1161e;

    /* renamed from: f */
    public final String f1162f;

    /* renamed from: g */
    final boolean f1163g;

    public C0521b(String str, String str2, String str3, String str4, String str5, String str6, boolean z) {
        this.f1157a = str == null ? "libapp.so" : str;
        this.f1158b = str2 == null ? "vm_snapshot_data" : str2;
        this.f1159c = str3 == null ? "isolate_snapshot_data" : str3;
        this.f1160d = str4 == null ? "flutter_assets" : str4;
        this.f1162f = str6;
        this.f1161e = str5 == null ? "" : str5;
        this.f1163g = z;
    }
}
