package p029n;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.SystemClock;
import android.view.WindowManager;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import p009d0.C0112b;
import p009d0.C0115e;
import p020io.flutter.embedding.engine.FlutterJNI;
import p020io.flutter.view.C0386e;
import p023k.C0401a;

/* renamed from: n.d */
public class C0523d {

    /* renamed from: a */
    private boolean f1165a;

    /* renamed from: b */
    private C0526c f1166b;

    /* renamed from: c */
    private long f1167c;

    /* renamed from: d */
    private C0521b f1168d;
    /* access modifiers changed from: private */

    /* renamed from: e */
    public FlutterJNI f1169e;
    /* access modifiers changed from: private */

    /* renamed from: f */
    public ExecutorService f1170f;

    /* renamed from: g */
    Future<C0525b> f1171g;

    /* renamed from: n.d$a */
    class C0524a implements Callable<C0525b> {

        /* renamed from: a */
        final /* synthetic */ Context f1172a;

        C0524a(Context context) {
            this.f1172a = context;
        }

        /* access modifiers changed from: private */
        /* renamed from: c */
        public /* synthetic */ void m1815c() {
            C0523d.this.f1169e.prefetchDefaultFontManager();
        }

        /* renamed from: b */
        public C0525b call() {
            C0115e.m393a("FlutterLoader initTask");
            try {
                C0527e unused = C0523d.this.m1807g(this.f1172a);
                C0523d.this.f1169e.loadLibrary();
                C0523d.this.f1169e.updateRefreshRate();
                C0523d.this.f1170f.execute(new C0522c(this));
                return new C0525b(C0112b.m391d(this.f1172a), C0112b.m388a(this.f1172a), C0112b.m390c(this.f1172a), (C0524a) null);
            } finally {
                C0115e.m394b();
            }
        }
    }

    /* renamed from: n.d$b */
    private static class C0525b {

        /* renamed from: a */
        final String f1174a;

        /* renamed from: b */
        final String f1175b;

        /* renamed from: c */
        final String f1176c;

        private C0525b(String str, String str2, String str3) {
            this.f1174a = str;
            this.f1175b = str2;
            this.f1176c = str3;
        }

        /* synthetic */ C0525b(String str, String str2, String str3, C0524a aVar) {
            this(str, str2, str3);
        }
    }

    /* renamed from: n.d$c */
    public static class C0526c {

        /* renamed from: a */
        private String f1177a;

        /* renamed from: a */
        public String mo1505a() {
            return this.f1177a;
        }
    }

    public C0523d() {
        this(C0401a.m1455e().mo1286d().mo922a());
    }

    public C0523d(FlutterJNI flutterJNI) {
        this(flutterJNI, C0401a.m1455e().mo1284b());
    }

    public C0523d(FlutterJNI flutterJNI, ExecutorService executorService) {
        this.f1165a = false;
        this.f1169e = flutterJNI;
        this.f1170f = executorService;
    }

    /* access modifiers changed from: private */
    /* renamed from: g */
    public C0527e m1807g(Context context) {
        return null;
    }

    /* renamed from: h */
    private static boolean m1808h(Bundle bundle) {
        if (bundle == null) {
            return true;
        }
        return bundle.getBoolean("io.flutter.embedding.android.LeakVM", true);
    }

    /* renamed from: d */
    public boolean mo1498d() {
        return this.f1168d.f1163g;
    }

    /* JADX WARNING: Removed duplicated region for block: B:40:0x0194 A[Catch:{ Exception -> 0x01d1, all -> 0x01cf }] */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x0197 A[Catch:{ Exception -> 0x01d1, all -> 0x01cf }] */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1499e(android.content.Context r10, java.lang.String[] r11) {
        /*
            r9 = this;
            java.lang.String r0 = "--aot-shared-library-name="
            boolean r1 = r9.f1165a
            if (r1 == 0) goto L_0x0007
            return
        L_0x0007:
            android.os.Looper r1 = android.os.Looper.myLooper()
            android.os.Looper r2 = android.os.Looper.getMainLooper()
            if (r1 != r2) goto L_0x01eb
            n.d$c r1 = r9.f1166b
            if (r1 == 0) goto L_0x01e3
            java.lang.String r1 = "FlutterLoader#ensureInitializationComplete"
            p009d0.C0115e.m393a(r1)
            java.util.concurrent.Future<n.d$b> r1 = r9.f1171g     // Catch:{ Exception -> 0x01d1 }
            java.lang.Object r1 = r1.get()     // Catch:{ Exception -> 0x01d1 }
            n.d$b r1 = (p029n.C0523d.C0525b) r1     // Catch:{ Exception -> 0x01d1 }
            java.util.ArrayList r2 = new java.util.ArrayList     // Catch:{ Exception -> 0x01d1 }
            r2.<init>()     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r3 = "--icu-symbol-prefix=_binary_icudtl_dat"
            r2.add(r3)     // Catch:{ Exception -> 0x01d1 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01d1 }
            r3.<init>()     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r4 = "--icu-native-lib-path="
            r3.append(r4)     // Catch:{ Exception -> 0x01d1 }
            n.b r4 = r9.f1168d     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r4 = r4.f1162f     // Catch:{ Exception -> 0x01d1 }
            r3.append(r4)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r4 = java.io.File.separator     // Catch:{ Exception -> 0x01d1 }
            r3.append(r4)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r5 = "libflutter.so"
            r3.append(r5)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x01d1 }
            r2.add(r3)     // Catch:{ Exception -> 0x01d1 }
            if (r11 == 0) goto L_0x0053
            java.util.Collections.addAll(r2, r11)     // Catch:{ Exception -> 0x01d1 }
        L_0x0053:
            r3 = 0
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01d1 }
            r11.<init>()     // Catch:{ Exception -> 0x01d1 }
            r11.append(r0)     // Catch:{ Exception -> 0x01d1 }
            n.b r5 = r9.f1168d     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r5 = r5.f1157a     // Catch:{ Exception -> 0x01d1 }
            r11.append(r5)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r11 = r11.toString()     // Catch:{ Exception -> 0x01d1 }
            r2.add(r11)     // Catch:{ Exception -> 0x01d1 }
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01d1 }
            r11.<init>()     // Catch:{ Exception -> 0x01d1 }
            r11.append(r0)     // Catch:{ Exception -> 0x01d1 }
            n.b r0 = r9.f1168d     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r0 = r0.f1162f     // Catch:{ Exception -> 0x01d1 }
            r11.append(r0)     // Catch:{ Exception -> 0x01d1 }
            r11.append(r4)     // Catch:{ Exception -> 0x01d1 }
            n.b r0 = r9.f1168d     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r0 = r0.f1157a     // Catch:{ Exception -> 0x01d1 }
            r11.append(r0)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r11 = r11.toString()     // Catch:{ Exception -> 0x01d1 }
            r2.add(r11)     // Catch:{ Exception -> 0x01d1 }
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01d1 }
            r11.<init>()     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r0 = "--cache-dir-path="
            r11.append(r0)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r0 = r1.f1175b     // Catch:{ Exception -> 0x01d1 }
            r11.append(r0)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r11 = r11.toString()     // Catch:{ Exception -> 0x01d1 }
            r2.add(r11)     // Catch:{ Exception -> 0x01d1 }
            n.b r11 = r9.f1168d     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r11 = r11.f1161e     // Catch:{ Exception -> 0x01d1 }
            if (r11 == 0) goto L_0x00be
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01d1 }
            r11.<init>()     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r0 = "--domain-network-policy="
            r11.append(r0)     // Catch:{ Exception -> 0x01d1 }
            n.b r0 = r9.f1168d     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r0 = r0.f1161e     // Catch:{ Exception -> 0x01d1 }
            r11.append(r0)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r11 = r11.toString()     // Catch:{ Exception -> 0x01d1 }
            r2.add(r11)     // Catch:{ Exception -> 0x01d1 }
        L_0x00be:
            n.d$c r11 = r9.f1166b     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r11 = r11.mo1505a()     // Catch:{ Exception -> 0x01d1 }
            if (r11 == 0) goto L_0x00e0
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01d1 }
            r11.<init>()     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r0 = "--log-tag="
            r11.append(r0)     // Catch:{ Exception -> 0x01d1 }
            n.d$c r0 = r9.f1166b     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r0 = r0.mo1505a()     // Catch:{ Exception -> 0x01d1 }
            r11.append(r0)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r11 = r11.toString()     // Catch:{ Exception -> 0x01d1 }
            r2.add(r11)     // Catch:{ Exception -> 0x01d1 }
        L_0x00e0:
            android.content.pm.PackageManager r11 = r10.getPackageManager()     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r0 = r10.getPackageName()     // Catch:{ Exception -> 0x01d1 }
            r4 = 128(0x80, float:1.794E-43)
            android.content.pm.ApplicationInfo r11 = r11.getApplicationInfo(r0, r4)     // Catch:{ Exception -> 0x01d1 }
            android.os.Bundle r11 = r11.metaData     // Catch:{ Exception -> 0x01d1 }
            r0 = 0
            if (r11 == 0) goto L_0x00fa
            java.lang.String r4 = "io.flutter.embedding.android.OldGenHeapSize"
            int r4 = r11.getInt(r4)     // Catch:{ Exception -> 0x01d1 }
            goto L_0x00fb
        L_0x00fa:
            r4 = 0
        L_0x00fb:
            if (r4 != 0) goto L_0x011d
            java.lang.String r4 = "activity"
            java.lang.Object r4 = r10.getSystemService(r4)     // Catch:{ Exception -> 0x01d1 }
            android.app.ActivityManager r4 = (android.app.ActivityManager) r4     // Catch:{ Exception -> 0x01d1 }
            android.app.ActivityManager$MemoryInfo r5 = new android.app.ActivityManager$MemoryInfo     // Catch:{ Exception -> 0x01d1 }
            r5.<init>()     // Catch:{ Exception -> 0x01d1 }
            r4.getMemoryInfo(r5)     // Catch:{ Exception -> 0x01d1 }
            long r4 = r5.totalMem     // Catch:{ Exception -> 0x01d1 }
            double r4 = (double) r4
            r6 = 4696837146684686336(0x412e848000000000, double:1000000.0)
            java.lang.Double.isNaN(r4)
            double r4 = r4 / r6
            r6 = 4611686018427387904(0x4000000000000000, double:2.0)
            double r4 = r4 / r6
            int r4 = (int) r4
        L_0x011d:
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01d1 }
            r5.<init>()     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r6 = "--old-gen-heap-size="
            r5.append(r6)     // Catch:{ Exception -> 0x01d1 }
            r5.append(r4)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r4 = r5.toString()     // Catch:{ Exception -> 0x01d1 }
            r2.add(r4)     // Catch:{ Exception -> 0x01d1 }
            android.content.res.Resources r4 = r10.getResources()     // Catch:{ Exception -> 0x01d1 }
            android.util.DisplayMetrics r4 = r4.getDisplayMetrics()     // Catch:{ Exception -> 0x01d1 }
            int r5 = r4.widthPixels     // Catch:{ Exception -> 0x01d1 }
            int r4 = r4.heightPixels     // Catch:{ Exception -> 0x01d1 }
            int r5 = r5 * r4
            int r5 = r5 * 12
            int r5 = r5 * 4
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01d1 }
            r4.<init>()     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r6 = "--resource-cache-max-bytes-threshold="
            r4.append(r6)     // Catch:{ Exception -> 0x01d1 }
            r4.append(r5)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r4 = r4.toString()     // Catch:{ Exception -> 0x01d1 }
            r2.add(r4)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r4 = "--prefetched-default-font-manager"
            r2.add(r4)     // Catch:{ Exception -> 0x01d1 }
            r8 = 1
            if (r11 == 0) goto L_0x016a
            java.lang.String r4 = "io.flutter.embedding.android.EnableSkParagraph"
            boolean r4 = r11.getBoolean(r4, r8)     // Catch:{ Exception -> 0x01d1 }
            if (r4 == 0) goto L_0x0168
            goto L_0x016a
        L_0x0168:
            r4 = 0
            goto L_0x016b
        L_0x016a:
            r4 = 1
        L_0x016b:
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01d1 }
            r5.<init>()     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r6 = "--enable-skparagraph="
            r5.append(r6)     // Catch:{ Exception -> 0x01d1 }
            r5.append(r4)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r4 = r5.toString()     // Catch:{ Exception -> 0x01d1 }
            r2.add(r4)     // Catch:{ Exception -> 0x01d1 }
            if (r11 == 0) goto L_0x018e
            java.lang.String r4 = "io.flutter.embedding.android.EnableImpeller"
            boolean r4 = r11.getBoolean(r4, r0)     // Catch:{ Exception -> 0x01d1 }
            if (r4 == 0) goto L_0x018e
            java.lang.String r4 = "--enable-impeller"
            r2.add(r4)     // Catch:{ Exception -> 0x01d1 }
        L_0x018e:
            boolean r11 = m1808h(r11)     // Catch:{ Exception -> 0x01d1 }
            if (r11 == 0) goto L_0x0197
            java.lang.String r11 = "true"
            goto L_0x0199
        L_0x0197:
            java.lang.String r11 = "false"
        L_0x0199:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01d1 }
            r4.<init>()     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r5 = "--leak-vm="
            r4.append(r5)     // Catch:{ Exception -> 0x01d1 }
            r4.append(r11)     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r11 = r4.toString()     // Catch:{ Exception -> 0x01d1 }
            r2.add(r11)     // Catch:{ Exception -> 0x01d1 }
            long r4 = android.os.SystemClock.uptimeMillis()     // Catch:{ Exception -> 0x01d1 }
            long r6 = r9.f1167c     // Catch:{ Exception -> 0x01d1 }
            long r6 = r4 - r6
            io.flutter.embedding.engine.FlutterJNI r11 = r9.f1169e     // Catch:{ Exception -> 0x01d1 }
            java.lang.String[] r0 = new java.lang.String[r0]     // Catch:{ Exception -> 0x01d1 }
            java.lang.Object[] r0 = r2.toArray(r0)     // Catch:{ Exception -> 0x01d1 }
            r2 = r0
            java.lang.String[] r2 = (java.lang.String[]) r2     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r4 = r1.f1174a     // Catch:{ Exception -> 0x01d1 }
            java.lang.String r5 = r1.f1175b     // Catch:{ Exception -> 0x01d1 }
            r0 = r11
            r1 = r10
            r0.init(r1, r2, r3, r4, r5, r6)     // Catch:{ Exception -> 0x01d1 }
            r9.f1165a = r8     // Catch:{ Exception -> 0x01d1 }
            p009d0.C0115e.m394b()
            return
        L_0x01cf:
            r10 = move-exception
            goto L_0x01df
        L_0x01d1:
            r10 = move-exception
            java.lang.String r11 = "FlutterLoader"
            java.lang.String r0 = "Flutter initialization failed."
            p023k.C0405b.m1464c(r11, r0, r10)     // Catch:{ all -> 0x01cf }
            java.lang.RuntimeException r11 = new java.lang.RuntimeException     // Catch:{ all -> 0x01cf }
            r11.<init>(r10)     // Catch:{ all -> 0x01cf }
            throw r11     // Catch:{ all -> 0x01cf }
        L_0x01df:
            p009d0.C0115e.m394b()
            throw r10
        L_0x01e3:
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r11 = "ensureInitializationComplete must be called after startInitialization"
            r10.<init>(r11)
            throw r10
        L_0x01eb:
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r11 = "ensureInitializationComplete must be called on the main thread"
            r10.<init>(r11)
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: p029n.C0523d.mo1499e(android.content.Context, java.lang.String[]):void");
    }

    /* renamed from: f */
    public String mo1500f() {
        return this.f1168d.f1160d;
    }

    /* renamed from: i */
    public void mo1501i(Context context) {
        mo1502j(context, new C0526c());
    }

    /* renamed from: j */
    public void mo1502j(Context context, C0526c cVar) {
        if (this.f1166b == null) {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                C0115e.m393a("FlutterLoader#startInitialization");
                try {
                    Context applicationContext = context.getApplicationContext();
                    this.f1166b = cVar;
                    this.f1167c = SystemClock.uptimeMillis();
                    this.f1168d = C0520a.m1800e(applicationContext);
                    (Build.VERSION.SDK_INT >= 17 ? C0386e.m1427e((DisplayManager) applicationContext.getSystemService("display"), this.f1169e) : C0386e.m1426d(((WindowManager) applicationContext.getSystemService("window")).getDefaultDisplay().getRefreshRate(), this.f1169e)).mo1266f();
                    this.f1171g = this.f1170f.submit(new C0524a(applicationContext));
                } finally {
                    C0115e.m394b();
                }
            } else {
                throw new IllegalStateException("startInitialization must be called on the main thread");
            }
        }
    }
}
