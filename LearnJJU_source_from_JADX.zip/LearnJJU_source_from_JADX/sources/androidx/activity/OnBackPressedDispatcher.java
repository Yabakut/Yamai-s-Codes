package androidx.activity;

import androidx.lifecycle.C0051d;
import androidx.lifecycle.C0055e;
import androidx.lifecycle.C0057g;

public final class OnBackPressedDispatcher {

    private class LifecycleOnBackPressedCancellable implements C0055e, C0012a {

        /* renamed from: a */
        private final C0051d f20a;

        /* renamed from: b */
        private C0012a f21b;

        public void cancel() {
            this.f20a.mo108c(this);
            throw null;
        }

        /* renamed from: g */
        public void mo11g(C0057g gVar, C0051d.C0053b bVar) {
            if (bVar == C0051d.C0053b.ON_START) {
                throw null;
            } else if (bVar == C0051d.C0053b.ON_STOP) {
                C0012a aVar = this.f21b;
                if (aVar != null) {
                    aVar.cancel();
                }
            } else if (bVar == C0051d.C0053b.ON_DESTROY) {
                cancel();
            }
        }
    }
}
