package androidx.activity;

import androidx.lifecycle.C0057g;

/* renamed from: androidx.activity.b */
public interface C0013b extends C0057g {
    /* renamed from: i */
    OnBackPressedDispatcher mo13i();
}
