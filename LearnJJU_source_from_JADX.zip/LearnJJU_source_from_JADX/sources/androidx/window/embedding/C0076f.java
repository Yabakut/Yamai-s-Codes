package androidx.window.embedding;

import android.content.Intent;
import java.util.Set;
import java.util.function.Predicate;

/* renamed from: androidx.window.embedding.f */
public final /* synthetic */ class C0076f implements Predicate {

    /* renamed from: a */
    public final /* synthetic */ Set f208a;

    public /* synthetic */ C0076f(Set set) {
        this.f208a = set;
    }

    public final boolean test(Object obj) {
        return EmbeddingAdapter.m2745translateIntentPredicates$lambda8(this.f208a, (Intent) obj);
    }
}
