package androidx.window.embedding;

import android.app.Activity;
import java.util.Set;
import java.util.function.Predicate;

/* renamed from: androidx.window.embedding.e */
public final /* synthetic */ class C0075e implements Predicate {

    /* renamed from: a */
    public final /* synthetic */ Set f207a;

    public /* synthetic */ C0075e(Set set) {
        this.f207a = set;
    }

    public final boolean test(Object obj) {
        return EmbeddingAdapter.m2744translateActivityPredicates$lambda6(this.f207a, (Activity) obj);
    }
}
