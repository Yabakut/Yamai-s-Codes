package androidx.window.embedding;

import androidx.window.embedding.ExtensionEmbeddingBackend;
import java.util.List;

/* renamed from: androidx.window.embedding.g */
public final /* synthetic */ class C0077g implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ ExtensionEmbeddingBackend.SplitListenerWrapper f209d;

    /* renamed from: e */
    public final /* synthetic */ List f210e;

    public /* synthetic */ C0077g(ExtensionEmbeddingBackend.SplitListenerWrapper splitListenerWrapper, List list) {
        this.f209d = splitListenerWrapper;
        this.f210e = list;
    }

    public final void run() {
        ExtensionEmbeddingBackend.SplitListenerWrapper.m2747accept$lambda1(this.f209d, this.f210e);
    }
}
