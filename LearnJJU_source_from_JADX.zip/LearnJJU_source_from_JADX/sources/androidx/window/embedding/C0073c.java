package androidx.window.embedding;

import android.util.Pair;
import java.util.Set;
import java.util.function.Predicate;

/* renamed from: androidx.window.embedding.c */
public final /* synthetic */ class C0073c implements Predicate {

    /* renamed from: a */
    public final /* synthetic */ EmbeddingAdapter f204a;

    /* renamed from: b */
    public final /* synthetic */ Set f205b;

    public /* synthetic */ C0073c(EmbeddingAdapter embeddingAdapter, Set set) {
        this.f204a = embeddingAdapter;
        this.f205b = set;
    }

    public final boolean test(Object obj) {
        return EmbeddingAdapter.m2743translateActivityPairPredicates$lambda1(this.f204a, this.f205b, (Pair) obj);
    }
}
