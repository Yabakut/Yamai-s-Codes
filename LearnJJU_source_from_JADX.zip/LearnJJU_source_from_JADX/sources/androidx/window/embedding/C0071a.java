package androidx.window.embedding;

/* renamed from: androidx.window.embedding.a */
public final /* synthetic */ class C0071a {
    /* renamed from: a */
    public static /* synthetic */ int m297a(boolean z) {
        return z ? 1231 : 1237;
    }
}
