package androidx.window.embedding;

import android.util.Pair;
import java.util.Set;
import java.util.function.Predicate;

/* renamed from: androidx.window.embedding.b */
public final /* synthetic */ class C0072b implements Predicate {

    /* renamed from: a */
    public final /* synthetic */ EmbeddingAdapter f202a;

    /* renamed from: b */
    public final /* synthetic */ Set f203b;

    public /* synthetic */ C0072b(EmbeddingAdapter embeddingAdapter, Set set) {
        this.f202a = embeddingAdapter;
        this.f203b = set;
    }

    public final boolean test(Object obj) {
        return EmbeddingAdapter.m2742translateActivityIntentPredicates$lambda3(this.f202a, this.f203b, (Pair) obj);
    }
}
