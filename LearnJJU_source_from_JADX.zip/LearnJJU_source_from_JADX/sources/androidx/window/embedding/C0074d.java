package androidx.window.embedding;

import android.view.WindowMetrics;
import java.util.function.Predicate;

/* renamed from: androidx.window.embedding.d */
public final /* synthetic */ class C0074d implements Predicate {

    /* renamed from: a */
    public final /* synthetic */ SplitRule f206a;

    public /* synthetic */ C0074d(SplitRule splitRule) {
        this.f206a = splitRule;
    }

    public final boolean test(Object obj) {
        return EmbeddingAdapter.m2746translateParentMetricsPredicate$lambda4(this.f206a, (WindowMetrics) obj);
    }
}
