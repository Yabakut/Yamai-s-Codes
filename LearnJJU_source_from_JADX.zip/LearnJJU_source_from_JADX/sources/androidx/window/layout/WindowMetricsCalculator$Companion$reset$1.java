package androidx.window.layout;

import kotlin.jvm.internal.C0429i;
import kotlin.jvm.internal.C0430j;
import p032o0.C0543l;

final class WindowMetricsCalculator$Companion$reset$1 extends C0430j implements C0543l<WindowMetricsCalculator, WindowMetricsCalculator> {
    public static final WindowMetricsCalculator$Companion$reset$1 INSTANCE = new WindowMetricsCalculator$Companion$reset$1();

    WindowMetricsCalculator$Companion$reset$1() {
        super(1);
    }

    public final WindowMetricsCalculator invoke(WindowMetricsCalculator windowMetricsCalculator) {
        C0429i.m1496d(windowMetricsCalculator, "it");
        return windowMetricsCalculator;
    }
}
