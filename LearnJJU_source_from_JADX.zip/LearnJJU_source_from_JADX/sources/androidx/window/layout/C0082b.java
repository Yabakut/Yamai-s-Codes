package androidx.window.layout;

import android.content.Context;
import androidx.window.layout.WindowInfoTracker;

/* renamed from: androidx.window.layout.b */
public final /* synthetic */ class C0082b {
    static {
        WindowInfoTracker.Companion companion = WindowInfoTracker.Companion;
    }

    /* renamed from: a */
    public static WindowInfoTracker m300a(Context context) {
        return WindowInfoTracker.Companion.getOrCreate(context);
    }

    /* renamed from: b */
    public static void m301b(WindowInfoTrackerDecorator windowInfoTrackerDecorator) {
        WindowInfoTracker.Companion.overrideDecorator(windowInfoTrackerDecorator);
    }

    /* renamed from: c */
    public static void m302c() {
        WindowInfoTracker.Companion.reset();
    }
}
