package androidx.window.layout;

import java.util.concurrent.Executor;

/* renamed from: androidx.window.layout.d */
public final /* synthetic */ class C0084d implements Executor {

    /* renamed from: d */
    public static final /* synthetic */ C0084d f214d = new C0084d();

    private /* synthetic */ C0084d() {
    }

    public final void execute(Runnable runnable) {
        runnable.run();
    }
}
