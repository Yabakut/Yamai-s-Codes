package androidx.window.layout;

import p010e.C0120a;
import p050x0.C0813f;

/* renamed from: androidx.window.layout.c */
public final /* synthetic */ class C0083c implements C0120a {

    /* renamed from: a */
    public final /* synthetic */ C0813f f213a;

    public /* synthetic */ C0083c(C0813f fVar) {
        this.f213a = fVar;
    }

    public final void accept(Object obj) {
        WindowInfoTrackerImpl$windowLayoutInfo$1.m2749invokeSuspend$lambda0(this.f213a, (WindowLayoutInfo) obj);
    }
}
