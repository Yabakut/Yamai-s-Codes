package androidx.window.layout;

import android.app.Activity;
import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0429i;
import p017h0.C0190d;
import p052y0.C0873b;
import p052y0.C0875d;

public final class WindowInfoTrackerImpl implements WindowInfoTracker {
    private static final int BUFFER_CAPACITY = 10;
    public static final Companion Companion = new Companion((C0425e) null);
    /* access modifiers changed from: private */
    public final WindowBackend windowBackend;
    private final WindowMetricsCalculator windowMetricsCalculator;

    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(C0425e eVar) {
            this();
        }
    }

    public WindowInfoTrackerImpl(WindowMetricsCalculator windowMetricsCalculator2, WindowBackend windowBackend2) {
        C0429i.m1496d(windowMetricsCalculator2, "windowMetricsCalculator");
        C0429i.m1496d(windowBackend2, "windowBackend");
        this.windowMetricsCalculator = windowMetricsCalculator2;
        this.windowBackend = windowBackend2;
    }

    public C0873b<WindowLayoutInfo> windowLayoutInfo(Activity activity) {
        C0429i.m1496d(activity, "activity");
        return C0875d.m2724a(new WindowInfoTrackerImpl$windowLayoutInfo$1(this, activity, (C0190d<? super WindowInfoTrackerImpl$windowLayoutInfo$1>) null));
    }
}
