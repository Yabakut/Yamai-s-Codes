package androidx.window.layout;

import kotlin.jvm.internal.C0428h;
import kotlin.jvm.internal.C0429i;
import p032o0.C0543l;

/* synthetic */ class WindowMetricsCalculator$Companion$overrideDecorator$1 extends C0428h implements C0543l<WindowMetricsCalculator, WindowMetricsCalculator> {
    WindowMetricsCalculator$Companion$overrideDecorator$1(Object obj) {
        super(1, obj, WindowMetricsCalculatorDecorator.class, "decorate", "decorate(Landroidx/window/layout/WindowMetricsCalculator;)Landroidx/window/layout/WindowMetricsCalculator;", 0);
    }

    public final WindowMetricsCalculator invoke(WindowMetricsCalculator windowMetricsCalculator) {
        C0429i.m1496d(windowMetricsCalculator, "p0");
        return ((WindowMetricsCalculatorDecorator) this.receiver).decorate(windowMetricsCalculator);
    }
}
