package androidx.window.layout;

import androidx.window.layout.SidecarWindowBackend;

/* renamed from: androidx.window.layout.a */
public final /* synthetic */ class C0081a implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ SidecarWindowBackend.WindowLayoutChangeCallbackWrapper f211d;

    /* renamed from: e */
    public final /* synthetic */ WindowLayoutInfo f212e;

    public /* synthetic */ C0081a(SidecarWindowBackend.WindowLayoutChangeCallbackWrapper windowLayoutChangeCallbackWrapper, WindowLayoutInfo windowLayoutInfo) {
        this.f211d = windowLayoutChangeCallbackWrapper;
        this.f212e = windowLayoutInfo;
    }

    public final void run() {
        SidecarWindowBackend.WindowLayoutChangeCallbackWrapper.m2748accept$lambda0(this.f211d, this.f212e);
    }
}
