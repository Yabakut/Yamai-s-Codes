package androidx.window.layout;

import kotlin.jvm.internal.C0429i;

final class EmptyDecorator implements WindowInfoTrackerDecorator {
    public static final EmptyDecorator INSTANCE = new EmptyDecorator();

    private EmptyDecorator() {
    }

    public WindowInfoTracker decorate(WindowInfoTracker windowInfoTracker) {
        C0429i.m1496d(windowInfoTracker, "tracker");
        return windowInfoTracker;
    }
}
