package androidx.window.layout;

import android.app.Activity;
import java.util.concurrent.Executor;
import p010e.C0120a;

public interface WindowBackend {
    void registerLayoutChangeCallback(Activity activity, Executor executor, C0120a<WindowLayoutInfo> aVar);

    void unregisterLayoutChangeCallback(C0120a<WindowLayoutInfo> aVar);
}
