package androidx.window;

import com.example.learn.R;

/* renamed from: androidx.window.R */
public final class C0069R {

    /* renamed from: androidx.window.R$attr */
    public static final class attr {
        public static final int activityAction = 2130771968;
        public static final int activityName = 2130771969;
        public static final int alwaysExpand = 2130771971;
        public static final int clearTop = 2130771972;
        public static final int finishPrimaryWithSecondary = 2130771973;
        public static final int finishSecondaryWithPrimary = 2130771974;
        public static final int placeholderActivityName = 2130771988;
        public static final int primaryActivityName = 2130771989;
        public static final int secondaryActivityAction = 2130771991;
        public static final int secondaryActivityName = 2130771992;
        public static final int splitLayoutDirection = 2130771994;
        public static final int splitMinSmallestWidth = 2130771995;
        public static final int splitMinWidth = 2130771996;
        public static final int splitRatio = 2130771997;

        private attr() {
        }
    }

    /* renamed from: androidx.window.R$id */
    public static final class C0070id {
        public static final int androidx_window_activity_scope = 2131034150;
        public static final int locale = 2131034162;
        public static final int ltr = 2131034163;
        public static final int rtl = 2131034170;

        private C0070id() {
        }
    }

    /* renamed from: androidx.window.R$styleable */
    public static final class styleable {
        public static final int[] ActivityFilter = {R.attr.activityAction, R.attr.activityName};
        public static final int ActivityFilter_activityAction = 0;
        public static final int ActivityFilter_activityName = 1;
        public static final int[] ActivityRule = {R.attr.alwaysExpand};
        public static final int ActivityRule_alwaysExpand = 0;
        public static final int[] SplitPairFilter = {R.attr.primaryActivityName, R.attr.secondaryActivityAction, R.attr.secondaryActivityName};
        public static final int SplitPairFilter_primaryActivityName = 0;
        public static final int SplitPairFilter_secondaryActivityAction = 1;
        public static final int SplitPairFilter_secondaryActivityName = 2;
        public static final int[] SplitPairRule = {R.attr.clearTop, R.attr.finishPrimaryWithSecondary, R.attr.finishSecondaryWithPrimary, R.attr.splitLayoutDirection, R.attr.splitMinSmallestWidth, R.attr.splitMinWidth, R.attr.splitRatio};
        public static final int SplitPairRule_clearTop = 0;
        public static final int SplitPairRule_finishPrimaryWithSecondary = 1;
        public static final int SplitPairRule_finishSecondaryWithPrimary = 2;
        public static final int SplitPairRule_splitLayoutDirection = 3;
        public static final int SplitPairRule_splitMinSmallestWidth = 4;
        public static final int SplitPairRule_splitMinWidth = 5;
        public static final int SplitPairRule_splitRatio = 6;
        public static final int[] SplitPlaceholderRule = {R.attr.placeholderActivityName, R.attr.splitLayoutDirection, R.attr.splitMinSmallestWidth, R.attr.splitMinWidth, R.attr.splitRatio};
        public static final int SplitPlaceholderRule_placeholderActivityName = 0;
        public static final int SplitPlaceholderRule_splitLayoutDirection = 1;
        public static final int SplitPlaceholderRule_splitMinSmallestWidth = 2;
        public static final int SplitPlaceholderRule_splitMinWidth = 3;
        public static final int SplitPlaceholderRule_splitRatio = 4;

        private styleable() {
        }
    }

    private C0069R() {
    }
}
