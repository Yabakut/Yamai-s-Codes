package androidx.window.java.layout;

import android.app.Activity;
import androidx.window.layout.WindowInfoTracker;
import androidx.window.layout.WindowLayoutInfo;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.jvm.internal.C0429i;
import p010e.C0120a;
import p011e0.C0141q;
import p017h0.C0190d;
import p017h0.C0195g;
import p046v0.C0660h1;
import p046v0.C0681m0;
import p046v0.C0684n0;
import p046v0.C0689o1;
import p052y0.C0873b;

public final class WindowInfoTrackerCallbackAdapter implements WindowInfoTracker {
    private final Map<C0120a<?>, C0689o1> consumerToJobMap = new LinkedHashMap();
    private final ReentrantLock lock = new ReentrantLock();
    private final WindowInfoTracker tracker;

    public WindowInfoTrackerCallbackAdapter(WindowInfoTracker windowInfoTracker) {
        C0429i.m1496d(windowInfoTracker, "tracker");
        this.tracker = windowInfoTracker;
    }

    private final <T> void addListener(Executor executor, C0120a<T> aVar, C0873b<? extends T> bVar) {
        ReentrantLock reentrantLock = this.lock;
        reentrantLock.lock();
        try {
            if (this.consumerToJobMap.get(aVar) == null) {
                this.consumerToJobMap.put(aVar, C0658h.m2066b(C0681m0.m2132a(C0660h1.m2069a(executor)), (C0195g) null, (C0684n0) null, new WindowInfoTrackerCallbackAdapter$addListener$1$1(bVar, aVar, (C0190d<? super WindowInfoTrackerCallbackAdapter$addListener$1$1>) null), 3, (Object) null));
            }
            C0141q qVar = C0141q.f277a;
        } finally {
            reentrantLock.unlock();
        }
    }

    private final void removeListener(C0120a<?> aVar) {
        ReentrantLock reentrantLock = this.lock;
        reentrantLock.lock();
        try {
            C0689o1 o1Var = this.consumerToJobMap.get(aVar);
            if (o1Var != null) {
                C0689o1.C0690a.m2146a(o1Var, (CancellationException) null, 1, (Object) null);
            }
            C0689o1 remove = this.consumerToJobMap.remove(aVar);
        } finally {
            reentrantLock.unlock();
        }
    }

    public final void addWindowLayoutInfoListener(Activity activity, Executor executor, C0120a<WindowLayoutInfo> aVar) {
        C0429i.m1496d(activity, "activity");
        C0429i.m1496d(executor, "executor");
        C0429i.m1496d(aVar, "consumer");
        addListener(executor, aVar, this.tracker.windowLayoutInfo(activity));
    }

    public final void removeWindowLayoutInfoListener(C0120a<WindowLayoutInfo> aVar) {
        C0429i.m1496d(aVar, "consumer");
        removeListener(aVar);
    }

    public C0873b<WindowLayoutInfo> windowLayoutInfo(Activity activity) {
        C0429i.m1496d(activity, "activity");
        return this.tracker.windowLayoutInfo(activity);
    }
}
