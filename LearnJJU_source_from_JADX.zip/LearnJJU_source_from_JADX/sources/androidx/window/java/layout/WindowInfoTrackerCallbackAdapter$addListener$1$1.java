package androidx.window.java.layout;

import kotlin.coroutines.jvm.internal.C0412f;
import kotlin.coroutines.jvm.internal.C0418k;
import p010e.C0120a;
import p011e0.C0136l;
import p011e0.C0141q;
import p017h0.C0190d;
import p032o0.C0547p;
import p046v0.C0678l0;
import p052y0.C0873b;

@C0412f(mo1297c = "androidx.window.java.layout.WindowInfoTrackerCallbackAdapter$addListener$1$1", mo1298f = "WindowInfoTrackerCallbackAdapter.kt", mo1299l = {96}, mo1300m = "invokeSuspend")
final class WindowInfoTrackerCallbackAdapter$addListener$1$1 extends C0418k implements C0547p<C0678l0, C0190d<? super C0141q>, Object> {
    final /* synthetic */ C0120a<T> $consumer;
    final /* synthetic */ C0873b<T> $flow;
    int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    WindowInfoTrackerCallbackAdapter$addListener$1$1(C0873b<? extends T> bVar, C0120a<T> aVar, C0190d<? super WindowInfoTrackerCallbackAdapter$addListener$1$1> dVar) {
        super(2, dVar);
        this.$flow = bVar;
        this.$consumer = aVar;
    }

    public final C0190d<C0141q> create(Object obj, C0190d<?> dVar) {
        return new WindowInfoTrackerCallbackAdapter$addListener$1$1(this.$flow, this.$consumer, dVar);
    }

    public final Object invoke(C0678l0 l0Var, C0190d<? super C0141q> dVar) {
        return ((WindowInfoTrackerCallbackAdapter$addListener$1$1) create(l0Var, dVar)).invokeSuspend(C0141q.f277a);
    }

    public final Object invokeSuspend(Object obj) {
        Object c = C0210d.m564c();
        int i = this.label;
        if (i == 0) {
            C0136l.m422b(obj);
            C0873b<T> bVar = this.$flow;
            C0079x3e71c403 windowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1 = new C0079x3e71c403(this.$consumer);
            this.label = 1;
            if (bVar.mo1858a(windowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1, this) == c) {
                return c;
            }
        } else if (i == 1) {
            C0136l.m422b(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return C0141q.f277a;
    }
}
