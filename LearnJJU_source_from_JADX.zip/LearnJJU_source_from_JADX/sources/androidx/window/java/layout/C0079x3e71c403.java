package androidx.window.java.layout;

import p010e.C0120a;
import p011e0.C0141q;
import p017h0.C0190d;
import p052y0.C0874c;

/* renamed from: androidx.window.java.layout.WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1 */
public final class C0079x3e71c403 implements C0874c<T> {
    final /* synthetic */ C0120a $consumer$inlined;

    public C0079x3e71c403(C0120a aVar) {
        this.$consumer$inlined = aVar;
    }

    public Object emit(T t, C0190d<? super C0141q> dVar) {
        this.$consumer$inlined.accept(t);
        return C0141q.f277a;
    }
}
