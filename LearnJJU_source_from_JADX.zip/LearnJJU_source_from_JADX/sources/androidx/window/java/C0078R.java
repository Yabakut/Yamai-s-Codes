package androidx.window.java;

/* renamed from: androidx.window.java.R */
public final class C0078R {
    private C0078R() {
    }
}
