package androidx.lifecycle;

import androidx.lifecycle.C0051d;

class Lifecycling$1 implements C0055e {

    /* renamed from: a */
    final /* synthetic */ C0055e f154a;

    /* renamed from: g */
    public void mo11g(C0057g gVar, C0051d.C0053b bVar) {
        this.f154a.mo11g(gVar, bVar);
    }
}
