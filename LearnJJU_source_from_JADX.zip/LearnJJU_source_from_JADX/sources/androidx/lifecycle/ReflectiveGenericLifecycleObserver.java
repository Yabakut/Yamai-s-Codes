package androidx.lifecycle;

import androidx.lifecycle.C0046a;
import androidx.lifecycle.C0051d;

class ReflectiveGenericLifecycleObserver implements C0055e {

    /* renamed from: a */
    private final Object f156a;

    /* renamed from: b */
    private final C0046a.C0047a f157b;

    ReflectiveGenericLifecycleObserver(Object obj) {
        this.f156a = obj;
        this.f157b = C0046a.f159c.mo93c(obj.getClass());
    }

    /* renamed from: g */
    public void mo11g(C0057g gVar, C0051d.C0053b bVar) {
        this.f157b.mo95a(gVar, bVar, this.f156a);
    }
}
