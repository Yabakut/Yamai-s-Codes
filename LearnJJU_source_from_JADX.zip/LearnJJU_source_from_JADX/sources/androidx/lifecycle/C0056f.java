package androidx.lifecycle;

/* renamed from: androidx.lifecycle.f */
public interface C0056f {
}
