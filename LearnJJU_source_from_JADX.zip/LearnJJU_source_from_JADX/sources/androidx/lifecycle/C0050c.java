package androidx.lifecycle;

import androidx.lifecycle.C0051d;

/* renamed from: androidx.lifecycle.c */
public interface C0050c {
    /* renamed from: a */
    void mo105a(C0057g gVar, C0051d.C0053b bVar, boolean z, C0062k kVar);
}
