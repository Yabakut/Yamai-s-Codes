package androidx.lifecycle;

/* renamed from: androidx.lifecycle.b */
interface C0049b extends C0056f {
    /* renamed from: a */
    void mo99a(C0057g gVar);

    /* renamed from: b */
    void mo100b(C0057g gVar);

    /* renamed from: c */
    void mo101c(C0057g gVar);

    /* renamed from: d */
    void mo102d(C0057g gVar);

    /* renamed from: e */
    void mo103e(C0057g gVar);

    /* renamed from: f */
    void mo104f(C0057g gVar);
}
