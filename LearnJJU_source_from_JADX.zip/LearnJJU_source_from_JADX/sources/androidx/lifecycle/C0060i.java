package androidx.lifecycle;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: androidx.lifecycle.i */
public class C0060i {

    /* renamed from: a */
    private static Map<Class<?>, Integer> f185a = new HashMap();

    /* renamed from: b */
    private static Map<Class<?>, List<Constructor<? extends C0050c>>> f186b = new HashMap();

    /* renamed from: a */
    private static C0050c m222a(Constructor<? extends C0050c> constructor, Object obj) {
        try {
            return (C0050c) constructor.newInstance(new Object[]{obj});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e2) {
            throw new RuntimeException(e2);
        } catch (InvocationTargetException e3) {
            throw new RuntimeException(e3);
        }
    }

    /* renamed from: b */
    private static Constructor<? extends C0050c> m223b(Class<?> cls) {
        try {
            Package packageR = cls.getPackage();
            String canonicalName = cls.getCanonicalName();
            String name = packageR != null ? packageR.getName() : "";
            if (!name.isEmpty()) {
                canonicalName = canonicalName.substring(name.length() + 1);
            }
            String c = m224c(canonicalName);
            if (!name.isEmpty()) {
                c = name + "." + c;
            }
            Constructor<?> declaredConstructor = Class.forName(c).getDeclaredConstructor(new Class[]{cls});
            if (!declaredConstructor.isAccessible()) {
                declaredConstructor.setAccessible(true);
            }
            return declaredConstructor;
        } catch (ClassNotFoundException unused) {
            return null;
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    /* renamed from: c */
    public static String m224c(String str) {
        return str.replace(".", "_") + "_LifecycleAdapter";
    }

    /* renamed from: d */
    private static int m225d(Class<?> cls) {
        Integer num = f185a.get(cls);
        if (num != null) {
            return num.intValue();
        }
        int g = m228g(cls);
        f185a.put(cls, Integer.valueOf(g));
        return g;
    }

    /* renamed from: e */
    private static boolean m226e(Class<?> cls) {
        return cls != null && C0056f.class.isAssignableFrom(cls);
    }

    /* renamed from: f */
    static C0055e m227f(Object obj) {
        boolean z = obj instanceof C0055e;
        boolean z2 = obj instanceof C0049b;
        if (z && z2) {
            return new FullLifecycleObserverAdapter((C0049b) obj, (C0055e) obj);
        }
        if (z2) {
            return new FullLifecycleObserverAdapter((C0049b) obj, (C0055e) null);
        }
        if (z) {
            return (C0055e) obj;
        }
        Class<?> cls = obj.getClass();
        if (m225d(cls) != 2) {
            return new ReflectiveGenericLifecycleObserver(obj);
        }
        List list = f186b.get(cls);
        if (list.size() == 1) {
            return new SingleGeneratedAdapterObserver(m222a((Constructor) list.get(0), obj));
        }
        C0050c[] cVarArr = new C0050c[list.size()];
        for (int i = 0; i < list.size(); i++) {
            cVarArr[i] = m222a((Constructor) list.get(i), obj);
        }
        return new CompositeGeneratedAdaptersObserver(cVarArr);
    }

    /* renamed from: g */
    private static int m228g(Class<?> cls) {
        if (cls.getCanonicalName() == null) {
            return 1;
        }
        Constructor<? extends C0050c> b = m223b(cls);
        if (b != null) {
            f186b.put(cls, Collections.singletonList(b));
            return 2;
        } else if (C0046a.f159c.mo94d(cls)) {
            return 1;
        } else {
            Class<? super Object> superclass = cls.getSuperclass();
            ArrayList arrayList = null;
            if (m226e(superclass)) {
                if (m225d(superclass) == 1) {
                    return 1;
                }
                arrayList = new ArrayList(f186b.get(superclass));
            }
            for (Class cls2 : cls.getInterfaces()) {
                if (m226e(cls2)) {
                    if (m225d(cls2) == 1) {
                        return 1;
                    }
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.addAll(f186b.get(cls2));
                }
            }
            if (arrayList == null) {
                return 1;
            }
            f186b.put(cls, arrayList);
            return 2;
        }
    }
}
