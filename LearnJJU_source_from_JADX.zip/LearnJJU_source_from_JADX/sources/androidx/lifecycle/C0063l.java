package androidx.lifecycle;

import androidx.lifecycle.C0051d;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
/* renamed from: androidx.lifecycle.l */
public @interface C0063l {
    C0051d.C0053b value();
}
