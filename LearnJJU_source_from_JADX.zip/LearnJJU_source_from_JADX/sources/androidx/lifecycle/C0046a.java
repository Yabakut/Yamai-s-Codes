package androidx.lifecycle;

import androidx.lifecycle.C0051d;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: androidx.lifecycle.a */
final class C0046a {

    /* renamed from: c */
    static C0046a f159c = new C0046a();

    /* renamed from: a */
    private final Map<Class<?>, C0047a> f160a = new HashMap();

    /* renamed from: b */
    private final Map<Class<?>, Boolean> f161b = new HashMap();

    /* renamed from: androidx.lifecycle.a$a */
    static class C0047a {

        /* renamed from: a */
        final Map<C0051d.C0053b, List<C0048b>> f162a = new HashMap();

        /* renamed from: b */
        final Map<C0048b, C0051d.C0053b> f163b;

        C0047a(Map<C0048b, C0051d.C0053b> map) {
            this.f163b = map;
            for (Map.Entry next : map.entrySet()) {
                C0051d.C0053b bVar = (C0051d.C0053b) next.getValue();
                List list = this.f162a.get(bVar);
                if (list == null) {
                    list = new ArrayList();
                    this.f162a.put(bVar, list);
                }
                list.add(next.getKey());
            }
        }

        /* renamed from: b */
        private static void m188b(List<C0048b> list, C0057g gVar, C0051d.C0053b bVar, Object obj) {
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    list.get(size).mo96a(gVar, bVar, obj);
                }
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo95a(C0057g gVar, C0051d.C0053b bVar, Object obj) {
            m188b(this.f162a.get(bVar), gVar, bVar, obj);
            m188b(this.f162a.get(C0051d.C0053b.ON_ANY), gVar, bVar, obj);
        }
    }

    /* renamed from: androidx.lifecycle.a$b */
    static final class C0048b {

        /* renamed from: a */
        final int f164a;

        /* renamed from: b */
        final Method f165b;

        C0048b(int i, Method method) {
            this.f164a = i;
            this.f165b = method;
            method.setAccessible(true);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo96a(C0057g gVar, C0051d.C0053b bVar, Object obj) {
            try {
                int i = this.f164a;
                if (i == 0) {
                    this.f165b.invoke(obj, new Object[0]);
                } else if (i == 1) {
                    this.f165b.invoke(obj, new Object[]{gVar});
                } else if (i == 2) {
                    this.f165b.invoke(obj, new Object[]{gVar, bVar});
                }
            } catch (InvocationTargetException e) {
                throw new RuntimeException("Failed to call observer method", e.getCause());
            } catch (IllegalAccessException e2) {
                throw new RuntimeException(e2);
            }
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof C0048b)) {
                return false;
            }
            C0048b bVar = (C0048b) obj;
            return this.f164a == bVar.f164a && this.f165b.getName().equals(bVar.f165b.getName());
        }

        public int hashCode() {
            return (this.f164a * 31) + this.f165b.getName().hashCode();
        }
    }

    C0046a() {
    }

    /* renamed from: a */
    private C0047a m183a(Class<?> cls, Method[] methodArr) {
        int i;
        C0047a c;
        Class<? super Object> superclass = cls.getSuperclass();
        HashMap hashMap = new HashMap();
        if (!(superclass == null || (c = mo93c(superclass)) == null)) {
            hashMap.putAll(c.f163b);
        }
        for (Class c2 : cls.getInterfaces()) {
            for (Map.Entry next : mo93c(c2).f163b.entrySet()) {
                m185e(hashMap, (C0048b) next.getKey(), (C0051d.C0053b) next.getValue(), cls);
            }
        }
        if (methodArr == null) {
            methodArr = m184b(cls);
        }
        boolean z = false;
        for (Method method : methodArr) {
            C0063l lVar = (C0063l) method.getAnnotation(C0063l.class);
            if (lVar != null) {
                Class[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i = 0;
                } else if (parameterTypes[0].isAssignableFrom(C0057g.class)) {
                    i = 1;
                } else {
                    throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                }
                C0051d.C0053b value = lVar.value();
                if (parameterTypes.length > 1) {
                    if (!parameterTypes[1].isAssignableFrom(C0051d.C0053b.class)) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    } else if (value == C0051d.C0053b.ON_ANY) {
                        i = 2;
                    } else {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                }
                if (parameterTypes.length <= 2) {
                    m185e(hashMap, new C0048b(i, method), value, cls);
                    z = true;
                } else {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
            }
        }
        C0047a aVar = new C0047a(hashMap);
        this.f160a.put(cls, aVar);
        this.f161b.put(cls, Boolean.valueOf(z));
        return aVar;
    }

    /* renamed from: b */
    private Method[] m184b(Class<?> cls) {
        try {
            return cls.getDeclaredMethods();
        } catch (NoClassDefFoundError e) {
            throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e);
        }
    }

    /* renamed from: e */
    private void m185e(Map<C0048b, C0051d.C0053b> map, C0048b bVar, C0051d.C0053b bVar2, Class<?> cls) {
        C0051d.C0053b bVar3 = map.get(bVar);
        if (bVar3 != null && bVar2 != bVar3) {
            Method method = bVar.f165b;
            throw new IllegalArgumentException("Method " + method.getName() + " in " + cls.getName() + " already declared with different @OnLifecycleEvent value: previous value " + bVar3 + ", new value " + bVar2);
        } else if (bVar3 == null) {
            map.put(bVar, bVar2);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public C0047a mo93c(Class<?> cls) {
        C0047a aVar = this.f160a.get(cls);
        return aVar != null ? aVar : m183a(cls, (Method[]) null);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public boolean mo94d(Class<?> cls) {
        Boolean bool = this.f161b.get(cls);
        if (bool != null) {
            return bool.booleanValue();
        }
        Method[] b = m184b(cls);
        for (Method annotation : b) {
            if (((C0063l) annotation.getAnnotation(C0063l.class)) != null) {
                m183a(cls, b);
                return true;
            }
        }
        this.f161b.put(cls, Boolean.FALSE);
        return false;
    }
}
