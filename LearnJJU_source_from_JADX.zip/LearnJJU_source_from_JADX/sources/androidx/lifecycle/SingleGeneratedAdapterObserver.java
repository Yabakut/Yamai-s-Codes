package androidx.lifecycle;

import androidx.lifecycle.C0051d;

class SingleGeneratedAdapterObserver implements C0055e {

    /* renamed from: a */
    private final C0050c f158a;

    SingleGeneratedAdapterObserver(C0050c cVar) {
        this.f158a = cVar;
    }

    /* renamed from: g */
    public void mo11g(C0057g gVar, C0051d.C0053b bVar) {
        this.f158a.mo105a(gVar, bVar, false, (C0062k) null);
        this.f158a.mo105a(gVar, bVar, true, (C0062k) null);
    }
}
