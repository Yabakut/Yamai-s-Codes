package androidx.lifecycle;

import androidx.lifecycle.C0051d;

class LiveData$LifecycleBoundObserver extends C0061j implements C0055e {

    /* renamed from: b */
    final C0057g f155b;

    /* renamed from: g */
    public void mo11g(C0057g gVar, C0051d.C0053b bVar) {
        if (this.f155b.mo111a().mo107b() != C0051d.C0054c.DESTROYED) {
            mo114h(mo92i());
            return;
        }
        throw null;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public boolean mo92i() {
        return this.f155b.mo111a().mo107b().mo110a(C0051d.C0054c.STARTED);
    }
}
