package androidx.lifecycle;

/* renamed from: androidx.lifecycle.j */
abstract class C0061j {

    /* renamed from: a */
    boolean f187a;

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public void mo114h(boolean z) {
        if (z != this.f187a) {
            this.f187a = z;
            throw null;
        }
    }
}
