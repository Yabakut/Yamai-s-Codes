package androidx.lifecycle;

public interface DefaultLifecycleObserver extends C0049b {
}
