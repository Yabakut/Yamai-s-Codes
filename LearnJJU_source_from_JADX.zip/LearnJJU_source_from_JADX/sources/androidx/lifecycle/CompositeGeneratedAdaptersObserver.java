package androidx.lifecycle;

import androidx.lifecycle.C0051d;

class CompositeGeneratedAdaptersObserver implements C0055e {

    /* renamed from: a */
    private final C0050c[] f150a;

    CompositeGeneratedAdaptersObserver(C0050c[] cVarArr) {
        this.f150a = cVarArr;
    }

    /* renamed from: g */
    public void mo11g(C0057g gVar, C0051d.C0053b bVar) {
        C0062k kVar = new C0062k();
        for (C0050c a : this.f150a) {
            a.mo105a(gVar, bVar, false, kVar);
        }
        for (C0050c a2 : this.f150a) {
            a2.mo105a(gVar, bVar, true, kVar);
        }
    }
}
