package androidx.lifecycle;

import androidx.lifecycle.C0051d;

/* renamed from: androidx.lifecycle.e */
public interface C0055e extends C0056f {
    /* renamed from: g */
    void mo11g(C0057g gVar, C0051d.C0053b bVar);
}
