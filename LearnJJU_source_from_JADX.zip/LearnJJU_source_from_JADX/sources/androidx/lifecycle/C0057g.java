package androidx.lifecycle;

/* renamed from: androidx.lifecycle.g */
public interface C0057g {
    /* renamed from: a */
    C0051d mo111a();
}
