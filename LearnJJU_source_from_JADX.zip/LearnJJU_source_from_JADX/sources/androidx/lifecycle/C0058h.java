package androidx.lifecycle;

import android.annotation.SuppressLint;
import androidx.lifecycle.C0051d;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import p000a.C0000a;
import p004b.C0086a;
import p004b.C0087b;

/* renamed from: androidx.lifecycle.h */
public class C0058h extends C0051d {

    /* renamed from: b */
    private C0086a<C0056f, C0059a> f175b;

    /* renamed from: c */
    private C0051d.C0054c f176c;

    /* renamed from: d */
    private final WeakReference<C0057g> f177d;

    /* renamed from: e */
    private int f178e;

    /* renamed from: f */
    private boolean f179f;

    /* renamed from: g */
    private boolean f180g;

    /* renamed from: h */
    private ArrayList<C0051d.C0054c> f181h;

    /* renamed from: i */
    private final boolean f182i;

    /* renamed from: androidx.lifecycle.h$a */
    static class C0059a {

        /* renamed from: a */
        C0051d.C0054c f183a;

        /* renamed from: b */
        C0055e f184b;

        C0059a(C0056f fVar, C0051d.C0054c cVar) {
            this.f184b = C0060i.m227f(fVar);
            this.f183a = cVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo113a(C0057g gVar, C0051d.C0053b bVar) {
            C0051d.C0054c b = bVar.mo109b();
            this.f183a = C0058h.m212j(this.f183a, b);
            this.f184b.mo11g(gVar, bVar);
            this.f183a = b;
        }
    }

    public C0058h(C0057g gVar) {
        this(gVar, true);
    }

    private C0058h(C0057g gVar, boolean z) {
        this.f175b = new C0086a<>();
        this.f178e = 0;
        this.f179f = false;
        this.f180g = false;
        this.f181h = new ArrayList<>();
        this.f177d = new WeakReference<>(gVar);
        this.f176c = C0051d.C0054c.INITIALIZED;
        this.f182i = z;
    }

    /* renamed from: d */
    private void m207d(C0057g gVar) {
        Iterator<Map.Entry<C0056f, C0059a>> a = this.f175b.mo404a();
        while (a.hasNext() && !this.f180g) {
            Map.Entry next = a.next();
            C0059a aVar = (C0059a) next.getValue();
            while (aVar.f183a.compareTo(this.f176c) > 0 && !this.f180g && this.f175b.contains(next.getKey())) {
                C0051d.C0053b a2 = C0051d.C0053b.m201a(aVar.f183a);
                if (a2 != null) {
                    m215m(a2.mo109b());
                    aVar.mo113a(gVar, a2);
                    m214l();
                } else {
                    throw new IllegalStateException("no event down from " + aVar.f183a);
                }
            }
        }
    }

    /* renamed from: e */
    private C0051d.C0054c m208e(C0056f fVar) {
        Map.Entry<C0056f, C0059a> h = this.f175b.mo402h(fVar);
        C0051d.C0054c cVar = null;
        C0051d.C0054c cVar2 = h != null ? h.getValue().f183a : null;
        if (!this.f181h.isEmpty()) {
            ArrayList<C0051d.C0054c> arrayList = this.f181h;
            cVar = arrayList.get(arrayList.size() - 1);
        }
        return m212j(m212j(this.f176c, cVar2), cVar);
    }

    @SuppressLint({"RestrictedApi"})
    /* renamed from: f */
    private void m209f(String str) {
        if (this.f182i && !C0000a.m0d().mo2b()) {
            throw new IllegalStateException("Method " + str + " must be called on the main thread");
        }
    }

    /* renamed from: g */
    private void m210g(C0057g gVar) {
        C0087b<K, V>.d d = this.f175b.mo406d();
        while (d.hasNext() && !this.f180g) {
            Map.Entry entry = (Map.Entry) d.next();
            C0059a aVar = (C0059a) entry.getValue();
            while (aVar.f183a.compareTo(this.f176c) < 0 && !this.f180g && this.f175b.contains(entry.getKey())) {
                m215m(aVar.f183a);
                C0051d.C0053b c = C0051d.C0053b.m202c(aVar.f183a);
                if (c != null) {
                    aVar.mo113a(gVar, c);
                    m214l();
                } else {
                    throw new IllegalStateException("no event up from " + aVar.f183a);
                }
            }
        }
    }

    /* renamed from: i */
    private boolean m211i() {
        if (this.f175b.size() == 0) {
            return true;
        }
        C0051d.C0054c cVar = this.f175b.mo405b().getValue().f183a;
        C0051d.C0054c cVar2 = this.f175b.mo407e().getValue().f183a;
        return cVar == cVar2 && this.f176c == cVar2;
    }

    /* renamed from: j */
    static C0051d.C0054c m212j(C0051d.C0054c cVar, C0051d.C0054c cVar2) {
        return (cVar2 == null || cVar2.compareTo(cVar) >= 0) ? cVar : cVar2;
    }

    /* renamed from: k */
    private void m213k(C0051d.C0054c cVar) {
        if (this.f176c != cVar) {
            this.f176c = cVar;
            if (this.f179f || this.f178e != 0) {
                this.f180g = true;
                return;
            }
            this.f179f = true;
            m216n();
            this.f179f = false;
        }
    }

    /* renamed from: l */
    private void m214l() {
        ArrayList<C0051d.C0054c> arrayList = this.f181h;
        arrayList.remove(arrayList.size() - 1);
    }

    /* renamed from: m */
    private void m215m(C0051d.C0054c cVar) {
        this.f181h.add(cVar);
    }

    /* renamed from: n */
    private void m216n() {
        C0057g gVar = (C0057g) this.f177d.get();
        if (gVar != null) {
            while (true) {
                boolean i = m211i();
                this.f180g = false;
                if (!i) {
                    if (this.f176c.compareTo(this.f175b.mo405b().getValue().f183a) < 0) {
                        m207d(gVar);
                    }
                    Map.Entry<C0056f, C0059a> e = this.f175b.mo407e();
                    if (!this.f180g && e != null && this.f176c.compareTo(e.getValue().f183a) > 0) {
                        m210g(gVar);
                    }
                } else {
                    return;
                }
            }
        } else {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
        }
    }

    /* renamed from: a */
    public void mo106a(C0056f fVar) {
        C0057g gVar;
        m209f("addObserver");
        C0051d.C0054c cVar = this.f176c;
        C0051d.C0054c cVar2 = C0051d.C0054c.DESTROYED;
        if (cVar != cVar2) {
            cVar2 = C0051d.C0054c.INITIALIZED;
        }
        C0059a aVar = new C0059a(fVar, cVar2);
        if (this.f175b.mo403i(fVar, aVar) == null && (gVar = (C0057g) this.f177d.get()) != null) {
            boolean z = this.f178e != 0 || this.f179f;
            C0051d.C0054c e = m208e(fVar);
            this.f178e++;
            while (aVar.f183a.compareTo(e) < 0 && this.f175b.contains(fVar)) {
                m215m(aVar.f183a);
                C0051d.C0053b c = C0051d.C0053b.m202c(aVar.f183a);
                if (c != null) {
                    aVar.mo113a(gVar, c);
                    m214l();
                    e = m208e(fVar);
                } else {
                    throw new IllegalStateException("no event up from " + aVar.f183a);
                }
            }
            if (!z) {
                m216n();
            }
            this.f178e--;
        }
    }

    /* renamed from: b */
    public C0051d.C0054c mo107b() {
        return this.f176c;
    }

    /* renamed from: c */
    public void mo108c(C0056f fVar) {
        m209f("removeObserver");
        this.f175b.mo401g(fVar);
    }

    /* renamed from: h */
    public void mo112h(C0051d.C0053b bVar) {
        m209f("handleLifecycleEvent");
        m213k(bVar.mo109b());
    }
}
