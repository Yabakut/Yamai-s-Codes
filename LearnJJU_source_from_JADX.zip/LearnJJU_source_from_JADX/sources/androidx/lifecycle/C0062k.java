package androidx.lifecycle;

import java.util.HashMap;
import java.util.Map;

/* renamed from: androidx.lifecycle.k */
public class C0062k {

    /* renamed from: a */
    private Map<String, Integer> f188a = new HashMap();
}
