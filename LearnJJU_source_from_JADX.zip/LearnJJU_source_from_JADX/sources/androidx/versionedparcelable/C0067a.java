package androidx.versionedparcelable;

import android.os.Parcelable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import p006c.C0095a;
import p016h.C0185a;

/* renamed from: androidx.versionedparcelable.a */
public abstract class C0067a {

    /* renamed from: a */
    protected final C0095a<String, Method> f191a;

    /* renamed from: b */
    protected final C0095a<String, Method> f192b;

    /* renamed from: c */
    protected final C0095a<String, Class> f193c;

    public C0067a(C0095a<String, Method> aVar, C0095a<String, Method> aVar2, C0095a<String, Class> aVar3) {
        this.f191a = aVar;
        this.f192b = aVar2;
        this.f193c = aVar3;
    }

    /* renamed from: N */
    private void m235N(C0185a aVar) {
        try {
            mo131I(m236c(aVar.getClass()).getName());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(aVar.getClass().getSimpleName() + " does not have a Parcelizer", e);
        }
    }

    /* renamed from: c */
    private Class m236c(Class<? extends C0185a> cls) {
        Class cls2 = this.f193c.get(cls.getName());
        if (cls2 != null) {
            return cls2;
        }
        Class<?> cls3 = Class.forName(String.format("%s.%sParcelizer", new Object[]{cls.getPackage().getName(), cls.getSimpleName()}), false, cls.getClassLoader());
        this.f193c.put(cls.getName(), cls3);
        return cls3;
    }

    /* renamed from: d */
    private Method m237d(String str) {
        Class<C0067a> cls = C0067a.class;
        Method method = this.f191a.get(str);
        if (method != null) {
            return method;
        }
        System.currentTimeMillis();
        Method declaredMethod = Class.forName(str, true, cls.getClassLoader()).getDeclaredMethod("read", new Class[]{cls});
        this.f191a.put(str, declaredMethod);
        return declaredMethod;
    }

    /* renamed from: e */
    private Method m238e(Class cls) {
        Method method = this.f192b.get(cls.getName());
        if (method != null) {
            return method;
        }
        Class c = m236c(cls);
        System.currentTimeMillis();
        Method declaredMethod = c.getDeclaredMethod("write", new Class[]{cls, C0067a.class});
        this.f192b.put(cls.getName(), declaredMethod);
        return declaredMethod;
    }

    /* access modifiers changed from: protected */
    /* renamed from: A */
    public abstract void mo123A(byte[] bArr);

    /* renamed from: B */
    public void mo124B(byte[] bArr, int i) {
        mo155w(i);
        mo123A(bArr);
    }

    /* access modifiers changed from: protected */
    /* renamed from: C */
    public abstract void mo125C(CharSequence charSequence);

    /* renamed from: D */
    public void mo126D(CharSequence charSequence, int i) {
        mo155w(i);
        mo125C(charSequence);
    }

    /* access modifiers changed from: protected */
    /* renamed from: E */
    public abstract void mo127E(int i);

    /* renamed from: F */
    public void mo128F(int i, int i2) {
        mo155w(i2);
        mo127E(i);
    }

    /* access modifiers changed from: protected */
    /* renamed from: G */
    public abstract void mo129G(Parcelable parcelable);

    /* renamed from: H */
    public void mo130H(Parcelable parcelable, int i) {
        mo155w(i);
        mo129G(parcelable);
    }

    /* access modifiers changed from: protected */
    /* renamed from: I */
    public abstract void mo131I(String str);

    /* renamed from: J */
    public void mo132J(String str, int i) {
        mo155w(i);
        mo131I(str);
    }

    /* access modifiers changed from: protected */
    /* renamed from: K */
    public <T extends C0185a> void mo133K(T t, C0067a aVar) {
        try {
            m238e(t.getClass()).invoke((Object) null, new Object[]{t, aVar});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: L */
    public void mo134L(C0185a aVar) {
        if (aVar == null) {
            mo131I((String) null);
            return;
        }
        m235N(aVar);
        C0067a b = mo137b();
        mo133K(aVar, b);
        b.mo136a();
    }

    /* renamed from: M */
    public void mo135M(C0185a aVar, int i) {
        mo155w(i);
        mo134L(aVar);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo136a();

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract C0067a mo137b();

    /* renamed from: f */
    public boolean mo138f() {
        return false;
    }

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public abstract boolean mo139g();

    /* renamed from: h */
    public boolean mo140h(boolean z, int i) {
        return !mo145m(i) ? z : mo139g();
    }

    /* access modifiers changed from: protected */
    /* renamed from: i */
    public abstract byte[] mo141i();

    /* renamed from: j */
    public byte[] mo142j(byte[] bArr, int i) {
        return !mo145m(i) ? bArr : mo141i();
    }

    /* access modifiers changed from: protected */
    /* renamed from: k */
    public abstract CharSequence mo143k();

    /* renamed from: l */
    public CharSequence mo144l(CharSequence charSequence, int i) {
        return !mo145m(i) ? charSequence : mo143k();
    }

    /* access modifiers changed from: protected */
    /* renamed from: m */
    public abstract boolean mo145m(int i);

    /* access modifiers changed from: protected */
    /* renamed from: n */
    public <T extends C0185a> T mo146n(String str, C0067a aVar) {
        try {
            return (C0185a) m237d(str).invoke((Object) null, new Object[]{aVar});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: o */
    public abstract int mo147o();

    /* renamed from: p */
    public int mo148p(int i, int i2) {
        return !mo145m(i2) ? i : mo147o();
    }

    /* access modifiers changed from: protected */
    /* renamed from: q */
    public abstract <T extends Parcelable> T mo149q();

    /* renamed from: r */
    public <T extends Parcelable> T mo150r(T t, int i) {
        return !mo145m(i) ? t : mo149q();
    }

    /* access modifiers changed from: protected */
    /* renamed from: s */
    public abstract String mo151s();

    /* renamed from: t */
    public String mo152t(String str, int i) {
        return !mo145m(i) ? str : mo151s();
    }

    /* access modifiers changed from: protected */
    /* renamed from: u */
    public <T extends C0185a> T mo153u() {
        String s = mo151s();
        if (s == null) {
            return null;
        }
        return mo146n(s, mo137b());
    }

    /* renamed from: v */
    public <T extends C0185a> T mo154v(T t, int i) {
        return !mo145m(i) ? t : mo153u();
    }

    /* access modifiers changed from: protected */
    /* renamed from: w */
    public abstract void mo155w(int i);

    /* renamed from: x */
    public void mo156x(boolean z, boolean z2) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: y */
    public abstract void mo157y(boolean z);

    /* renamed from: z */
    public void mo158z(boolean z, int i) {
        mo155w(i);
        mo157y(z);
    }
}
