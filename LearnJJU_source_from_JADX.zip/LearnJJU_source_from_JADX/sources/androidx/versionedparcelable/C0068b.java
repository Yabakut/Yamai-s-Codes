package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.SparseIntArray;
import java.lang.reflect.Method;
import p006c.C0095a;

/* renamed from: androidx.versionedparcelable.b */
class C0068b extends C0067a {

    /* renamed from: d */
    private final SparseIntArray f194d;

    /* renamed from: e */
    private final Parcel f195e;

    /* renamed from: f */
    private final int f196f;

    /* renamed from: g */
    private final int f197g;

    /* renamed from: h */
    private final String f198h;

    /* renamed from: i */
    private int f199i;

    /* renamed from: j */
    private int f200j;

    /* renamed from: k */
    private int f201k;

    C0068b(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new C0095a(), new C0095a(), new C0095a());
    }

    private C0068b(Parcel parcel, int i, int i2, String str, C0095a<String, Method> aVar, C0095a<String, Method> aVar2, C0095a<String, Class> aVar3) {
        super(aVar, aVar2, aVar3);
        this.f194d = new SparseIntArray();
        this.f199i = -1;
        this.f200j = 0;
        this.f201k = -1;
        this.f195e = parcel;
        this.f196f = i;
        this.f197g = i2;
        this.f200j = i;
        this.f198h = str;
    }

    /* renamed from: A */
    public void mo123A(byte[] bArr) {
        if (bArr != null) {
            this.f195e.writeInt(bArr.length);
            this.f195e.writeByteArray(bArr);
            return;
        }
        this.f195e.writeInt(-1);
    }

    /* access modifiers changed from: protected */
    /* renamed from: C */
    public void mo125C(CharSequence charSequence) {
        TextUtils.writeToParcel(charSequence, this.f195e, 0);
    }

    /* renamed from: E */
    public void mo127E(int i) {
        this.f195e.writeInt(i);
    }

    /* renamed from: G */
    public void mo129G(Parcelable parcelable) {
        this.f195e.writeParcelable(parcelable, 0);
    }

    /* renamed from: I */
    public void mo131I(String str) {
        this.f195e.writeString(str);
    }

    /* renamed from: a */
    public void mo136a() {
        int i = this.f199i;
        if (i >= 0) {
            int i2 = this.f194d.get(i);
            int dataPosition = this.f195e.dataPosition();
            this.f195e.setDataPosition(i2);
            this.f195e.writeInt(dataPosition - i2);
            this.f195e.setDataPosition(dataPosition);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public C0067a mo137b() {
        Parcel parcel = this.f195e;
        int dataPosition = parcel.dataPosition();
        int i = this.f200j;
        if (i == this.f196f) {
            i = this.f197g;
        }
        int i2 = i;
        return new C0068b(parcel, dataPosition, i2, this.f198h + "  ", this.f191a, this.f192b, this.f193c);
    }

    /* renamed from: g */
    public boolean mo139g() {
        return this.f195e.readInt() != 0;
    }

    /* renamed from: i */
    public byte[] mo141i() {
        int readInt = this.f195e.readInt();
        if (readInt < 0) {
            return null;
        }
        byte[] bArr = new byte[readInt];
        this.f195e.readByteArray(bArr);
        return bArr;
    }

    /* access modifiers changed from: protected */
    /* renamed from: k */
    public CharSequence mo143k() {
        return (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(this.f195e);
    }

    /* renamed from: m */
    public boolean mo145m(int i) {
        while (this.f200j < this.f197g) {
            int i2 = this.f201k;
            if (i2 == i) {
                return true;
            }
            if (String.valueOf(i2).compareTo(String.valueOf(i)) > 0) {
                return false;
            }
            this.f195e.setDataPosition(this.f200j);
            int readInt = this.f195e.readInt();
            this.f201k = this.f195e.readInt();
            this.f200j += readInt;
        }
        return this.f201k == i;
    }

    /* renamed from: o */
    public int mo147o() {
        return this.f195e.readInt();
    }

    /* renamed from: q */
    public <T extends Parcelable> T mo149q() {
        return this.f195e.readParcelable(getClass().getClassLoader());
    }

    /* renamed from: s */
    public String mo151s() {
        return this.f195e.readString();
    }

    /* renamed from: w */
    public void mo155w(int i) {
        mo136a();
        this.f199i = i;
        this.f194d.put(i, this.f195e.dataPosition());
        mo127E(0);
        mo127E(i);
    }

    /* renamed from: y */
    public void mo157y(boolean z) {
        this.f195e.writeInt(z ? 1 : 0);
    }
}
