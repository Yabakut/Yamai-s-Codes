package androidx.versionedparcelable;

import p016h.C0185a;

public abstract class CustomVersionedParcelable implements C0185a {
}
