package androidx.versionedparcelable;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import p016h.C0185a;

@SuppressLint({"BanParcelableUsage"})
public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new C0066a();

    /* renamed from: d */
    private final C0185a f190d;

    /* renamed from: androidx.versionedparcelable.ParcelImpl$a */
    static class C0066a implements Parcelable.Creator<ParcelImpl> {
        C0066a() {
        }

        /* renamed from: a */
        public ParcelImpl createFromParcel(Parcel parcel) {
            return new ParcelImpl(parcel);
        }

        /* renamed from: b */
        public ParcelImpl[] newArray(int i) {
            return new ParcelImpl[i];
        }
    }

    protected ParcelImpl(Parcel parcel) {
        this.f190d = new C0068b(parcel).mo153u();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        new C0068b(parcel).mo134L(this.f190d);
    }
}
