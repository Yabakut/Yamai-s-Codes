package androidx.exifinterface.media;

import android.content.res.AssetManager;
import android.media.MediaDataSource;
import android.os.Build;
import android.system.OsConstants;
import android.util.Log;
import androidx.exifinterface.media.C0042b;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

/* renamed from: androidx.exifinterface.media.a */
public class C0034a {

    /* renamed from: A */
    public static final int[] f55A = {8};

    /* renamed from: B */
    static final byte[] f56B = {-1, -40, -1};

    /* renamed from: C */
    private static final byte[] f57C = {102, 116, 121, 112};

    /* renamed from: D */
    private static final byte[] f58D = {109, 105, 102, 49};

    /* renamed from: E */
    private static final byte[] f59E = {104, 101, 105, 99};

    /* renamed from: F */
    private static final byte[] f60F = {79, 76, 89, 77, 80, 0};

    /* renamed from: G */
    private static final byte[] f61G = {79, 76, 89, 77, 80, 85, 83, 0, 73, 73};

    /* renamed from: H */
    private static final byte[] f62H = {-119, 80, 78, 71, 13, 10, 26, 10};

    /* renamed from: I */
    private static final byte[] f63I = {101, 88, 73, 102};

    /* renamed from: J */
    private static final byte[] f64J = {73, 72, 68, 82};

    /* renamed from: K */
    private static final byte[] f65K = {73, 69, 78, 68};

    /* renamed from: L */
    private static final byte[] f66L = {82, 73, 70, 70};

    /* renamed from: M */
    private static final byte[] f67M = {87, 69, 66, 80};

    /* renamed from: N */
    private static final byte[] f68N = {69, 88, 73, 70};

    /* renamed from: O */
    private static final byte[] f69O = {-99, 1, 42};

    /* renamed from: P */
    private static final byte[] f70P = "VP8X".getBytes(Charset.defaultCharset());

    /* renamed from: Q */
    private static final byte[] f71Q = "VP8L".getBytes(Charset.defaultCharset());

    /* renamed from: R */
    private static final byte[] f72R = "VP8 ".getBytes(Charset.defaultCharset());

    /* renamed from: S */
    private static final byte[] f73S = "ANIM".getBytes(Charset.defaultCharset());

    /* renamed from: T */
    private static final byte[] f74T = "ANMF".getBytes(Charset.defaultCharset());

    /* renamed from: U */
    private static SimpleDateFormat f75U;

    /* renamed from: V */
    private static SimpleDateFormat f76V;

    /* renamed from: W */
    static final String[] f77W = {"", "BYTE", "STRING", "USHORT", "ULONG", "URATIONAL", "SBYTE", "UNDEFINED", "SSHORT", "SLONG", "SRATIONAL", "SINGLE", "DOUBLE", "IFD"};

    /* renamed from: X */
    static final int[] f78X = {0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8, 1};

    /* renamed from: Y */
    static final byte[] f79Y = {65, 83, 67, 73, 73, 0, 0, 0};

    /* renamed from: Z */
    private static final C0039e[] f80Z;

    /* renamed from: a0 */
    private static final C0039e[] f81a0;

    /* renamed from: b0 */
    private static final C0039e[] f82b0;

    /* renamed from: c0 */
    private static final C0039e[] f83c0;

    /* renamed from: d0 */
    private static final C0039e[] f84d0;

    /* renamed from: e0 */
    private static final C0039e f85e0 = new C0039e("StripOffsets", 273, 3);

    /* renamed from: f0 */
    private static final C0039e[] f86f0;

    /* renamed from: g0 */
    private static final C0039e[] f87g0;

    /* renamed from: h0 */
    private static final C0039e[] f88h0;

    /* renamed from: i0 */
    private static final C0039e[] f89i0;

    /* renamed from: j0 */
    static final C0039e[][] f90j0;

    /* renamed from: k0 */
    private static final C0039e[] f91k0 = {new C0039e("SubIFDPointer", 330, 4), new C0039e("ExifIFDPointer", 34665, 4), new C0039e("GPSInfoIFDPointer", 34853, 4), new C0039e("InteroperabilityIFDPointer", 40965, 4), new C0039e("CameraSettingsIFDPointer", 8224, 1), new C0039e("ImageProcessingIFDPointer", 8256, 1)};

    /* renamed from: l0 */
    private static final HashMap<Integer, C0039e>[] f92l0;

    /* renamed from: m0 */
    private static final HashMap<String, C0039e>[] f93m0;

    /* renamed from: n0 */
    private static final HashSet<String> f94n0 = new HashSet<>(Arrays.asList(new String[]{"FNumber", "DigitalZoomRatio", "ExposureTime", "SubjectDistance", "GPSTimeStamp"}));

    /* renamed from: o0 */
    private static final HashMap<Integer, Integer> f95o0 = new HashMap<>();

    /* renamed from: p0 */
    static final Charset f96p0;

    /* renamed from: q0 */
    static final byte[] f97q0;

    /* renamed from: r0 */
    private static final byte[] f98r0;

    /* renamed from: s0 */
    private static final Pattern f99s0 = Pattern.compile(".*[1-9].*");

    /* renamed from: t0 */
    private static final Pattern f100t0 = Pattern.compile("^(\\d{2}):(\\d{2}):(\\d{2})$");

    /* renamed from: u0 */
    private static final Pattern f101u0 = Pattern.compile("^(\\d{4}):(\\d{2}):(\\d{2})\\s(\\d{2}):(\\d{2}):(\\d{2})$");

    /* renamed from: v */
    private static final boolean f102v = Log.isLoggable("ExifInterface", 3);

    /* renamed from: v0 */
    private static final Pattern f103v0 = Pattern.compile("^(\\d{4})-(\\d{2})-(\\d{2})\\s(\\d{2}):(\\d{2}):(\\d{2})$");

    /* renamed from: w */
    private static final List<Integer> f104w = Arrays.asList(new Integer[]{1, 6, 3, 8});

    /* renamed from: x */
    private static final List<Integer> f105x = Arrays.asList(new Integer[]{2, 7, 4, 5});

    /* renamed from: y */
    public static final int[] f106y = {8, 8, 8};

    /* renamed from: z */
    public static final int[] f107z = {4};

    /* renamed from: a */
    private String f108a;

    /* renamed from: b */
    private FileDescriptor f109b;

    /* renamed from: c */
    private AssetManager.AssetInputStream f110c;

    /* renamed from: d */
    private int f111d;

    /* renamed from: e */
    private boolean f112e;

    /* renamed from: f */
    private final HashMap<String, C0038d>[] f113f;

    /* renamed from: g */
    private Set<Integer> f114g;

    /* renamed from: h */
    private ByteOrder f115h = ByteOrder.BIG_ENDIAN;

    /* renamed from: i */
    private boolean f116i;

    /* renamed from: j */
    private boolean f117j;

    /* renamed from: k */
    private boolean f118k;

    /* renamed from: l */
    private int f119l;

    /* renamed from: m */
    private int f120m;

    /* renamed from: n */
    private byte[] f121n;

    /* renamed from: o */
    private int f122o;

    /* renamed from: p */
    private int f123p;

    /* renamed from: q */
    private int f124q;

    /* renamed from: r */
    private int f125r;

    /* renamed from: s */
    private int f126s;

    /* renamed from: t */
    private boolean f127t;

    /* renamed from: u */
    private boolean f128u;

    /* renamed from: androidx.exifinterface.media.a$a */
    class C0035a extends MediaDataSource {

        /* renamed from: d */
        long f129d;

        /* renamed from: e */
        final /* synthetic */ C0041g f130e;

        C0035a(C0041g gVar) {
            this.f130e = gVar;
        }

        public void close() {
        }

        public long getSize() {
            return -1;
        }

        public int readAt(long j, byte[] bArr, int i, int i2) {
            if (i2 == 0) {
                return 0;
            }
            if (j < 0) {
                return -1;
            }
            try {
                long j2 = this.f129d;
                if (j2 != j) {
                    if (j2 >= 0 && j >= j2 + ((long) this.f130e.available())) {
                        return -1;
                    }
                    this.f130e.mo91e(j);
                    this.f129d = j;
                }
                if (i2 > this.f130e.available()) {
                    i2 = this.f130e.available();
                }
                int read = this.f130e.read(bArr, i, i2);
                if (read >= 0) {
                    this.f129d += (long) read;
                    return read;
                }
            } catch (IOException unused) {
            }
            this.f129d = -1;
            return -1;
        }
    }

    /* renamed from: androidx.exifinterface.media.a$b */
    private static class C0036b extends InputStream implements DataInput {

        /* renamed from: h */
        private static final ByteOrder f132h = ByteOrder.LITTLE_ENDIAN;

        /* renamed from: i */
        private static final ByteOrder f133i = ByteOrder.BIG_ENDIAN;

        /* renamed from: d */
        final DataInputStream f134d;

        /* renamed from: e */
        private ByteOrder f135e;

        /* renamed from: f */
        int f136f;

        /* renamed from: g */
        private byte[] f137g;

        C0036b(InputStream inputStream) {
            this(inputStream, ByteOrder.BIG_ENDIAN);
        }

        C0036b(InputStream inputStream, ByteOrder byteOrder) {
            this.f135e = ByteOrder.BIG_ENDIAN;
            DataInputStream dataInputStream = new DataInputStream(inputStream);
            this.f134d = dataInputStream;
            dataInputStream.mark(0);
            this.f136f = 0;
            this.f135e = byteOrder;
        }

        C0036b(byte[] bArr) {
            this(new ByteArrayInputStream(bArr), ByteOrder.BIG_ENDIAN);
        }

        /* renamed from: a */
        public int mo50a() {
            return this.f136f;
        }

        public int available() {
            return this.f134d.available();
        }

        /* renamed from: b */
        public long mo52b() {
            return ((long) readInt()) & 4294967295L;
        }

        /* renamed from: c */
        public void mo53c(ByteOrder byteOrder) {
            this.f135e = byteOrder;
        }

        /* renamed from: d */
        public void mo54d(int i) {
            int i2 = 0;
            while (i2 < i) {
                int i3 = i - i2;
                int skip = (int) this.f134d.skip((long) i3);
                if (skip <= 0) {
                    if (this.f137g == null) {
                        this.f137g = new byte[8192];
                    }
                    skip = this.f134d.read(this.f137g, 0, Math.min(8192, i3));
                    if (skip == -1) {
                        throw new EOFException("Reached EOF while skipping " + i + " bytes.");
                    }
                }
                i2 += skip;
            }
            this.f136f += i2;
        }

        public void mark(int i) {
            throw new UnsupportedOperationException("Mark is currently unsupported");
        }

        public int read() {
            this.f136f++;
            return this.f134d.read();
        }

        public int read(byte[] bArr, int i, int i2) {
            int read = this.f134d.read(bArr, i, i2);
            this.f136f += read;
            return read;
        }

        public boolean readBoolean() {
            this.f136f++;
            return this.f134d.readBoolean();
        }

        public byte readByte() {
            this.f136f++;
            int read = this.f134d.read();
            if (read >= 0) {
                return (byte) read;
            }
            throw new EOFException();
        }

        public char readChar() {
            this.f136f += 2;
            return this.f134d.readChar();
        }

        public double readDouble() {
            return Double.longBitsToDouble(readLong());
        }

        public float readFloat() {
            return Float.intBitsToFloat(readInt());
        }

        public void readFully(byte[] bArr) {
            this.f136f += bArr.length;
            this.f134d.readFully(bArr);
        }

        public void readFully(byte[] bArr, int i, int i2) {
            this.f136f += i2;
            this.f134d.readFully(bArr, i, i2);
        }

        public int readInt() {
            this.f136f += 4;
            int read = this.f134d.read();
            int read2 = this.f134d.read();
            int read3 = this.f134d.read();
            int read4 = this.f134d.read();
            if ((read | read2 | read3 | read4) >= 0) {
                ByteOrder byteOrder = this.f135e;
                if (byteOrder == f132h) {
                    return (read4 << 24) + (read3 << 16) + (read2 << 8) + read;
                }
                if (byteOrder == f133i) {
                    return (read << 24) + (read2 << 16) + (read3 << 8) + read4;
                }
                throw new IOException("Invalid byte order: " + this.f135e);
            }
            throw new EOFException();
        }

        public String readLine() {
            Log.d("ExifInterface", "Currently unsupported");
            return null;
        }

        public long readLong() {
            this.f136f += 8;
            int read = this.f134d.read();
            int read2 = this.f134d.read();
            int read3 = this.f134d.read();
            int read4 = this.f134d.read();
            int read5 = this.f134d.read();
            int read6 = this.f134d.read();
            int read7 = this.f134d.read();
            int read8 = this.f134d.read();
            if ((read | read2 | read3 | read4 | read5 | read6 | read7 | read8) >= 0) {
                ByteOrder byteOrder = this.f135e;
                if (byteOrder == f132h) {
                    return (((long) read8) << 56) + (((long) read7) << 48) + (((long) read6) << 40) + (((long) read5) << 32) + (((long) read4) << 24) + (((long) read3) << 16) + (((long) read2) << 8) + ((long) read);
                }
                int i = read2;
                if (byteOrder == f133i) {
                    return (((long) read) << 56) + (((long) i) << 48) + (((long) read3) << 40) + (((long) read4) << 32) + (((long) read5) << 24) + (((long) read6) << 16) + (((long) read7) << 8) + ((long) read8);
                }
                throw new IOException("Invalid byte order: " + this.f135e);
            }
            throw new EOFException();
        }

        public short readShort() {
            this.f136f += 2;
            int read = this.f134d.read();
            int read2 = this.f134d.read();
            if ((read | read2) >= 0) {
                ByteOrder byteOrder = this.f135e;
                if (byteOrder == f132h) {
                    return (short) ((read2 << 8) + read);
                }
                if (byteOrder == f133i) {
                    return (short) ((read << 8) + read2);
                }
                throw new IOException("Invalid byte order: " + this.f135e);
            }
            throw new EOFException();
        }

        public String readUTF() {
            this.f136f += 2;
            return this.f134d.readUTF();
        }

        public int readUnsignedByte() {
            this.f136f++;
            return this.f134d.readUnsignedByte();
        }

        public int readUnsignedShort() {
            this.f136f += 2;
            int read = this.f134d.read();
            int read2 = this.f134d.read();
            if ((read | read2) >= 0) {
                ByteOrder byteOrder = this.f135e;
                if (byteOrder == f132h) {
                    return (read2 << 8) + read;
                }
                if (byteOrder == f133i) {
                    return (read << 8) + read2;
                }
                throw new IOException("Invalid byte order: " + this.f135e);
            }
            throw new EOFException();
        }

        public void reset() {
            throw new UnsupportedOperationException("Reset is currently unsupported");
        }

        public int skipBytes(int i) {
            throw new UnsupportedOperationException("skipBytes is currently unsupported");
        }
    }

    /* renamed from: androidx.exifinterface.media.a$c */
    private static class C0037c extends FilterOutputStream {

        /* renamed from: d */
        final OutputStream f138d;

        /* renamed from: e */
        private ByteOrder f139e;

        public C0037c(OutputStream outputStream, ByteOrder byteOrder) {
            super(outputStream);
            this.f138d = outputStream;
            this.f139e = byteOrder;
        }

        /* renamed from: a */
        public void mo74a(ByteOrder byteOrder) {
            this.f139e = byteOrder;
        }

        /* renamed from: b */
        public void mo75b(int i) {
            this.f138d.write(i);
        }

        /* renamed from: c */
        public void mo76c(int i) {
            OutputStream outputStream;
            int i2;
            ByteOrder byteOrder = this.f139e;
            if (byteOrder == ByteOrder.LITTLE_ENDIAN) {
                this.f138d.write((i >>> 0) & 255);
                this.f138d.write((i >>> 8) & 255);
                this.f138d.write((i >>> 16) & 255);
                outputStream = this.f138d;
                i2 = i >>> 24;
            } else if (byteOrder == ByteOrder.BIG_ENDIAN) {
                this.f138d.write((i >>> 24) & 255);
                this.f138d.write((i >>> 16) & 255);
                this.f138d.write((i >>> 8) & 255);
                outputStream = this.f138d;
                i2 = i >>> 0;
            } else {
                return;
            }
            outputStream.write(i2 & 255);
        }

        /* renamed from: d */
        public void mo77d(short s) {
            OutputStream outputStream;
            int i;
            ByteOrder byteOrder = this.f139e;
            if (byteOrder == ByteOrder.LITTLE_ENDIAN) {
                this.f138d.write((s >>> 0) & 255);
                outputStream = this.f138d;
                i = s >>> 8;
            } else if (byteOrder == ByteOrder.BIG_ENDIAN) {
                this.f138d.write((s >>> 8) & 255);
                outputStream = this.f138d;
                i = s >>> 0;
            } else {
                return;
            }
            outputStream.write(i & 255);
        }

        /* renamed from: e */
        public void mo78e(long j) {
            mo76c((int) j);
        }

        /* renamed from: f */
        public void mo79f(int i) {
            mo77d((short) i);
        }

        public void write(byte[] bArr) {
            this.f138d.write(bArr);
        }

        public void write(byte[] bArr, int i, int i2) {
            this.f138d.write(bArr, i, i2);
        }
    }

    /* renamed from: androidx.exifinterface.media.a$d */
    private static class C0038d {

        /* renamed from: a */
        public final int f140a;

        /* renamed from: b */
        public final int f141b;

        /* renamed from: c */
        public final long f142c;

        /* renamed from: d */
        public final byte[] f143d;

        C0038d(int i, int i2, long j, byte[] bArr) {
            this.f140a = i;
            this.f141b = i2;
            this.f142c = j;
            this.f143d = bArr;
        }

        C0038d(int i, int i2, byte[] bArr) {
            this(i, i2, -1, bArr);
        }

        /* renamed from: a */
        public static C0038d m145a(String str) {
            if (str.length() != 1 || str.charAt(0) < '0' || str.charAt(0) > '1') {
                byte[] bytes = str.getBytes(C0034a.f96p0);
                return new C0038d(1, bytes.length, bytes);
            }
            return new C0038d(1, 1, new byte[]{(byte) (str.charAt(0) - '0')});
        }

        /* renamed from: b */
        public static C0038d m146b(double[] dArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[(C0034a.f78X[12] * dArr.length)]);
            wrap.order(byteOrder);
            for (double putDouble : dArr) {
                wrap.putDouble(putDouble);
            }
            return new C0038d(12, dArr.length, wrap.array());
        }

        /* renamed from: c */
        public static C0038d m147c(int[] iArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[(C0034a.f78X[9] * iArr.length)]);
            wrap.order(byteOrder);
            for (int putInt : iArr) {
                wrap.putInt(putInt);
            }
            return new C0038d(9, iArr.length, wrap.array());
        }

        /* renamed from: d */
        public static C0038d m148d(C0040f[] fVarArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[(C0034a.f78X[10] * fVarArr.length)]);
            wrap.order(byteOrder);
            for (C0040f fVar : fVarArr) {
                wrap.putInt((int) fVar.f148a);
                wrap.putInt((int) fVar.f149b);
            }
            return new C0038d(10, fVarArr.length, wrap.array());
        }

        /* renamed from: e */
        public static C0038d m149e(String str) {
            byte[] bytes = (str + 0).getBytes(C0034a.f96p0);
            return new C0038d(2, bytes.length, bytes);
        }

        /* renamed from: f */
        public static C0038d m150f(long j, ByteOrder byteOrder) {
            return m151g(new long[]{j}, byteOrder);
        }

        /* renamed from: g */
        public static C0038d m151g(long[] jArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[(C0034a.f78X[4] * jArr.length)]);
            wrap.order(byteOrder);
            for (long j : jArr) {
                wrap.putInt((int) j);
            }
            return new C0038d(4, jArr.length, wrap.array());
        }

        /* renamed from: h */
        public static C0038d m152h(C0040f fVar, ByteOrder byteOrder) {
            return m153i(new C0040f[]{fVar}, byteOrder);
        }

        /* renamed from: i */
        public static C0038d m153i(C0040f[] fVarArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[(C0034a.f78X[5] * fVarArr.length)]);
            wrap.order(byteOrder);
            for (C0040f fVar : fVarArr) {
                wrap.putInt((int) fVar.f148a);
                wrap.putInt((int) fVar.f149b);
            }
            return new C0038d(5, fVarArr.length, wrap.array());
        }

        /* renamed from: j */
        public static C0038d m154j(int i, ByteOrder byteOrder) {
            return m155k(new int[]{i}, byteOrder);
        }

        /* renamed from: k */
        public static C0038d m155k(int[] iArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[(C0034a.f78X[3] * iArr.length)]);
            wrap.order(byteOrder);
            for (int i : iArr) {
                wrap.putShort((short) i);
            }
            return new C0038d(3, iArr.length, wrap.array());
        }

        /* renamed from: l */
        public double mo82l(ByteOrder byteOrder) {
            Object o = mo85o(byteOrder);
            if (o == null) {
                throw new NumberFormatException("NULL can't be converted to a double value");
            } else if (o instanceof String) {
                return Double.parseDouble((String) o);
            } else {
                if (o instanceof long[]) {
                    long[] jArr = (long[]) o;
                    if (jArr.length == 1) {
                        return (double) jArr[0];
                    }
                    throw new NumberFormatException("There are more than one component");
                } else if (o instanceof int[]) {
                    int[] iArr = (int[]) o;
                    if (iArr.length == 1) {
                        return (double) iArr[0];
                    }
                    throw new NumberFormatException("There are more than one component");
                } else if (o instanceof double[]) {
                    double[] dArr = (double[]) o;
                    if (dArr.length == 1) {
                        return dArr[0];
                    }
                    throw new NumberFormatException("There are more than one component");
                } else if (o instanceof C0040f[]) {
                    C0040f[] fVarArr = (C0040f[]) o;
                    if (fVarArr.length == 1) {
                        return fVarArr[0].mo89a();
                    }
                    throw new NumberFormatException("There are more than one component");
                } else {
                    throw new NumberFormatException("Couldn't find a double value");
                }
            }
        }

        /* renamed from: m */
        public int mo83m(ByteOrder byteOrder) {
            Object o = mo85o(byteOrder);
            if (o == null) {
                throw new NumberFormatException("NULL can't be converted to a integer value");
            } else if (o instanceof String) {
                return Integer.parseInt((String) o);
            } else {
                if (o instanceof long[]) {
                    long[] jArr = (long[]) o;
                    if (jArr.length == 1) {
                        return (int) jArr[0];
                    }
                    throw new NumberFormatException("There are more than one component");
                } else if (o instanceof int[]) {
                    int[] iArr = (int[]) o;
                    if (iArr.length == 1) {
                        return iArr[0];
                    }
                    throw new NumberFormatException("There are more than one component");
                } else {
                    throw new NumberFormatException("Couldn't find a integer value");
                }
            }
        }

        /* renamed from: n */
        public String mo84n(ByteOrder byteOrder) {
            Object o = mo85o(byteOrder);
            if (o == null) {
                return null;
            }
            if (o instanceof String) {
                return (String) o;
            }
            StringBuilder sb = new StringBuilder();
            int i = 0;
            if (o instanceof long[]) {
                long[] jArr = (long[]) o;
                while (i < jArr.length) {
                    sb.append(jArr[i]);
                    i++;
                    if (i != jArr.length) {
                        sb.append(",");
                    }
                }
                return sb.toString();
            } else if (o instanceof int[]) {
                int[] iArr = (int[]) o;
                while (i < iArr.length) {
                    sb.append(iArr[i]);
                    i++;
                    if (i != iArr.length) {
                        sb.append(",");
                    }
                }
                return sb.toString();
            } else if (o instanceof double[]) {
                double[] dArr = (double[]) o;
                while (i < dArr.length) {
                    sb.append(dArr[i]);
                    i++;
                    if (i != dArr.length) {
                        sb.append(",");
                    }
                }
                return sb.toString();
            } else if (!(o instanceof C0040f[])) {
                return null;
            } else {
                C0040f[] fVarArr = (C0040f[]) o;
                while (i < fVarArr.length) {
                    sb.append(fVarArr[i].f148a);
                    sb.append('/');
                    sb.append(fVarArr[i].f149b);
                    i++;
                    if (i != fVarArr.length) {
                        sb.append(",");
                    }
                }
                return sb.toString();
            }
        }

        /* access modifiers changed from: package-private */
        /* JADX WARNING: Removed duplicated region for block: B:164:0x019f A[SYNTHETIC, Splitter:B:164:0x019f] */
        /* renamed from: o */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public java.lang.Object mo85o(java.nio.ByteOrder r11) {
            /*
                r10 = this;
                java.lang.String r0 = "IOException occurred while closing InputStream"
                java.lang.String r1 = "ExifInterface"
                r2 = 0
                androidx.exifinterface.media.a$b r3 = new androidx.exifinterface.media.a$b     // Catch:{ IOException -> 0x0189, all -> 0x0187 }
                byte[] r4 = r10.f143d     // Catch:{ IOException -> 0x0189, all -> 0x0187 }
                r3.<init>((byte[]) r4)     // Catch:{ IOException -> 0x0189, all -> 0x0187 }
                r3.mo53c(r11)     // Catch:{ IOException -> 0x0185 }
                int r11 = r10.f140a     // Catch:{ IOException -> 0x0185 }
                r4 = 1
                r5 = 0
                switch(r11) {
                    case 1: goto L_0x0148;
                    case 2: goto L_0x00fd;
                    case 3: goto L_0x00e3;
                    case 4: goto L_0x00c9;
                    case 5: goto L_0x00a6;
                    case 6: goto L_0x0148;
                    case 7: goto L_0x00fd;
                    case 8: goto L_0x008c;
                    case 9: goto L_0x0072;
                    case 10: goto L_0x004d;
                    case 11: goto L_0x0032;
                    case 12: goto L_0x0018;
                    default: goto L_0x0016;
                }     // Catch:{ IOException -> 0x0185 }
            L_0x0016:
                goto L_0x017c
            L_0x0018:
                int r11 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                double[] r11 = new double[r11]     // Catch:{ IOException -> 0x0185 }
            L_0x001c:
                int r4 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                if (r5 >= r4) goto L_0x0029
                double r6 = r3.readDouble()     // Catch:{ IOException -> 0x0185 }
                r11[r5] = r6     // Catch:{ IOException -> 0x0185 }
                int r5 = r5 + 1
                goto L_0x001c
            L_0x0029:
                r3.close()     // Catch:{ IOException -> 0x002d }
                goto L_0x0031
            L_0x002d:
                r2 = move-exception
                android.util.Log.e(r1, r0, r2)
            L_0x0031:
                return r11
            L_0x0032:
                int r11 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                double[] r11 = new double[r11]     // Catch:{ IOException -> 0x0185 }
            L_0x0036:
                int r4 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                if (r5 >= r4) goto L_0x0044
                float r4 = r3.readFloat()     // Catch:{ IOException -> 0x0185 }
                double r6 = (double) r4     // Catch:{ IOException -> 0x0185 }
                r11[r5] = r6     // Catch:{ IOException -> 0x0185 }
                int r5 = r5 + 1
                goto L_0x0036
            L_0x0044:
                r3.close()     // Catch:{ IOException -> 0x0048 }
                goto L_0x004c
            L_0x0048:
                r2 = move-exception
                android.util.Log.e(r1, r0, r2)
            L_0x004c:
                return r11
            L_0x004d:
                int r11 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                androidx.exifinterface.media.a$f[] r11 = new androidx.exifinterface.media.C0034a.C0040f[r11]     // Catch:{ IOException -> 0x0185 }
            L_0x0051:
                int r4 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                if (r5 >= r4) goto L_0x0069
                int r4 = r3.readInt()     // Catch:{ IOException -> 0x0185 }
                long r6 = (long) r4     // Catch:{ IOException -> 0x0185 }
                int r4 = r3.readInt()     // Catch:{ IOException -> 0x0185 }
                long r8 = (long) r4     // Catch:{ IOException -> 0x0185 }
                androidx.exifinterface.media.a$f r4 = new androidx.exifinterface.media.a$f     // Catch:{ IOException -> 0x0185 }
                r4.<init>(r6, r8)     // Catch:{ IOException -> 0x0185 }
                r11[r5] = r4     // Catch:{ IOException -> 0x0185 }
                int r5 = r5 + 1
                goto L_0x0051
            L_0x0069:
                r3.close()     // Catch:{ IOException -> 0x006d }
                goto L_0x0071
            L_0x006d:
                r2 = move-exception
                android.util.Log.e(r1, r0, r2)
            L_0x0071:
                return r11
            L_0x0072:
                int r11 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                int[] r11 = new int[r11]     // Catch:{ IOException -> 0x0185 }
            L_0x0076:
                int r4 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                if (r5 >= r4) goto L_0x0083
                int r4 = r3.readInt()     // Catch:{ IOException -> 0x0185 }
                r11[r5] = r4     // Catch:{ IOException -> 0x0185 }
                int r5 = r5 + 1
                goto L_0x0076
            L_0x0083:
                r3.close()     // Catch:{ IOException -> 0x0087 }
                goto L_0x008b
            L_0x0087:
                r2 = move-exception
                android.util.Log.e(r1, r0, r2)
            L_0x008b:
                return r11
            L_0x008c:
                int r11 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                int[] r11 = new int[r11]     // Catch:{ IOException -> 0x0185 }
            L_0x0090:
                int r4 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                if (r5 >= r4) goto L_0x009d
                short r4 = r3.readShort()     // Catch:{ IOException -> 0x0185 }
                r11[r5] = r4     // Catch:{ IOException -> 0x0185 }
                int r5 = r5 + 1
                goto L_0x0090
            L_0x009d:
                r3.close()     // Catch:{ IOException -> 0x00a1 }
                goto L_0x00a5
            L_0x00a1:
                r2 = move-exception
                android.util.Log.e(r1, r0, r2)
            L_0x00a5:
                return r11
            L_0x00a6:
                int r11 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                androidx.exifinterface.media.a$f[] r11 = new androidx.exifinterface.media.C0034a.C0040f[r11]     // Catch:{ IOException -> 0x0185 }
            L_0x00aa:
                int r4 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                if (r5 >= r4) goto L_0x00c0
                long r6 = r3.mo52b()     // Catch:{ IOException -> 0x0185 }
                long r8 = r3.mo52b()     // Catch:{ IOException -> 0x0185 }
                androidx.exifinterface.media.a$f r4 = new androidx.exifinterface.media.a$f     // Catch:{ IOException -> 0x0185 }
                r4.<init>(r6, r8)     // Catch:{ IOException -> 0x0185 }
                r11[r5] = r4     // Catch:{ IOException -> 0x0185 }
                int r5 = r5 + 1
                goto L_0x00aa
            L_0x00c0:
                r3.close()     // Catch:{ IOException -> 0x00c4 }
                goto L_0x00c8
            L_0x00c4:
                r2 = move-exception
                android.util.Log.e(r1, r0, r2)
            L_0x00c8:
                return r11
            L_0x00c9:
                int r11 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                long[] r11 = new long[r11]     // Catch:{ IOException -> 0x0185 }
            L_0x00cd:
                int r4 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                if (r5 >= r4) goto L_0x00da
                long r6 = r3.mo52b()     // Catch:{ IOException -> 0x0185 }
                r11[r5] = r6     // Catch:{ IOException -> 0x0185 }
                int r5 = r5 + 1
                goto L_0x00cd
            L_0x00da:
                r3.close()     // Catch:{ IOException -> 0x00de }
                goto L_0x00e2
            L_0x00de:
                r2 = move-exception
                android.util.Log.e(r1, r0, r2)
            L_0x00e2:
                return r11
            L_0x00e3:
                int r11 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                int[] r11 = new int[r11]     // Catch:{ IOException -> 0x0185 }
            L_0x00e7:
                int r4 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                if (r5 >= r4) goto L_0x00f4
                int r4 = r3.readUnsignedShort()     // Catch:{ IOException -> 0x0185 }
                r11[r5] = r4     // Catch:{ IOException -> 0x0185 }
                int r5 = r5 + 1
                goto L_0x00e7
            L_0x00f4:
                r3.close()     // Catch:{ IOException -> 0x00f8 }
                goto L_0x00fc
            L_0x00f8:
                r2 = move-exception
                android.util.Log.e(r1, r0, r2)
            L_0x00fc:
                return r11
            L_0x00fd:
                int r11 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                byte[] r6 = androidx.exifinterface.media.C0034a.f79Y     // Catch:{ IOException -> 0x0185 }
                int r6 = r6.length     // Catch:{ IOException -> 0x0185 }
                if (r11 < r6) goto L_0x011a
                r11 = 0
            L_0x0105:
                byte[] r6 = androidx.exifinterface.media.C0034a.f79Y     // Catch:{ IOException -> 0x0185 }
                int r7 = r6.length     // Catch:{ IOException -> 0x0185 }
                if (r11 >= r7) goto L_0x0117
                byte[] r7 = r10.f143d     // Catch:{ IOException -> 0x0185 }
                byte r7 = r7[r11]     // Catch:{ IOException -> 0x0185 }
                byte r8 = r6[r11]     // Catch:{ IOException -> 0x0185 }
                if (r7 == r8) goto L_0x0114
                r4 = 0
                goto L_0x0117
            L_0x0114:
                int r11 = r11 + 1
                goto L_0x0105
            L_0x0117:
                if (r4 == 0) goto L_0x011a
                int r5 = r6.length     // Catch:{ IOException -> 0x0185 }
            L_0x011a:
                java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x0185 }
                r11.<init>()     // Catch:{ IOException -> 0x0185 }
            L_0x011f:
                int r4 = r10.f141b     // Catch:{ IOException -> 0x0185 }
                if (r5 >= r4) goto L_0x013b
                byte[] r4 = r10.f143d     // Catch:{ IOException -> 0x0185 }
                byte r4 = r4[r5]     // Catch:{ IOException -> 0x0185 }
                if (r4 != 0) goto L_0x012a
                goto L_0x013b
            L_0x012a:
                r6 = 32
                if (r4 < r6) goto L_0x0133
                char r4 = (char) r4     // Catch:{ IOException -> 0x0185 }
                r11.append(r4)     // Catch:{ IOException -> 0x0185 }
                goto L_0x0138
            L_0x0133:
                r4 = 63
                r11.append(r4)     // Catch:{ IOException -> 0x0185 }
            L_0x0138:
                int r5 = r5 + 1
                goto L_0x011f
            L_0x013b:
                java.lang.String r11 = r11.toString()     // Catch:{ IOException -> 0x0185 }
                r3.close()     // Catch:{ IOException -> 0x0143 }
                goto L_0x0147
            L_0x0143:
                r2 = move-exception
                android.util.Log.e(r1, r0, r2)
            L_0x0147:
                return r11
            L_0x0148:
                byte[] r11 = r10.f143d     // Catch:{ IOException -> 0x0185 }
                int r6 = r11.length     // Catch:{ IOException -> 0x0185 }
                if (r6 != r4) goto L_0x016c
                byte r6 = r11[r5]     // Catch:{ IOException -> 0x0185 }
                if (r6 < 0) goto L_0x016c
                byte r6 = r11[r5]     // Catch:{ IOException -> 0x0185 }
                if (r6 > r4) goto L_0x016c
                java.lang.String r6 = new java.lang.String     // Catch:{ IOException -> 0x0185 }
                char[] r4 = new char[r4]     // Catch:{ IOException -> 0x0185 }
                byte r11 = r11[r5]     // Catch:{ IOException -> 0x0185 }
                int r11 = r11 + 48
                char r11 = (char) r11     // Catch:{ IOException -> 0x0185 }
                r4[r5] = r11     // Catch:{ IOException -> 0x0185 }
                r6.<init>(r4)     // Catch:{ IOException -> 0x0185 }
                r3.close()     // Catch:{ IOException -> 0x0167 }
                goto L_0x016b
            L_0x0167:
                r11 = move-exception
                android.util.Log.e(r1, r0, r11)
            L_0x016b:
                return r6
            L_0x016c:
                java.lang.String r4 = new java.lang.String     // Catch:{ IOException -> 0x0185 }
                java.nio.charset.Charset r5 = androidx.exifinterface.media.C0034a.f96p0     // Catch:{ IOException -> 0x0185 }
                r4.<init>(r11, r5)     // Catch:{ IOException -> 0x0185 }
                r3.close()     // Catch:{ IOException -> 0x0177 }
                goto L_0x017b
            L_0x0177:
                r11 = move-exception
                android.util.Log.e(r1, r0, r11)
            L_0x017b:
                return r4
            L_0x017c:
                r3.close()     // Catch:{ IOException -> 0x0180 }
                goto L_0x0184
            L_0x0180:
                r11 = move-exception
                android.util.Log.e(r1, r0, r11)
            L_0x0184:
                return r2
            L_0x0185:
                r11 = move-exception
                goto L_0x018b
            L_0x0187:
                r11 = move-exception
                goto L_0x019d
            L_0x0189:
                r11 = move-exception
                r3 = r2
            L_0x018b:
                java.lang.String r4 = "IOException occurred during reading a value"
                android.util.Log.w(r1, r4, r11)     // Catch:{ all -> 0x019b }
                if (r3 == 0) goto L_0x019a
                r3.close()     // Catch:{ IOException -> 0x0196 }
                goto L_0x019a
            L_0x0196:
                r11 = move-exception
                android.util.Log.e(r1, r0, r11)
            L_0x019a:
                return r2
            L_0x019b:
                r11 = move-exception
                r2 = r3
            L_0x019d:
                if (r2 == 0) goto L_0x01a7
                r2.close()     // Catch:{ IOException -> 0x01a3 }
                goto L_0x01a7
            L_0x01a3:
                r2 = move-exception
                android.util.Log.e(r1, r0, r2)
            L_0x01a7:
                goto L_0x01a9
            L_0x01a8:
                throw r11
            L_0x01a9:
                goto L_0x01a8
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.C0038d.mo85o(java.nio.ByteOrder):java.lang.Object");
        }

        /* renamed from: p */
        public int mo86p() {
            return C0034a.f78X[this.f140a] * this.f141b;
        }

        public String toString() {
            return "(" + C0034a.f77W[this.f140a] + ", data length:" + this.f143d.length + ")";
        }
    }

    /* renamed from: androidx.exifinterface.media.a$e */
    static class C0039e {

        /* renamed from: a */
        public final int f144a;

        /* renamed from: b */
        public final String f145b;

        /* renamed from: c */
        public final int f146c;

        /* renamed from: d */
        public final int f147d;

        C0039e(String str, int i, int i2) {
            this.f145b = str;
            this.f144a = i;
            this.f146c = i2;
            this.f147d = -1;
        }

        C0039e(String str, int i, int i2, int i3) {
            this.f145b = str;
            this.f144a = i;
            this.f146c = i2;
            this.f147d = i3;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public boolean mo88a(int i) {
            int i2;
            int i3 = this.f146c;
            if (i3 == 7 || i == 7 || i3 == i || (i2 = this.f147d) == i) {
                return true;
            }
            if ((i3 == 4 || i2 == 4) && i == 3) {
                return true;
            }
            if ((i3 == 9 || i2 == 9) && i == 8) {
                return true;
            }
            return (i3 == 12 || i2 == 12) && i == 11;
        }
    }

    /* renamed from: androidx.exifinterface.media.a$f */
    private static class C0040f {

        /* renamed from: a */
        public final long f148a;

        /* renamed from: b */
        public final long f149b;

        C0040f(double d) {
            this((long) (d * 10000.0d), 10000);
        }

        C0040f(long j, long j2) {
            if (j2 == 0) {
                this.f148a = 0;
                this.f149b = 1;
                return;
            }
            this.f148a = j;
            this.f149b = j2;
        }

        /* renamed from: a */
        public double mo89a() {
            double d = (double) this.f148a;
            double d2 = (double) this.f149b;
            Double.isNaN(d);
            Double.isNaN(d2);
            return d / d2;
        }

        public String toString() {
            return this.f148a + "/" + this.f149b;
        }
    }

    /* renamed from: androidx.exifinterface.media.a$g */
    private static class C0041g extends C0036b {
        C0041g(InputStream inputStream) {
            super(inputStream);
            if (inputStream.markSupported()) {
                this.f134d.mark(Integer.MAX_VALUE);
                return;
            }
            throw new IllegalArgumentException("Cannot create SeekableByteOrderedDataInputStream with stream that does not support mark/reset");
        }

        C0041g(byte[] bArr) {
            super(bArr);
            this.f134d.mark(Integer.MAX_VALUE);
        }

        /* renamed from: e */
        public void mo91e(long j) {
            int i = this.f136f;
            if (((long) i) > j) {
                this.f136f = 0;
                this.f134d.reset();
            } else {
                j -= (long) i;
            }
            mo54d((int) j);
        }
    }

    static {
        C0039e[] eVarArr = {new C0039e("NewSubfileType", 254, 4), new C0039e("SubfileType", 255, 4), new C0039e("ImageWidth", 256, 3, 4), new C0039e("ImageLength", 257, 3, 4), new C0039e("BitsPerSample", 258, 3), new C0039e("Compression", 259, 3), new C0039e("PhotometricInterpretation", 262, 3), new C0039e("ImageDescription", 270, 2), new C0039e("Make", 271, 2), new C0039e("Model", 272, 2), new C0039e("StripOffsets", 273, 3, 4), new C0039e("Orientation", 274, 3), new C0039e("SamplesPerPixel", 277, 3), new C0039e("RowsPerStrip", 278, 3, 4), new C0039e("StripByteCounts", 279, 3, 4), new C0039e("XResolution", 282, 5), new C0039e("YResolution", 283, 5), new C0039e("PlanarConfiguration", 284, 3), new C0039e("ResolutionUnit", 296, 3), new C0039e("TransferFunction", 301, 3), new C0039e("Software", 305, 2), new C0039e("DateTime", 306, 2), new C0039e("Artist", 315, 2), new C0039e("WhitePoint", 318, 5), new C0039e("PrimaryChromaticities", 319, 5), new C0039e("SubIFDPointer", 330, 4), new C0039e("JPEGInterchangeFormat", 513, 4), new C0039e("JPEGInterchangeFormatLength", 514, 4), new C0039e("YCbCrCoefficients", 529, 5), new C0039e("YCbCrSubSampling", 530, 3), new C0039e("YCbCrPositioning", 531, 3), new C0039e("ReferenceBlackWhite", 532, 5), new C0039e("Copyright", 33432, 2), new C0039e("ExifIFDPointer", 34665, 4), new C0039e("GPSInfoIFDPointer", 34853, 4), new C0039e("SensorTopBorder", 4, 4), new C0039e("SensorLeftBorder", 5, 4), new C0039e("SensorBottomBorder", 6, 4), new C0039e("SensorRightBorder", 7, 4), new C0039e("ISO", 23, 3), new C0039e("JpgFromRaw", 46, 7), new C0039e("Xmp", 700, 1)};
        f80Z = eVarArr;
        C0039e[] eVarArr2 = {new C0039e("ExposureTime", 33434, 5), new C0039e("FNumber", 33437, 5), new C0039e("ExposureProgram", 34850, 3), new C0039e("SpectralSensitivity", 34852, 2), new C0039e("PhotographicSensitivity", 34855, 3), new C0039e("OECF", 34856, 7), new C0039e("SensitivityType", 34864, 3), new C0039e("StandardOutputSensitivity", 34865, 4), new C0039e("RecommendedExposureIndex", 34866, 4), new C0039e("ISOSpeed", 34867, 4), new C0039e("ISOSpeedLatitudeyyy", 34868, 4), new C0039e("ISOSpeedLatitudezzz", 34869, 4), new C0039e("ExifVersion", 36864, 2), new C0039e("DateTimeOriginal", 36867, 2), new C0039e("DateTimeDigitized", 36868, 2), new C0039e("OffsetTime", 36880, 2), new C0039e("OffsetTimeOriginal", 36881, 2), new C0039e("OffsetTimeDigitized", 36882, 2), new C0039e("ComponentsConfiguration", 37121, 7), new C0039e("CompressedBitsPerPixel", 37122, 5), new C0039e("ShutterSpeedValue", 37377, 10), new C0039e("ApertureValue", 37378, 5), new C0039e("BrightnessValue", 37379, 10), new C0039e("ExposureBiasValue", 37380, 10), new C0039e("MaxApertureValue", 37381, 5), new C0039e("SubjectDistance", 37382, 5), new C0039e("MeteringMode", 37383, 3), new C0039e("LightSource", 37384, 3), new C0039e("Flash", 37385, 3), new C0039e("FocalLength", 37386, 5), new C0039e("SubjectArea", 37396, 3), new C0039e("MakerNote", 37500, 7), new C0039e("UserComment", 37510, 7), new C0039e("SubSecTime", 37520, 2), new C0039e("SubSecTimeOriginal", 37521, 2), new C0039e("SubSecTimeDigitized", 37522, 2), new C0039e("FlashpixVersion", 40960, 7), new C0039e("ColorSpace", 40961, 3), new C0039e("PixelXDimension", 40962, 3, 4), new C0039e("PixelYDimension", 40963, 3, 4), new C0039e("RelatedSoundFile", 40964, 2), new C0039e("InteroperabilityIFDPointer", 40965, 4), new C0039e("FlashEnergy", 41483, 5), new C0039e("SpatialFrequencyResponse", 41484, 7), new C0039e("FocalPlaneXResolution", 41486, 5), new C0039e("FocalPlaneYResolution", 41487, 5), new C0039e("FocalPlaneResolutionUnit", 41488, 3), new C0039e("SubjectLocation", 41492, 3), new C0039e("ExposureIndex", 41493, 5), new C0039e("SensingMethod", 41495, 3), new C0039e("FileSource", 41728, 7), new C0039e("SceneType", 41729, 7), new C0039e("CFAPattern", 41730, 7), new C0039e("CustomRendered", 41985, 3), new C0039e("ExposureMode", 41986, 3), new C0039e("WhiteBalance", 41987, 3), new C0039e("DigitalZoomRatio", 41988, 5), new C0039e("FocalLengthIn35mmFilm", 41989, 3), new C0039e("SceneCaptureType", 41990, 3), new C0039e("GainControl", 41991, 3), new C0039e("Contrast", 41992, 3), new C0039e("Saturation", 41993, 3), new C0039e("Sharpness", 41994, 3), new C0039e("DeviceSettingDescription", 41995, 7), new C0039e("SubjectDistanceRange", 41996, 3), new C0039e("ImageUniqueID", 42016, 2), new C0039e("CameraOwnerName", 42032, 2), new C0039e("BodySerialNumber", 42033, 2), new C0039e("LensSpecification", 42034, 5), new C0039e("LensMake", 42035, 2), new C0039e("LensModel", 42036, 2), new C0039e("Gamma", 42240, 5), new C0039e("DNGVersion", 50706, 1), new C0039e("DefaultCropSize", 50720, 3, 4)};
        f81a0 = eVarArr2;
        C0039e[] eVarArr3 = {new C0039e("GPSVersionID", 0, 1), new C0039e("GPSLatitudeRef", 1, 2), new C0039e("GPSLatitude", 2, 5, 10), new C0039e("GPSLongitudeRef", 3, 2), new C0039e("GPSLongitude", 4, 5, 10), new C0039e("GPSAltitudeRef", 5, 1), new C0039e("GPSAltitude", 6, 5), new C0039e("GPSTimeStamp", 7, 5), new C0039e("GPSSatellites", 8, 2), new C0039e("GPSStatus", 9, 2), new C0039e("GPSMeasureMode", 10, 2), new C0039e("GPSDOP", 11, 5), new C0039e("GPSSpeedRef", 12, 2), new C0039e("GPSSpeed", 13, 5), new C0039e("GPSTrackRef", 14, 2), new C0039e("GPSTrack", 15, 5), new C0039e("GPSImgDirectionRef", 16, 2), new C0039e("GPSImgDirection", 17, 5), new C0039e("GPSMapDatum", 18, 2), new C0039e("GPSDestLatitudeRef", 19, 2), new C0039e("GPSDestLatitude", 20, 5), new C0039e("GPSDestLongitudeRef", 21, 2), new C0039e("GPSDestLongitude", 22, 5), new C0039e("GPSDestBearingRef", 23, 2), new C0039e("GPSDestBearing", 24, 5), new C0039e("GPSDestDistanceRef", 25, 2), new C0039e("GPSDestDistance", 26, 5), new C0039e("GPSProcessingMethod", 27, 7), new C0039e("GPSAreaInformation", 28, 7), new C0039e("GPSDateStamp", 29, 2), new C0039e("GPSDifferential", 30, 3), new C0039e("GPSHPositioningError", 31, 5)};
        f82b0 = eVarArr3;
        C0039e[] eVarArr4 = {new C0039e("InteroperabilityIndex", 1, 2)};
        f83c0 = eVarArr4;
        C0039e[] eVarArr5 = {new C0039e("NewSubfileType", 254, 4), new C0039e("SubfileType", 255, 4), new C0039e("ThumbnailImageWidth", 256, 3, 4), new C0039e("ThumbnailImageLength", 257, 3, 4), new C0039e("BitsPerSample", 258, 3), new C0039e("Compression", 259, 3), new C0039e("PhotometricInterpretation", 262, 3), new C0039e("ImageDescription", 270, 2), new C0039e("Make", 271, 2), new C0039e("Model", 272, 2), new C0039e("StripOffsets", 273, 3, 4), new C0039e("ThumbnailOrientation", 274, 3), new C0039e("SamplesPerPixel", 277, 3), new C0039e("RowsPerStrip", 278, 3, 4), new C0039e("StripByteCounts", 279, 3, 4), new C0039e("XResolution", 282, 5), new C0039e("YResolution", 283, 5), new C0039e("PlanarConfiguration", 284, 3), new C0039e("ResolutionUnit", 296, 3), new C0039e("TransferFunction", 301, 3), new C0039e("Software", 305, 2), new C0039e("DateTime", 306, 2), new C0039e("Artist", 315, 2), new C0039e("WhitePoint", 318, 5), new C0039e("PrimaryChromaticities", 319, 5), new C0039e("SubIFDPointer", 330, 4), new C0039e("JPEGInterchangeFormat", 513, 4), new C0039e("JPEGInterchangeFormatLength", 514, 4), new C0039e("YCbCrCoefficients", 529, 5), new C0039e("YCbCrSubSampling", 530, 3), new C0039e("YCbCrPositioning", 531, 3), new C0039e("ReferenceBlackWhite", 532, 5), new C0039e("Xmp", 700, 1), new C0039e("Copyright", 33432, 2), new C0039e("ExifIFDPointer", 34665, 4), new C0039e("GPSInfoIFDPointer", 34853, 4), new C0039e("DNGVersion", 50706, 1), new C0039e("DefaultCropSize", 50720, 3, 4)};
        f84d0 = eVarArr5;
        C0039e[] eVarArr6 = {new C0039e("ThumbnailImage", 256, 7), new C0039e("CameraSettingsIFDPointer", 8224, 4), new C0039e("ImageProcessingIFDPointer", 8256, 4)};
        f86f0 = eVarArr6;
        C0039e[] eVarArr7 = {new C0039e("PreviewImageStart", 257, 4), new C0039e("PreviewImageLength", 258, 4)};
        f87g0 = eVarArr7;
        C0039e[] eVarArr8 = {new C0039e("AspectFrame", 4371, 3)};
        f88h0 = eVarArr8;
        C0039e[] eVarArr9 = {new C0039e("ColorSpace", 55, 3)};
        f89i0 = eVarArr9;
        C0039e[][] eVarArr10 = {eVarArr, eVarArr2, eVarArr3, eVarArr4, eVarArr5, eVarArr, eVarArr6, eVarArr7, eVarArr8, eVarArr9};
        f90j0 = eVarArr10;
        f92l0 = new HashMap[eVarArr10.length];
        f93m0 = new HashMap[eVarArr10.length];
        Charset forName = Charset.forName("US-ASCII");
        f96p0 = forName;
        f97q0 = "Exif\u0000\u0000".getBytes(forName);
        f98r0 = "http://ns.adobe.com/xap/1.0/\u0000".getBytes(forName);
        Locale locale = Locale.US;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss", locale);
        f75U = simpleDateFormat;
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", locale);
        f76V = simpleDateFormat2;
        simpleDateFormat2.setTimeZone(TimeZone.getTimeZone("UTC"));
        int i = 0;
        while (true) {
            C0039e[][] eVarArr11 = f90j0;
            if (i < eVarArr11.length) {
                f92l0[i] = new HashMap<>();
                f93m0[i] = new HashMap<>();
                for (C0039e eVar : eVarArr11[i]) {
                    f92l0[i].put(Integer.valueOf(eVar.f144a), eVar);
                    f93m0[i].put(eVar.f145b, eVar);
                }
                i++;
            } else {
                HashMap<Integer, Integer> hashMap = f95o0;
                C0039e[] eVarArr12 = f91k0;
                hashMap.put(Integer.valueOf(eVarArr12[0].f144a), 5);
                hashMap.put(Integer.valueOf(eVarArr12[1].f144a), 1);
                hashMap.put(Integer.valueOf(eVarArr12[2].f144a), 2);
                hashMap.put(Integer.valueOf(eVarArr12[3].f144a), 3);
                hashMap.put(Integer.valueOf(eVarArr12[4].f144a), 7);
                hashMap.put(Integer.valueOf(eVarArr12[5].f144a), 8);
                return;
            }
        }
    }

    public C0034a(String str) {
        C0039e[][] eVarArr = f90j0;
        this.f113f = new HashMap[eVarArr.length];
        this.f114g = new HashSet(eVarArr.length);
        if (str != null) {
            m124u(str);
            return;
        }
        throw new NullPointerException("filename cannot be null");
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x0025  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x002c  */
    /* renamed from: A */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m83A(byte[] r4) {
        /*
            r3 = this;
            r0 = 0
            r1 = 0
            androidx.exifinterface.media.a$b r2 = new androidx.exifinterface.media.a$b     // Catch:{ Exception -> 0x0029, all -> 0x0022 }
            r2.<init>((byte[]) r4)     // Catch:{ Exception -> 0x0029, all -> 0x0022 }
            java.nio.ByteOrder r4 = r3.m92J(r2)     // Catch:{ Exception -> 0x0020, all -> 0x001d }
            r3.f115h = r4     // Catch:{ Exception -> 0x0020, all -> 0x001d }
            r2.mo53c(r4)     // Catch:{ Exception -> 0x0020, all -> 0x001d }
            short r4 = r2.readShort()     // Catch:{ Exception -> 0x0020, all -> 0x001d }
            r1 = 85
            if (r4 != r1) goto L_0x0019
            r0 = 1
        L_0x0019:
            r2.close()
            return r0
        L_0x001d:
            r4 = move-exception
            r1 = r2
            goto L_0x0023
        L_0x0020:
            r1 = r2
            goto L_0x002a
        L_0x0022:
            r4 = move-exception
        L_0x0023:
            if (r1 == 0) goto L_0x0028
            r1.close()
        L_0x0028:
            throw r4
        L_0x0029:
        L_0x002a:
            if (r1 == 0) goto L_0x002f
            r1.close()
        L_0x002f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.m83A(byte[]):boolean");
    }

    /* renamed from: B */
    private static boolean m84B(FileDescriptor fileDescriptor) {
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                C0042b.C0043a.m173c(fileDescriptor, 0, OsConstants.SEEK_CUR);
                return true;
            } catch (Exception unused) {
                if (f102v) {
                    Log.d("ExifInterface", "The file descriptor for the given input is not seekable");
                }
            }
        }
        return false;
    }

    /* renamed from: C */
    private boolean m85C(HashMap hashMap) {
        C0038d dVar;
        int m;
        C0038d dVar2 = (C0038d) hashMap.get("BitsPerSample");
        if (dVar2 != null) {
            int[] iArr = (int[]) dVar2.mo85o(this.f115h);
            int[] iArr2 = f106y;
            if (Arrays.equals(iArr2, iArr)) {
                return true;
            }
            if (this.f111d == 3 && (dVar = (C0038d) hashMap.get("PhotometricInterpretation")) != null && (((m = dVar.mo83m(this.f115h)) == 1 && Arrays.equals(iArr, f55A)) || (m == 6 && Arrays.equals(iArr, iArr2)))) {
                return true;
            }
        }
        if (!f102v) {
            return false;
        }
        Log.d("ExifInterface", "Unsupported data type value");
        return false;
    }

    /* renamed from: D */
    private static boolean m86D(int i) {
        return i == 4 || i == 13 || i == 14 || i == 3 || i == 0;
    }

    /* renamed from: E */
    private boolean m87E(HashMap hashMap) {
        C0038d dVar = (C0038d) hashMap.get("ImageLength");
        C0038d dVar2 = (C0038d) hashMap.get("ImageWidth");
        if (dVar == null || dVar2 == null) {
            return false;
        }
        return dVar.mo83m(this.f115h) <= 512 && dVar2.mo83m(this.f115h) <= 512;
    }

    /* renamed from: F */
    private boolean m88F(byte[] bArr) {
        int i = 0;
        while (true) {
            byte[] bArr2 = f66L;
            if (i >= bArr2.length) {
                int i2 = 0;
                while (true) {
                    byte[] bArr3 = f67M;
                    if (i2 >= bArr3.length) {
                        return true;
                    }
                    if (bArr[f66L.length + i2 + 4] != bArr3[i2]) {
                        return false;
                    }
                    i2++;
                }
            } else if (bArr[i] != bArr2[i]) {
                return false;
            } else {
                i++;
            }
        }
    }

    /* renamed from: G */
    private void m89G(InputStream inputStream) {
        if (inputStream != null) {
            int i = 0;
            while (i < f90j0.length) {
                try {
                    this.f113f[i] = new HashMap<>();
                    i++;
                } catch (IOException | UnsupportedOperationException e) {
                    boolean z = f102v;
                    if (z) {
                        Log.w("ExifInterface", "Invalid image: ExifInterface got an unsupported image format file(ExifInterface supports JPEG and some RAW image formats only) or a corrupted JPEG file to ExifInterface.", e);
                    }
                    m107a();
                    if (!z) {
                        return;
                    }
                } catch (Throwable th) {
                    m107a();
                    if (f102v) {
                        m91I();
                    }
                    throw th;
                }
            }
            if (!this.f112e) {
                BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream, 5000);
                this.f111d = m113h(bufferedInputStream);
                inputStream = bufferedInputStream;
            }
            if (m102V(this.f111d)) {
                C0041g gVar = new C0041g(inputStream);
                if (this.f112e) {
                    m119n(gVar);
                } else {
                    int i2 = this.f111d;
                    if (i2 == 12) {
                        m111f(gVar);
                    } else if (i2 == 7) {
                        m114i(gVar);
                    } else if (i2 == 10) {
                        m118m(gVar);
                    } else {
                        m117l(gVar);
                    }
                }
                gVar.mo91e((long) this.f123p);
                m101U(gVar);
            } else {
                C0036b bVar = new C0036b(inputStream);
                int i3 = this.f111d;
                if (i3 == 4) {
                    m112g(bVar, 0, 0);
                } else if (i3 == 13) {
                    m115j(bVar);
                } else if (i3 == 9) {
                    m116k(bVar);
                } else if (i3 == 14) {
                    m120q(bVar);
                }
            }
            m107a();
            if (!f102v) {
                return;
            }
            m91I();
            return;
        }
        throw new NullPointerException("inputstream shouldn't be null");
    }

    /* renamed from: H */
    private void m90H(C0036b bVar) {
        ByteOrder J = m92J(bVar);
        this.f115h = J;
        bVar.mo53c(J);
        int readUnsignedShort = bVar.readUnsignedShort();
        int i = this.f111d;
        if (i == 7 || i == 10 || readUnsignedShort == 42) {
            int readInt = bVar.readInt();
            if (readInt >= 8) {
                int i2 = readInt - 8;
                if (i2 > 0) {
                    bVar.mo54d(i2);
                    return;
                }
                return;
            }
            throw new IOException("Invalid first Ifd offset: " + readInt);
        }
        throw new IOException("Invalid start code: " + Integer.toHexString(readUnsignedShort));
    }

    /* renamed from: I */
    private void m91I() {
        for (int i = 0; i < this.f113f.length; i++) {
            Log.d("ExifInterface", "The size of tag group[" + i + "]: " + this.f113f[i].size());
            for (Map.Entry next : this.f113f[i].entrySet()) {
                C0038d dVar = (C0038d) next.getValue();
                Log.d("ExifInterface", "tagName: " + ((String) next.getKey()) + ", tagType: " + dVar.toString() + ", tagValue: '" + dVar.mo84n(this.f115h) + "'");
            }
        }
    }

    /* renamed from: J */
    private ByteOrder m92J(C0036b bVar) {
        short readShort = bVar.readShort();
        if (readShort == 18761) {
            if (f102v) {
                Log.d("ExifInterface", "readExifSegment: Byte Align II");
            }
            return ByteOrder.LITTLE_ENDIAN;
        } else if (readShort == 19789) {
            if (f102v) {
                Log.d("ExifInterface", "readExifSegment: Byte Align MM");
            }
            return ByteOrder.BIG_ENDIAN;
        } else {
            throw new IOException("Invalid byte order: " + Integer.toHexString(readShort));
        }
    }

    /* renamed from: K */
    private void m93K(byte[] bArr, int i) {
        C0041g gVar = new C0041g(bArr);
        m90H(gVar);
        m94L(gVar, i);
    }

    /* JADX WARNING: Removed duplicated region for block: B:43:0x012c  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0134  */
    /* JADX WARNING: Removed duplicated region for block: B:84:0x0222  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x0240  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x0279  */
    /* renamed from: L */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m94L(androidx.exifinterface.media.C0034a.C0041g r30, int r31) {
        /*
            r29 = this;
            r0 = r29
            r1 = r30
            r2 = r31
            java.util.Set<java.lang.Integer> r3 = r0.f114g
            int r4 = r1.f136f
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            r3.add(r4)
            short r3 = r30.readShort()
            boolean r4 = f102v
            java.lang.String r5 = "ExifInterface"
            if (r4 == 0) goto L_0x002f
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r6 = "numberOfDirectoryEntry: "
            r4.append(r6)
            r4.append(r3)
            java.lang.String r4 = r4.toString()
            android.util.Log.d(r5, r4)
        L_0x002f:
            if (r3 > 0) goto L_0x0032
            return
        L_0x0032:
            r4 = 0
            r6 = 0
        L_0x0034:
            r7 = 5
            if (r6 >= r3) goto L_0x0317
            int r12 = r30.readUnsignedShort()
            int r13 = r30.readUnsignedShort()
            int r15 = r30.readInt()
            int r14 = r30.mo50a()
            long r8 = (long) r14
            r18 = 4
            long r8 = r8 + r18
            java.util.HashMap<java.lang.Integer, androidx.exifinterface.media.a$e>[] r14 = f92l0
            r14 = r14[r2]
            java.lang.Integer r11 = java.lang.Integer.valueOf(r12)
            java.lang.Object r11 = r14.get(r11)
            androidx.exifinterface.media.a$e r11 = (androidx.exifinterface.media.C0034a.C0039e) r11
            boolean r14 = f102v
            r10 = 3
            if (r14 == 0) goto L_0x0090
            java.lang.Object[] r7 = new java.lang.Object[r7]
            java.lang.Integer r23 = java.lang.Integer.valueOf(r31)
            r7[r4] = r23
            java.lang.Integer r23 = java.lang.Integer.valueOf(r12)
            r21 = 1
            r7[r21] = r23
            if (r11 == 0) goto L_0x0074
            java.lang.String r4 = r11.f145b
            goto L_0x0075
        L_0x0074:
            r4 = 0
        L_0x0075:
            r22 = 2
            r7[r22] = r4
            java.lang.Integer r4 = java.lang.Integer.valueOf(r13)
            r7[r10] = r4
            java.lang.Integer r4 = java.lang.Integer.valueOf(r15)
            r20 = 4
            r7[r20] = r4
            java.lang.String r4 = "ifdType: %d, tagNumber: %d, tagName: %s, dataFormat: %d, numberOfComponents: %d"
            java.lang.String r4 = java.lang.String.format(r4, r7)
            android.util.Log.d(r5, r4)
        L_0x0090:
            r4 = 7
            if (r11 != 0) goto L_0x00ae
            if (r14 == 0) goto L_0x00a9
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r10 = "Skip the tag entry since tag number is not defined: "
            r7.append(r10)
            r7.append(r12)
        L_0x00a2:
            java.lang.String r7 = r7.toString()
            android.util.Log.d(r5, r7)
        L_0x00a9:
            r10 = r5
            r25 = r6
            goto L_0x0127
        L_0x00ae:
            if (r13 <= 0) goto L_0x010e
            int[] r7 = f78X
            int r10 = r7.length
            if (r13 < r10) goto L_0x00b6
            goto L_0x010e
        L_0x00b6:
            boolean r10 = r11.mo88a(r13)
            if (r10 != 0) goto L_0x00da
            if (r14 == 0) goto L_0x00a9
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r10 = "Skip the tag entry since data format ("
            r7.append(r10)
            java.lang.String[] r10 = f77W
            r10 = r10[r13]
            r7.append(r10)
            java.lang.String r10 = ") is unexpected for tag: "
            r7.append(r10)
            java.lang.String r10 = r11.f145b
            r7.append(r10)
            goto L_0x00a2
        L_0x00da:
            if (r13 != r4) goto L_0x00de
            int r13 = r11.f146c
        L_0x00de:
            r10 = r5
            long r4 = (long) r15
            r7 = r7[r13]
            r25 = r6
            long r6 = (long) r7
            long r4 = r4 * r6
            r6 = 0
            int r26 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r26 < 0) goto L_0x00f7
            r6 = 2147483647(0x7fffffff, double:1.060997895E-314)
            int r26 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r26 <= 0) goto L_0x00f5
            goto L_0x00f7
        L_0x00f5:
            r6 = 1
            goto L_0x012a
        L_0x00f7:
            if (r14 == 0) goto L_0x0129
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r7 = "Skip the tag entry since the number of components is invalid: "
            r6.append(r7)
            r6.append(r15)
            java.lang.String r6 = r6.toString()
            android.util.Log.d(r10, r6)
            goto L_0x0129
        L_0x010e:
            r10 = r5
            r25 = r6
            if (r14 == 0) goto L_0x0127
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = "Skip the tag entry since data format is invalid: "
            r4.append(r5)
            r4.append(r13)
            java.lang.String r4 = r4.toString()
            android.util.Log.d(r10, r4)
        L_0x0127:
            r4 = 0
        L_0x0129:
            r6 = 0
        L_0x012a:
            if (r6 != 0) goto L_0x0134
            r1.mo91e(r8)
            r26 = r3
            r8 = r10
            goto L_0x030e
        L_0x0134:
            java.lang.String r6 = "Compression"
            int r7 = (r4 > r18 ? 1 : (r4 == r18 ? 0 : -1))
            if (r7 <= 0) goto L_0x01be
            int r7 = r30.readInt()
            r26 = r3
            if (r14 == 0) goto L_0x0159
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            r27 = r8
            java.lang.String r8 = "seek to data offset: "
            r3.append(r8)
            r3.append(r7)
            java.lang.String r3 = r3.toString()
            android.util.Log.d(r10, r3)
            goto L_0x015b
        L_0x0159:
            r27 = r8
        L_0x015b:
            int r3 = r0.f111d
            r8 = 7
            if (r3 != r8) goto L_0x01b5
            java.lang.String r3 = r11.f145b
            java.lang.String r8 = "MakerNote"
            boolean r3 = r8.equals(r3)
            if (r3 == 0) goto L_0x016d
            r0.f124q = r7
            goto L_0x01b5
        L_0x016d:
            r3 = 6
            if (r2 != r3) goto L_0x01b5
            java.lang.String r8 = r11.f145b
            java.lang.String r9 = "ThumbnailImage"
            boolean r8 = r9.equals(r8)
            if (r8 == 0) goto L_0x01b5
            r0.f125r = r7
            r0.f126s = r15
            java.nio.ByteOrder r8 = r0.f115h
            androidx.exifinterface.media.a$d r3 = androidx.exifinterface.media.C0034a.C0038d.m154j(r3, r8)
            int r8 = r0.f125r
            long r8 = (long) r8
            r18 = r15
            java.nio.ByteOrder r15 = r0.f115h
            androidx.exifinterface.media.a$d r8 = androidx.exifinterface.media.C0034a.C0038d.m150f(r8, r15)
            int r9 = r0.f126s
            r24 = r10
            long r9 = (long) r9
            java.nio.ByteOrder r15 = r0.f115h
            androidx.exifinterface.media.a$d r9 = androidx.exifinterface.media.C0034a.C0038d.m150f(r9, r15)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r10 = r0.f113f
            r15 = 4
            r10 = r10[r15]
            r10.put(r6, r3)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r3 = r0.f113f
            r3 = r3[r15]
            java.lang.String r10 = "JPEGInterchangeFormat"
            r3.put(r10, r8)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r3 = r0.f113f
            r3 = r3[r15]
            java.lang.String r8 = "JPEGInterchangeFormatLength"
            r3.put(r8, r9)
            goto L_0x01b9
        L_0x01b5:
            r24 = r10
            r18 = r15
        L_0x01b9:
            long r7 = (long) r7
            r1.mo91e(r7)
            goto L_0x01c6
        L_0x01be:
            r26 = r3
            r27 = r8
            r24 = r10
            r18 = r15
        L_0x01c6:
            java.util.HashMap<java.lang.Integer, java.lang.Integer> r3 = f95o0
            java.lang.Integer r7 = java.lang.Integer.valueOf(r12)
            java.lang.Object r3 = r3.get(r7)
            java.lang.Integer r3 = (java.lang.Integer) r3
            if (r14 == 0) goto L_0x01f3
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r8 = "nextIfdType: "
            r7.append(r8)
            r7.append(r3)
            java.lang.String r8 = " byteCount: "
            r7.append(r8)
            r7.append(r4)
            java.lang.String r7 = r7.toString()
            r8 = r24
            android.util.Log.d(r8, r7)
            goto L_0x01f5
        L_0x01f3:
            r8 = r24
        L_0x01f5:
            r7 = 8
            if (r3 == 0) goto L_0x0296
            r4 = -1
            r6 = 3
            if (r13 == r6) goto L_0x021b
            r6 = 4
            if (r13 == r6) goto L_0x0216
            if (r13 == r7) goto L_0x0211
            r6 = 9
            if (r13 == r6) goto L_0x020c
            r6 = 13
            if (r13 == r6) goto L_0x020c
            goto L_0x0220
        L_0x020c:
            int r4 = r30.readInt()
            goto L_0x021f
        L_0x0211:
            short r4 = r30.readShort()
            goto L_0x021f
        L_0x0216:
            long r4 = r30.mo52b()
            goto L_0x0220
        L_0x021b:
            int r4 = r30.readUnsignedShort()
        L_0x021f:
            long r4 = (long) r4
        L_0x0220:
            if (r14 == 0) goto L_0x023a
            r6 = 2
            java.lang.Object[] r6 = new java.lang.Object[r6]
            java.lang.Long r7 = java.lang.Long.valueOf(r4)
            r9 = 0
            r6[r9] = r7
            java.lang.String r7 = r11.f145b
            r9 = 1
            r6[r9] = r7
            java.lang.String r7 = "Offset: %d, tagName: %s"
            java.lang.String r6 = java.lang.String.format(r7, r6)
            android.util.Log.d(r8, r6)
        L_0x023a:
            r6 = 0
            int r9 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r9 <= 0) goto L_0x0279
            java.util.Set<java.lang.Integer> r6 = r0.f114g
            int r7 = (int) r4
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)
            boolean r6 = r6.contains(r7)
            if (r6 != 0) goto L_0x0258
            r1.mo91e(r4)
            int r3 = r3.intValue()
            r0.m94L(r1, r3)
            goto L_0x028f
        L_0x0258:
            if (r14 == 0) goto L_0x028f
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r7 = "Skip jump into the IFD since it has already been read: IfdType "
            r6.append(r7)
            r6.append(r3)
            java.lang.String r3 = " (at "
            r6.append(r3)
            r6.append(r4)
            java.lang.String r3 = ")"
            r6.append(r3)
            java.lang.String r3 = r6.toString()
            goto L_0x028c
        L_0x0279:
            if (r14 == 0) goto L_0x028f
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r6 = "Skip jump into the IFD since its offset is invalid: "
            r3.append(r6)
            r3.append(r4)
            java.lang.String r3 = r3.toString()
        L_0x028c:
            android.util.Log.d(r8, r3)
        L_0x028f:
            r9 = r27
        L_0x0291:
            r1.mo91e(r9)
            goto L_0x030e
        L_0x0296:
            r9 = r27
            int r3 = r30.mo50a()
            int r12 = r0.f123p
            int r3 = r3 + r12
            int r5 = (int) r4
            byte[] r4 = new byte[r5]
            r1.readFully(r4)
            androidx.exifinterface.media.a$d r5 = new androidx.exifinterface.media.a$d
            long r14 = (long) r3
            r19 = r14
            r14 = r5
            r3 = r18
            r15 = r13
            r16 = r3
            r17 = r19
            r19 = r4
            r14.<init>(r15, r16, r17, r19)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r3 = r0.f113f
            r3 = r3[r2]
            java.lang.String r4 = r11.f145b
            r3.put(r4, r5)
            java.lang.String r3 = r11.f145b
            java.lang.String r4 = "DNGVersion"
            boolean r3 = r4.equals(r3)
            if (r3 == 0) goto L_0x02cd
            r3 = 3
            r0.f111d = r3
        L_0x02cd:
            java.lang.String r3 = r11.f145b
            java.lang.String r4 = "Make"
            boolean r3 = r4.equals(r3)
            if (r3 != 0) goto L_0x02e1
            java.lang.String r3 = r11.f145b
            java.lang.String r4 = "Model"
            boolean r3 = r4.equals(r3)
            if (r3 == 0) goto L_0x02ef
        L_0x02e1:
            java.nio.ByteOrder r3 = r0.f115h
            java.lang.String r3 = r5.mo84n(r3)
            java.lang.String r4 = "PENTAX"
            boolean r3 = r3.contains(r4)
            if (r3 != 0) goto L_0x0302
        L_0x02ef:
            java.lang.String r3 = r11.f145b
            boolean r3 = r6.equals(r3)
            if (r3 == 0) goto L_0x0304
            java.nio.ByteOrder r3 = r0.f115h
            int r3 = r5.mo83m(r3)
            r4 = 65535(0xffff, float:9.1834E-41)
            if (r3 != r4) goto L_0x0304
        L_0x0302:
            r0.f111d = r7
        L_0x0304:
            int r3 = r30.mo50a()
            long r3 = (long) r3
            int r5 = (r3 > r9 ? 1 : (r3 == r9 ? 0 : -1))
            if (r5 == 0) goto L_0x030e
            goto L_0x0291
        L_0x030e:
            int r6 = r25 + 1
            short r6 = (short) r6
            r5 = r8
            r3 = r26
            r4 = 0
            goto L_0x0034
        L_0x0317:
            r8 = r5
            int r2 = r30.readInt()
            boolean r3 = f102v
            if (r3 == 0) goto L_0x0333
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]
            java.lang.Integer r5 = java.lang.Integer.valueOf(r2)
            r6 = 0
            r4[r6] = r5
            java.lang.String r5 = "nextIfdOffset: %d"
            java.lang.String r4 = java.lang.String.format(r5, r4)
            android.util.Log.d(r8, r4)
        L_0x0333:
            long r4 = (long) r2
            r9 = 0
            int r6 = (r4 > r9 ? 1 : (r4 == r9 ? 0 : -1))
            if (r6 <= 0) goto L_0x0370
            java.util.Set<java.lang.Integer> r6 = r0.f114g
            java.lang.Integer r9 = java.lang.Integer.valueOf(r2)
            boolean r6 = r6.contains(r9)
            if (r6 != 0) goto L_0x0366
            r1.mo91e(r4)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r2 = r0.f113f
            r3 = 4
            r2 = r2[r3]
            boolean r2 = r2.isEmpty()
            if (r2 == 0) goto L_0x0358
            r0.m94L(r1, r3)
            goto L_0x0386
        L_0x0358:
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r2 = r0.f113f
            r2 = r2[r7]
            boolean r2 = r2.isEmpty()
            if (r2 == 0) goto L_0x0386
            r0.m94L(r1, r7)
            goto L_0x0386
        L_0x0366:
            if (r3 == 0) goto L_0x0386
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = "Stop reading file since re-reading an IFD may cause an infinite loop: "
            goto L_0x0379
        L_0x0370:
            if (r3 == 0) goto L_0x0386
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = "Stop reading file since a wrong offset may cause an infinite loop: "
        L_0x0379:
            r1.append(r3)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.d(r8, r1)
        L_0x0386:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.m94L(androidx.exifinterface.media.a$g, int):void");
    }

    /* renamed from: M */
    private void m95M(String str) {
        for (int i = 0; i < f90j0.length; i++) {
            this.f113f[i].remove(str);
        }
    }

    /* renamed from: N */
    private void m96N(int i, String str, String str2) {
        if (!this.f113f[i].isEmpty() && this.f113f[i].get(str) != null) {
            HashMap<String, C0038d>[] hashMapArr = this.f113f;
            hashMapArr[i].put(str2, hashMapArr[i].get(str));
            this.f113f[i].remove(str);
        }
    }

    /* renamed from: O */
    private void m97O(C0041g gVar, int i) {
        C0038d dVar = this.f113f[i].get("ImageLength");
        C0038d dVar2 = this.f113f[i].get("ImageWidth");
        if (dVar == null || dVar2 == null) {
            C0038d dVar3 = this.f113f[i].get("JPEGInterchangeFormat");
            C0038d dVar4 = this.f113f[i].get("JPEGInterchangeFormatLength");
            if (dVar3 != null && dVar4 != null) {
                int m = dVar3.mo83m(this.f115h);
                int m2 = dVar3.mo83m(this.f115h);
                gVar.mo91e((long) m);
                byte[] bArr = new byte[m2];
                gVar.read(bArr);
                m112g(new C0036b(bArr), m, i);
            }
        }
    }

    /* renamed from: Q */
    private void m98Q(InputStream inputStream, OutputStream outputStream) {
        if (f102v) {
            Log.d("ExifInterface", "saveJpegAttributes starting with (inputStream: " + inputStream + ", outputStream: " + outputStream + ")");
        }
        C0036b bVar = new C0036b(inputStream);
        C0037c cVar = new C0037c(outputStream, ByteOrder.BIG_ENDIAN);
        if (bVar.readByte() == -1) {
            cVar.mo75b(-1);
            if (bVar.readByte() == -40) {
                cVar.mo75b(-40);
                C0038d dVar = null;
                if (mo44d("Xmp") != null && this.f128u) {
                    dVar = this.f113f[0].remove("Xmp");
                }
                cVar.mo75b(-1);
                cVar.mo75b(-31);
                m106Z(cVar);
                if (dVar != null) {
                    this.f113f[0].put("Xmp", dVar);
                }
                byte[] bArr = new byte[4096];
                while (bVar.readByte() == -1) {
                    byte readByte = bVar.readByte();
                    if (readByte == -39 || readByte == -38) {
                        cVar.mo75b(-1);
                        cVar.mo75b(readByte);
                        C0042b.m168e(bVar, cVar);
                        return;
                    } else if (readByte != -31) {
                        cVar.mo75b(-1);
                        cVar.mo75b(readByte);
                        int readUnsignedShort = bVar.readUnsignedShort();
                        cVar.mo79f(readUnsignedShort);
                        int i = readUnsignedShort - 2;
                        if (i >= 0) {
                            while (i > 0) {
                                int read = bVar.read(bArr, 0, Math.min(i, 4096));
                                if (read < 0) {
                                    break;
                                }
                                cVar.write(bArr, 0, read);
                                i -= read;
                            }
                        } else {
                            throw new IOException("Invalid length");
                        }
                    } else {
                        int readUnsignedShort2 = bVar.readUnsignedShort() - 2;
                        if (readUnsignedShort2 >= 0) {
                            byte[] bArr2 = new byte[6];
                            if (readUnsignedShort2 >= 6) {
                                if (bVar.read(bArr2) != 6) {
                                    throw new IOException("Invalid exif");
                                } else if (Arrays.equals(bArr2, f97q0)) {
                                    bVar.mo54d(readUnsignedShort2 - 6);
                                }
                            }
                            cVar.mo75b(-1);
                            cVar.mo75b(readByte);
                            cVar.mo79f(readUnsignedShort2 + 2);
                            if (readUnsignedShort2 >= 6) {
                                readUnsignedShort2 -= 6;
                                cVar.write(bArr2);
                            }
                            while (readUnsignedShort2 > 0) {
                                int read2 = bVar.read(bArr, 0, Math.min(readUnsignedShort2, 4096));
                                if (read2 < 0) {
                                    break;
                                }
                                cVar.write(bArr, 0, read2);
                                readUnsignedShort2 -= read2;
                            }
                        } else {
                            throw new IOException("Invalid length");
                        }
                    }
                }
                throw new IOException("Invalid marker");
            }
            throw new IOException("Invalid marker");
        }
        throw new IOException("Invalid marker");
    }

    /* renamed from: R */
    private void m99R(InputStream inputStream, OutputStream outputStream) {
        if (f102v) {
            Log.d("ExifInterface", "savePngAttributes starting with (inputStream: " + inputStream + ", outputStream: " + outputStream + ")");
        }
        C0036b bVar = new C0036b(inputStream);
        ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
        C0037c cVar = new C0037c(outputStream, byteOrder);
        byte[] bArr = f62H;
        C0042b.m169f(bVar, cVar, bArr.length);
        int i = this.f123p;
        if (i == 0) {
            int readInt = bVar.readInt();
            cVar.mo76c(readInt);
            C0042b.m169f(bVar, cVar, readInt + 4 + 4);
        } else {
            C0042b.m169f(bVar, cVar, ((i - bArr.length) - 4) - 4);
            bVar.mo54d(bVar.readInt() + 4 + 4);
        }
        ByteArrayOutputStream byteArrayOutputStream = null;
        try {
            ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
            try {
                C0037c cVar2 = new C0037c(byteArrayOutputStream2, byteOrder);
                m106Z(cVar2);
                byte[] byteArray = ((ByteArrayOutputStream) cVar2.f138d).toByteArray();
                cVar.write(byteArray);
                CRC32 crc32 = new CRC32();
                crc32.update(byteArray, 4, byteArray.length - 4);
                cVar.mo76c((int) crc32.getValue());
                C0042b.m166c(byteArrayOutputStream2);
                C0042b.m168e(bVar, cVar);
            } catch (Throwable th) {
                th = th;
                byteArrayOutputStream = byteArrayOutputStream2;
                C0042b.m166c(byteArrayOutputStream);
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            C0042b.m166c(byteArrayOutputStream);
            throw th;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:59:0x01a3 A[Catch:{ Exception -> 0x01e5, all -> 0x01e2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x01af A[Catch:{ Exception -> 0x01e5, all -> 0x01e2 }] */
    /* renamed from: S */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m100S(java.io.InputStream r21, java.io.OutputStream r22) {
        /*
            r20 = this;
            r1 = r20
            r0 = r21
            r2 = r22
            boolean r3 = f102v
            if (r3 == 0) goto L_0x002d
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "saveWebpAttributes starting with (inputStream: "
            r3.append(r4)
            r3.append(r0)
            java.lang.String r4 = ", outputStream: "
            r3.append(r4)
            r3.append(r2)
            java.lang.String r4 = ")"
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            java.lang.String r4 = "ExifInterface"
            android.util.Log.d(r4, r3)
        L_0x002d:
            androidx.exifinterface.media.a$b r3 = new androidx.exifinterface.media.a$b
            java.nio.ByteOrder r4 = java.nio.ByteOrder.LITTLE_ENDIAN
            r3.<init>(r0, r4)
            androidx.exifinterface.media.a$c r5 = new androidx.exifinterface.media.a$c
            r5.<init>(r2, r4)
            byte[] r2 = f66L
            int r6 = r2.length
            androidx.exifinterface.media.C0042b.m169f(r3, r5, r6)
            byte[] r6 = f67M
            int r7 = r6.length
            r8 = 4
            int r7 = r7 + r8
            r3.mo54d(r7)
            r7 = 0
            java.io.ByteArrayOutputStream r9 = new java.io.ByteArrayOutputStream     // Catch:{ Exception -> 0x01ea }
            r9.<init>()     // Catch:{ Exception -> 0x01ea }
            androidx.exifinterface.media.a$c r10 = new androidx.exifinterface.media.a$c     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r10.<init>(r9, r4)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r4 = r1.f123p     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r4 == 0) goto L_0x006f
            int r0 = r2.length     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r0 = r0 + r8
            int r2 = r6.length     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r0 = r0 + r2
            int r4 = r4 - r0
            int r4 = r4 - r8
            int r4 = r4 - r8
            androidx.exifinterface.media.C0042b.m169f(r3, r10, r4)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r3.mo54d(r8)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r0 = r3.readInt()     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r3.mo54d(r0)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
        L_0x006a:
            r1.m106Z(r10)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            goto L_0x01c2
        L_0x006f:
            byte[] r2 = new byte[r8]     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r4 = r3.read(r2)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r4 != r8) goto L_0x01da
            byte[] r4 = f70P     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            boolean r6 = java.util.Arrays.equals(r2, r4)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r11 = 8
            r12 = 1
            r13 = 0
            if (r6 == 0) goto L_0x00cc
            int r2 = r3.readInt()     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r6 = r2 % 2
            if (r6 != r12) goto L_0x008e
            int r6 = r2 + 1
            goto L_0x008f
        L_0x008e:
            r6 = r2
        L_0x008f:
            byte[] r6 = new byte[r6]     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r3.read(r6)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            byte r14 = r6[r13]     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r11 = r11 | r14
            byte r11 = (byte) r11     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r6[r13] = r11     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            byte r11 = r6[r13]     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r11 = r11 >> r12
            r11 = r11 & r12
            if (r11 != r12) goto L_0x00a1
            goto L_0x00a2
        L_0x00a1:
            r12 = 0
        L_0x00a2:
            r10.write(r4)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r10.mo76c(r2)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r10.write(r6)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r12 == 0) goto L_0x00c4
            byte[] r2 = f73S     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r1.m108b(r3, r10, r2, r7)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
        L_0x00b2:
            byte[] r2 = new byte[r8]     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r0.read(r2)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            byte[] r4 = f74T     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            boolean r4 = java.util.Arrays.equals(r2, r4)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r4 != 0) goto L_0x00c0
            goto L_0x006a
        L_0x00c0:
            r1.m109c(r3, r10, r2)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            goto L_0x00b2
        L_0x00c4:
            byte[] r0 = f72R     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            byte[] r2 = f71Q     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r1.m108b(r3, r10, r0, r2)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            goto L_0x006a
        L_0x00cc:
            byte[] r0 = f72R     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            boolean r6 = java.util.Arrays.equals(r2, r0)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r6 != 0) goto L_0x00dc
            byte[] r6 = f71Q     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            boolean r6 = java.util.Arrays.equals(r2, r6)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r6 == 0) goto L_0x01c2
        L_0x00dc:
            int r6 = r3.readInt()     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r7 = r6 % 2
            if (r7 != r12) goto L_0x00e7
            int r7 = r6 + 1
            goto L_0x00e8
        L_0x00e7:
            r7 = r6
        L_0x00e8:
            r14 = 3
            byte[] r15 = new byte[r14]     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            boolean r16 = java.util.Arrays.equals(r2, r0)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r8 = 47
            if (r16 == 0) goto L_0x011d
            r3.read(r15)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            byte[] r12 = new byte[r14]     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r11 = r3.read(r12)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r11 != r14) goto L_0x0115
            byte[] r11 = f69O     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            boolean r11 = java.util.Arrays.equals(r11, r12)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r11 == 0) goto L_0x0115
            int r11 = r3.readInt()     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r12 = r11 << 18
            int r12 = r12 >> 18
            int r14 = r11 << 2
            int r14 = r14 >> 18
            int r7 = r7 + -10
            goto L_0x014f
        L_0x0115:
            java.io.IOException r0 = new java.io.IOException     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            java.lang.String r2 = "Encountered error while checking VP8 signature"
            r0.<init>(r2)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            throw r0     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
        L_0x011d:
            byte[] r11 = f71Q     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            boolean r11 = java.util.Arrays.equals(r2, r11)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r11 == 0) goto L_0x014c
            byte r11 = r3.readByte()     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r11 != r8) goto L_0x0144
            int r11 = r3.readInt()     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r14 = r11 << 18
            int r14 = r14 >> 18
            int r14 = r14 + r12
            int r17 = r11 << 4
            int r17 = r17 >> 18
            int r12 = r17 + 1
            r17 = r11 & 8
            int r7 = r7 + -5
            r19 = r14
            r14 = r12
            r12 = r19
            goto L_0x0151
        L_0x0144:
            java.io.IOException r0 = new java.io.IOException     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            java.lang.String r2 = "Encountered error while checking VP8L signature"
            r0.<init>(r2)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            throw r0     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
        L_0x014c:
            r11 = 0
            r12 = 0
            r14 = 0
        L_0x014f:
            r17 = 0
        L_0x0151:
            r10.write(r4)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r4 = 10
            r10.mo76c(r4)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            byte[] r4 = new byte[r4]     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            byte r18 = r4[r13]     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r16 = 8
            r8 = r18 | 8
            byte r8 = (byte) r8     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r4[r13] = r8     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            byte r8 = r4[r13]     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r18 = 4
            int r17 = r17 << 4
            r8 = r8 | r17
            byte r8 = (byte) r8     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r4[r13] = r8     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r12 = r12 + -1
            int r14 = r14 + -1
            byte r8 = (byte) r12     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r4[r18] = r8     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r8 = 5
            int r13 = r12 >> 8
            byte r13 = (byte) r13     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r4[r8] = r13     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r8 = 6
            int r12 = r12 >> 16
            byte r12 = (byte) r12     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r4[r8] = r12     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r8 = 7
            byte r12 = (byte) r14     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r4[r8] = r12     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r8 = r14 >> 8
            byte r8 = (byte) r8     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r12 = 8
            r4[r12] = r8     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r8 = 9
            int r12 = r14 >> 16
            byte r12 = (byte) r12     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r4[r8] = r12     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r10.write(r4)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r10.write(r2)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r10.mo76c(r6)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            boolean r0 = java.util.Arrays.equals(r2, r0)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r0 == 0) goto L_0x01af
            r10.write(r15)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            byte[] r0 = f69O     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r10.write(r0)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
        L_0x01ab:
            r10.mo76c(r11)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            goto L_0x01bd
        L_0x01af:
            byte[] r0 = f71Q     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            boolean r0 = java.util.Arrays.equals(r2, r0)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            if (r0 == 0) goto L_0x01bd
            r0 = 47
            r10.write(r0)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            goto L_0x01ab
        L_0x01bd:
            androidx.exifinterface.media.C0042b.m169f(r3, r10, r7)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            goto L_0x006a
        L_0x01c2:
            androidx.exifinterface.media.C0042b.m168e(r3, r10)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r0 = r9.size()     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            byte[] r2 = f67M     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r3 = r2.length     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            int r0 = r0 + r3
            r5.mo76c(r0)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r5.write(r2)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            r9.writeTo(r5)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            androidx.exifinterface.media.C0042b.m166c(r9)
            return
        L_0x01da:
            java.io.IOException r0 = new java.io.IOException     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            java.lang.String r2 = "Encountered invalid length while parsing WebP chunk type"
            r0.<init>(r2)     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
            throw r0     // Catch:{ Exception -> 0x01e5, all -> 0x01e2 }
        L_0x01e2:
            r0 = move-exception
            r7 = r9
            goto L_0x01f3
        L_0x01e5:
            r0 = move-exception
            r7 = r9
            goto L_0x01eb
        L_0x01e8:
            r0 = move-exception
            goto L_0x01f3
        L_0x01ea:
            r0 = move-exception
        L_0x01eb:
            java.io.IOException r2 = new java.io.IOException     // Catch:{ all -> 0x01e8 }
            java.lang.String r3 = "Failed to save WebP file"
            r2.<init>(r3, r0)     // Catch:{ all -> 0x01e8 }
            throw r2     // Catch:{ all -> 0x01e8 }
        L_0x01f3:
            androidx.exifinterface.media.C0042b.m166c(r7)
            goto L_0x01f8
        L_0x01f7:
            throw r0
        L_0x01f8:
            goto L_0x01f7
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.m100S(java.io.InputStream, java.io.OutputStream):void");
    }

    /* renamed from: U */
    private void m101U(C0036b bVar) {
        HashMap<String, C0038d> hashMap = this.f113f[4];
        C0038d dVar = hashMap.get("Compression");
        if (dVar != null) {
            int m = dVar.mo83m(this.f115h);
            this.f122o = m;
            if (m != 1) {
                if (m != 6) {
                    if (m != 7) {
                        return;
                    }
                }
            }
            if (m85C(hashMap)) {
                m123t(bVar, hashMap);
                return;
            }
            return;
        }
        this.f122o = 6;
        m122s(bVar, hashMap);
    }

    /* renamed from: V */
    private static boolean m102V(int i) {
        return (i == 4 || i == 9 || i == 13 || i == 14) ? false : true;
    }

    /* renamed from: W */
    private void m103W(int i, int i2) {
        String str;
        if (!this.f113f[i].isEmpty() && !this.f113f[i2].isEmpty()) {
            C0038d dVar = this.f113f[i].get("ImageLength");
            C0038d dVar2 = this.f113f[i].get("ImageWidth");
            C0038d dVar3 = this.f113f[i2].get("ImageLength");
            C0038d dVar4 = this.f113f[i2].get("ImageWidth");
            if (dVar == null || dVar2 == null) {
                if (f102v) {
                    str = "First image does not contain valid size information";
                } else {
                    return;
                }
            } else if (dVar3 != null && dVar4 != null) {
                int m = dVar.mo83m(this.f115h);
                int m2 = dVar2.mo83m(this.f115h);
                int m3 = dVar3.mo83m(this.f115h);
                int m4 = dVar4.mo83m(this.f115h);
                if (m < m3 && m2 < m4) {
                    HashMap<String, C0038d>[] hashMapArr = this.f113f;
                    HashMap<String, C0038d> hashMap = hashMapArr[i];
                    hashMapArr[i] = hashMapArr[i2];
                    hashMapArr[i2] = hashMap;
                    return;
                }
                return;
            } else if (f102v) {
                str = "Second image does not contain valid size information";
            } else {
                return;
            }
            Log.d("ExifInterface", str);
        } else if (f102v) {
            Log.d("ExifInterface", "Cannot perform swap since only one image data exists");
        }
    }

    /* renamed from: X */
    private void m104X(C0041g gVar, int i) {
        C0038d dVar;
        C0038d dVar2;
        StringBuilder sb;
        String arrays;
        C0038d dVar3 = this.f113f[i].get("DefaultCropSize");
        C0038d dVar4 = this.f113f[i].get("SensorTopBorder");
        C0038d dVar5 = this.f113f[i].get("SensorLeftBorder");
        C0038d dVar6 = this.f113f[i].get("SensorBottomBorder");
        C0038d dVar7 = this.f113f[i].get("SensorRightBorder");
        if (dVar3 != null) {
            if (dVar3.f140a == 5) {
                C0040f[] fVarArr = (C0040f[]) dVar3.mo85o(this.f115h);
                if (fVarArr == null || fVarArr.length != 2) {
                    sb = new StringBuilder();
                    sb.append("Invalid crop size values. cropSize=");
                    arrays = Arrays.toString(fVarArr);
                } else {
                    dVar2 = C0038d.m152h(fVarArr[0], this.f115h);
                    dVar = C0038d.m152h(fVarArr[1], this.f115h);
                    this.f113f[i].put("ImageWidth", dVar2);
                    this.f113f[i].put("ImageLength", dVar);
                    return;
                }
            } else {
                int[] iArr = (int[]) dVar3.mo85o(this.f115h);
                if (iArr == null || iArr.length != 2) {
                    sb = new StringBuilder();
                    sb.append("Invalid crop size values. cropSize=");
                    arrays = Arrays.toString(iArr);
                } else {
                    dVar2 = C0038d.m154j(iArr[0], this.f115h);
                    dVar = C0038d.m154j(iArr[1], this.f115h);
                    this.f113f[i].put("ImageWidth", dVar2);
                    this.f113f[i].put("ImageLength", dVar);
                    return;
                }
            }
            sb.append(arrays);
            Log.w("ExifInterface", sb.toString());
        } else if (dVar4 == null || dVar5 == null || dVar6 == null || dVar7 == null) {
            m97O(gVar, i);
        } else {
            int m = dVar4.mo83m(this.f115h);
            int m2 = dVar6.mo83m(this.f115h);
            int m3 = dVar7.mo83m(this.f115h);
            int m4 = dVar5.mo83m(this.f115h);
            if (m2 > m && m3 > m4) {
                C0038d j = C0038d.m154j(m2 - m, this.f115h);
                C0038d j2 = C0038d.m154j(m3 - m4, this.f115h);
                this.f113f[i].put("ImageLength", j);
                this.f113f[i].put("ImageWidth", j2);
            }
        }
    }

    /* renamed from: Y */
    private void m105Y() {
        m103W(0, 5);
        m103W(0, 4);
        m103W(5, 4);
        C0038d dVar = this.f113f[1].get("PixelXDimension");
        C0038d dVar2 = this.f113f[1].get("PixelYDimension");
        if (!(dVar == null || dVar2 == null)) {
            this.f113f[0].put("ImageWidth", dVar);
            this.f113f[0].put("ImageLength", dVar2);
        }
        if (this.f113f[4].isEmpty() && m87E(this.f113f[5])) {
            HashMap<String, C0038d>[] hashMapArr = this.f113f;
            hashMapArr[4] = hashMapArr[5];
            hashMapArr[5] = new HashMap<>();
        }
        if (!m87E(this.f113f[4])) {
            Log.d("ExifInterface", "No image meets the size requirements of a thumbnail image.");
        }
        m96N(0, "ThumbnailOrientation", "Orientation");
        m96N(0, "ThumbnailImageLength", "ImageLength");
        m96N(0, "ThumbnailImageWidth", "ImageWidth");
        m96N(5, "ThumbnailOrientation", "Orientation");
        m96N(5, "ThumbnailImageLength", "ImageLength");
        m96N(5, "ThumbnailImageWidth", "ImageWidth");
        m96N(4, "Orientation", "ThumbnailOrientation");
        m96N(4, "ImageLength", "ThumbnailImageLength");
        m96N(4, "ImageWidth", "ThumbnailImageWidth");
    }

    /* renamed from: Z */
    private int m106Z(C0037c cVar) {
        C0037c cVar2 = cVar;
        C0039e[][] eVarArr = f90j0;
        int[] iArr = new int[eVarArr.length];
        int[] iArr2 = new int[eVarArr.length];
        for (C0039e eVar : f91k0) {
            m95M(eVar.f145b);
        }
        if (this.f116i) {
            if (this.f117j) {
                m95M("StripOffsets");
                m95M("StripByteCounts");
            } else {
                m95M("JPEGInterchangeFormat");
                m95M("JPEGInterchangeFormatLength");
            }
        }
        for (int i = 0; i < f90j0.length; i++) {
            for (Object obj : this.f113f[i].entrySet().toArray()) {
                Map.Entry entry = (Map.Entry) obj;
                if (entry.getValue() == null) {
                    this.f113f[i].remove(entry.getKey());
                }
            }
        }
        if (!this.f113f[1].isEmpty()) {
            this.f113f[0].put(f91k0[1].f145b, C0038d.m150f(0, this.f115h));
        }
        if (!this.f113f[2].isEmpty()) {
            this.f113f[0].put(f91k0[2].f145b, C0038d.m150f(0, this.f115h));
        }
        if (!this.f113f[3].isEmpty()) {
            this.f113f[1].put(f91k0[3].f145b, C0038d.m150f(0, this.f115h));
        }
        if (this.f116i) {
            if (this.f117j) {
                this.f113f[4].put("StripOffsets", C0038d.m154j(0, this.f115h));
                this.f113f[4].put("StripByteCounts", C0038d.m154j(this.f120m, this.f115h));
            } else {
                this.f113f[4].put("JPEGInterchangeFormat", C0038d.m150f(0, this.f115h));
                this.f113f[4].put("JPEGInterchangeFormatLength", C0038d.m150f((long) this.f120m, this.f115h));
            }
        }
        for (int i2 = 0; i2 < f90j0.length; i2++) {
            int i3 = 0;
            for (Map.Entry<String, C0038d> value : this.f113f[i2].entrySet()) {
                int p = ((C0038d) value.getValue()).mo86p();
                if (p > 4) {
                    i3 += p;
                }
            }
            iArr2[i2] = iArr2[i2] + i3;
        }
        int i4 = 8;
        for (int i5 = 0; i5 < f90j0.length; i5++) {
            if (!this.f113f[i5].isEmpty()) {
                iArr[i5] = i4;
                i4 += (this.f113f[i5].size() * 12) + 2 + 4 + iArr2[i5];
            }
        }
        if (this.f116i) {
            if (this.f117j) {
                this.f113f[4].put("StripOffsets", C0038d.m154j(i4, this.f115h));
            } else {
                this.f113f[4].put("JPEGInterchangeFormat", C0038d.m150f((long) i4, this.f115h));
            }
            this.f119l = i4;
            i4 += this.f120m;
        }
        if (this.f111d == 4) {
            i4 += 8;
        }
        if (f102v) {
            for (int i6 = 0; i6 < f90j0.length; i6++) {
                Log.d("ExifInterface", String.format("index: %d, offsets: %d, tag count: %d, data sizes: %d, total size: %d", new Object[]{Integer.valueOf(i6), Integer.valueOf(iArr[i6]), Integer.valueOf(this.f113f[i6].size()), Integer.valueOf(iArr2[i6]), Integer.valueOf(i4)}));
            }
        }
        if (!this.f113f[1].isEmpty()) {
            this.f113f[0].put(f91k0[1].f145b, C0038d.m150f((long) iArr[1], this.f115h));
        }
        if (!this.f113f[2].isEmpty()) {
            this.f113f[0].put(f91k0[2].f145b, C0038d.m150f((long) iArr[2], this.f115h));
        }
        if (!this.f113f[3].isEmpty()) {
            this.f113f[1].put(f91k0[3].f145b, C0038d.m150f((long) iArr[3], this.f115h));
        }
        int i7 = this.f111d;
        if (i7 == 4) {
            cVar2.mo79f(i4);
            cVar2.write(f97q0);
        } else if (i7 == 13) {
            cVar2.mo76c(i4);
            cVar2.write(f63I);
        } else if (i7 == 14) {
            cVar2.write(f68N);
            cVar2.mo76c(i4);
        }
        cVar2.mo77d(this.f115h == ByteOrder.BIG_ENDIAN ? (short) 19789 : 18761);
        cVar2.mo74a(this.f115h);
        cVar2.mo79f(42);
        cVar2.mo78e(8);
        for (int i8 = 0; i8 < f90j0.length; i8++) {
            if (!this.f113f[i8].isEmpty()) {
                cVar2.mo79f(this.f113f[i8].size());
                int size = iArr[i8] + 2 + (this.f113f[i8].size() * 12) + 4;
                for (Map.Entry next : this.f113f[i8].entrySet()) {
                    int i9 = f93m0[i8].get(next.getKey()).f144a;
                    C0038d dVar = (C0038d) next.getValue();
                    int p2 = dVar.mo86p();
                    cVar2.mo79f(i9);
                    cVar2.mo79f(dVar.f140a);
                    cVar2.mo76c(dVar.f141b);
                    if (p2 > 4) {
                        cVar2.mo78e((long) size);
                        size += p2;
                    } else {
                        cVar2.write(dVar.f143d);
                        if (p2 < 4) {
                            while (p2 < 4) {
                                cVar2.mo75b(0);
                                p2++;
                            }
                        }
                    }
                }
                if (i8 != 0 || this.f113f[4].isEmpty()) {
                    cVar2.mo78e(0);
                } else {
                    cVar2.mo78e((long) iArr[4]);
                }
                for (Map.Entry<String, C0038d> value2 : this.f113f[i8].entrySet()) {
                    byte[] bArr = ((C0038d) value2.getValue()).f143d;
                    if (bArr.length > 4) {
                        cVar2.write(bArr, 0, bArr.length);
                    }
                }
            }
        }
        if (this.f116i) {
            cVar2.write(mo46p());
        }
        if (this.f111d == 14 && i4 % 2 == 1) {
            cVar2.mo75b(0);
        }
        cVar2.mo74a(ByteOrder.BIG_ENDIAN);
        return i4;
    }

    /* renamed from: a */
    private void m107a() {
        String d = mo44d("DateTimeOriginal");
        if (d != null && mo44d("DateTime") == null) {
            this.f113f[0].put("DateTime", C0038d.m149e(d));
        }
        if (mo44d("ImageWidth") == null) {
            this.f113f[0].put("ImageWidth", C0038d.m150f(0, this.f115h));
        }
        if (mo44d("ImageLength") == null) {
            this.f113f[0].put("ImageLength", C0038d.m150f(0, this.f115h));
        }
        if (mo44d("Orientation") == null) {
            this.f113f[0].put("Orientation", C0038d.m150f(0, this.f115h));
        }
        if (mo44d("LightSource") == null) {
            this.f113f[1].put("LightSource", C0038d.m150f(0, this.f115h));
        }
    }

    /* renamed from: b */
    private void m108b(C0036b bVar, C0037c cVar, byte[] bArr, byte[] bArr2) {
        String str;
        while (true) {
            byte[] bArr3 = new byte[4];
            if (bVar.read(bArr3) != 4) {
                StringBuilder sb = new StringBuilder();
                sb.append("Encountered invalid length while copying WebP chunks up tochunk type ");
                Charset charset = f96p0;
                sb.append(new String(bArr, charset));
                if (bArr2 == null) {
                    str = "";
                } else {
                    str = " or " + new String(bArr2, charset);
                }
                sb.append(str);
                throw new IOException(sb.toString());
            }
            m109c(bVar, cVar, bArr3);
            if (Arrays.equals(bArr3, bArr)) {
                return;
            }
            if (bArr2 != null && Arrays.equals(bArr3, bArr2)) {
                return;
            }
        }
    }

    /* renamed from: c */
    private void m109c(C0036b bVar, C0037c cVar, byte[] bArr) {
        int readInt = bVar.readInt();
        cVar.write(bArr);
        cVar.mo76c(readInt);
        if (readInt % 2 == 1) {
            readInt++;
        }
        C0042b.m169f(bVar, cVar, readInt);
    }

    /* renamed from: e */
    private C0038d m110e(String str) {
        if (str != null) {
            if ("ISOSpeedRatings".equals(str)) {
                if (f102v) {
                    Log.d("ExifInterface", "getExifAttribute: Replacing TAG_ISO_SPEED_RATINGS with TAG_PHOTOGRAPHIC_SENSITIVITY.");
                }
                str = "PhotographicSensitivity";
            }
            for (int i = 0; i < f90j0.length; i++) {
                C0038d dVar = this.f113f[i].get(str);
                if (dVar != null) {
                    return dVar;
                }
            }
            return null;
        }
        throw new NullPointerException("tag shouldn't be null");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0138, code lost:
        r13 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:56:0x0141, code lost:
        throw new java.lang.UnsupportedOperationException("Failed to read EXIF from HEIF file. Given stream is either malformed or unsupported.");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x0142, code lost:
        r1.release();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x0145, code lost:
        throw r13;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:54:0x013a */
    /* renamed from: f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m111f(androidx.exifinterface.media.C0034a.C0041g r13) {
        /*
            r12 = this;
            java.lang.String r0 = "yes"
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 28
            if (r1 < r2) goto L_0x0146
            android.media.MediaMetadataRetriever r1 = new android.media.MediaMetadataRetriever
            r1.<init>()
            androidx.exifinterface.media.a$a r2 = new androidx.exifinterface.media.a$a     // Catch:{ RuntimeException -> 0x013a }
            r2.<init>(r13)     // Catch:{ RuntimeException -> 0x013a }
            androidx.exifinterface.media.C0042b.C0044b.m174a(r1, r2)     // Catch:{ RuntimeException -> 0x013a }
            r2 = 33
            java.lang.String r2 = r1.extractMetadata(r2)     // Catch:{ RuntimeException -> 0x013a }
            r3 = 34
            java.lang.String r3 = r1.extractMetadata(r3)     // Catch:{ RuntimeException -> 0x013a }
            r4 = 26
            java.lang.String r4 = r1.extractMetadata(r4)     // Catch:{ RuntimeException -> 0x013a }
            r5 = 17
            java.lang.String r5 = r1.extractMetadata(r5)     // Catch:{ RuntimeException -> 0x013a }
            boolean r4 = r0.equals(r4)     // Catch:{ RuntimeException -> 0x013a }
            r6 = 0
            if (r4 == 0) goto L_0x0047
            r0 = 29
            java.lang.String r6 = r1.extractMetadata(r0)     // Catch:{ RuntimeException -> 0x013a }
            r0 = 30
            java.lang.String r0 = r1.extractMetadata(r0)     // Catch:{ RuntimeException -> 0x013a }
            r4 = 31
            java.lang.String r4 = r1.extractMetadata(r4)     // Catch:{ RuntimeException -> 0x013a }
            goto L_0x0062
        L_0x0047:
            boolean r0 = r0.equals(r5)     // Catch:{ RuntimeException -> 0x013a }
            if (r0 == 0) goto L_0x0060
            r0 = 18
            java.lang.String r6 = r1.extractMetadata(r0)     // Catch:{ RuntimeException -> 0x013a }
            r0 = 19
            java.lang.String r0 = r1.extractMetadata(r0)     // Catch:{ RuntimeException -> 0x013a }
            r4 = 24
            java.lang.String r4 = r1.extractMetadata(r4)     // Catch:{ RuntimeException -> 0x013a }
            goto L_0x0062
        L_0x0060:
            r0 = r6
            r4 = r0
        L_0x0062:
            r5 = 0
            if (r6 == 0) goto L_0x0078
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r7 = r12.f113f     // Catch:{ RuntimeException -> 0x013a }
            r7 = r7[r5]     // Catch:{ RuntimeException -> 0x013a }
            java.lang.String r8 = "ImageWidth"
            int r9 = java.lang.Integer.parseInt(r6)     // Catch:{ RuntimeException -> 0x013a }
            java.nio.ByteOrder r10 = r12.f115h     // Catch:{ RuntimeException -> 0x013a }
            androidx.exifinterface.media.a$d r9 = androidx.exifinterface.media.C0034a.C0038d.m154j(r9, r10)     // Catch:{ RuntimeException -> 0x013a }
            r7.put(r8, r9)     // Catch:{ RuntimeException -> 0x013a }
        L_0x0078:
            if (r0 == 0) goto L_0x008d
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r7 = r12.f113f     // Catch:{ RuntimeException -> 0x013a }
            r7 = r7[r5]     // Catch:{ RuntimeException -> 0x013a }
            java.lang.String r8 = "ImageLength"
            int r9 = java.lang.Integer.parseInt(r0)     // Catch:{ RuntimeException -> 0x013a }
            java.nio.ByteOrder r10 = r12.f115h     // Catch:{ RuntimeException -> 0x013a }
            androidx.exifinterface.media.a$d r9 = androidx.exifinterface.media.C0034a.C0038d.m154j(r9, r10)     // Catch:{ RuntimeException -> 0x013a }
            r7.put(r8, r9)     // Catch:{ RuntimeException -> 0x013a }
        L_0x008d:
            r7 = 6
            if (r4 == 0) goto L_0x00b7
            r8 = 1
            int r9 = java.lang.Integer.parseInt(r4)     // Catch:{ RuntimeException -> 0x013a }
            r10 = 90
            if (r9 == r10) goto L_0x00a7
            r10 = 180(0xb4, float:2.52E-43)
            if (r9 == r10) goto L_0x00a5
            r10 = 270(0x10e, float:3.78E-43)
            if (r9 == r10) goto L_0x00a2
            goto L_0x00a8
        L_0x00a2:
            r8 = 8
            goto L_0x00a8
        L_0x00a5:
            r8 = 3
            goto L_0x00a8
        L_0x00a7:
            r8 = 6
        L_0x00a8:
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r9 = r12.f113f     // Catch:{ RuntimeException -> 0x013a }
            r9 = r9[r5]     // Catch:{ RuntimeException -> 0x013a }
            java.lang.String r10 = "Orientation"
            java.nio.ByteOrder r11 = r12.f115h     // Catch:{ RuntimeException -> 0x013a }
            androidx.exifinterface.media.a$d r8 = androidx.exifinterface.media.C0034a.C0038d.m154j(r8, r11)     // Catch:{ RuntimeException -> 0x013a }
            r9.put(r10, r8)     // Catch:{ RuntimeException -> 0x013a }
        L_0x00b7:
            if (r2 == 0) goto L_0x010a
            if (r3 == 0) goto L_0x010a
            int r2 = java.lang.Integer.parseInt(r2)     // Catch:{ RuntimeException -> 0x013a }
            int r3 = java.lang.Integer.parseInt(r3)     // Catch:{ RuntimeException -> 0x013a }
            if (r3 <= r7) goto L_0x0102
            long r8 = (long) r2     // Catch:{ RuntimeException -> 0x013a }
            r13.mo91e(r8)     // Catch:{ RuntimeException -> 0x013a }
            byte[] r8 = new byte[r7]     // Catch:{ RuntimeException -> 0x013a }
            int r9 = r13.read(r8)     // Catch:{ RuntimeException -> 0x013a }
            if (r9 != r7) goto L_0x00fa
            int r2 = r2 + r7
            int r3 = r3 + -6
            byte[] r7 = f97q0     // Catch:{ RuntimeException -> 0x013a }
            boolean r7 = java.util.Arrays.equals(r8, r7)     // Catch:{ RuntimeException -> 0x013a }
            if (r7 == 0) goto L_0x00f2
            byte[] r7 = new byte[r3]     // Catch:{ RuntimeException -> 0x013a }
            int r13 = r13.read(r7)     // Catch:{ RuntimeException -> 0x013a }
            if (r13 != r3) goto L_0x00ea
            r12.f123p = r2     // Catch:{ RuntimeException -> 0x013a }
            r12.m93K(r7, r5)     // Catch:{ RuntimeException -> 0x013a }
            goto L_0x010a
        L_0x00ea:
            java.io.IOException r13 = new java.io.IOException     // Catch:{ RuntimeException -> 0x013a }
            java.lang.String r0 = "Can't read exif"
            r13.<init>(r0)     // Catch:{ RuntimeException -> 0x013a }
            throw r13     // Catch:{ RuntimeException -> 0x013a }
        L_0x00f2:
            java.io.IOException r13 = new java.io.IOException     // Catch:{ RuntimeException -> 0x013a }
            java.lang.String r0 = "Invalid identifier"
            r13.<init>(r0)     // Catch:{ RuntimeException -> 0x013a }
            throw r13     // Catch:{ RuntimeException -> 0x013a }
        L_0x00fa:
            java.io.IOException r13 = new java.io.IOException     // Catch:{ RuntimeException -> 0x013a }
            java.lang.String r0 = "Can't read identifier"
            r13.<init>(r0)     // Catch:{ RuntimeException -> 0x013a }
            throw r13     // Catch:{ RuntimeException -> 0x013a }
        L_0x0102:
            java.io.IOException r13 = new java.io.IOException     // Catch:{ RuntimeException -> 0x013a }
            java.lang.String r0 = "Invalid exif length"
            r13.<init>(r0)     // Catch:{ RuntimeException -> 0x013a }
            throw r13     // Catch:{ RuntimeException -> 0x013a }
        L_0x010a:
            boolean r13 = f102v     // Catch:{ RuntimeException -> 0x013a }
            if (r13 == 0) goto L_0x0134
            java.lang.String r13 = "ExifInterface"
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ RuntimeException -> 0x013a }
            r2.<init>()     // Catch:{ RuntimeException -> 0x013a }
            java.lang.String r3 = "Heif meta: "
            r2.append(r3)     // Catch:{ RuntimeException -> 0x013a }
            r2.append(r6)     // Catch:{ RuntimeException -> 0x013a }
            java.lang.String r3 = "x"
            r2.append(r3)     // Catch:{ RuntimeException -> 0x013a }
            r2.append(r0)     // Catch:{ RuntimeException -> 0x013a }
            java.lang.String r0 = ", rotation "
            r2.append(r0)     // Catch:{ RuntimeException -> 0x013a }
            r2.append(r4)     // Catch:{ RuntimeException -> 0x013a }
            java.lang.String r0 = r2.toString()     // Catch:{ RuntimeException -> 0x013a }
            android.util.Log.d(r13, r0)     // Catch:{ RuntimeException -> 0x013a }
        L_0x0134:
            r1.release()
            return
        L_0x0138:
            r13 = move-exception
            goto L_0x0142
        L_0x013a:
            java.lang.UnsupportedOperationException r13 = new java.lang.UnsupportedOperationException     // Catch:{ all -> 0x0138 }
            java.lang.String r0 = "Failed to read EXIF from HEIF file. Given stream is either malformed or unsupported."
            r13.<init>(r0)     // Catch:{ all -> 0x0138 }
            throw r13     // Catch:{ all -> 0x0138 }
        L_0x0142:
            r1.release()
            throw r13
        L_0x0146:
            java.lang.UnsupportedOperationException r13 = new java.lang.UnsupportedOperationException
            java.lang.String r0 = "Reading EXIF from HEIF files is supported from SDK 28 and above"
            r13.<init>(r0)
            throw r13
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.m111f(androidx.exifinterface.media.a$g):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:33:0x00c4  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00c7  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00dd  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00e0  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x0184 A[LOOP:0: B:8:0x0038->B:60:0x0184, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x018e A[SYNTHETIC] */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m112g(androidx.exifinterface.media.C0034a.C0036b r22, int r23, int r24) {
        /*
            r21 = this;
            r0 = r21
            r1 = r22
            r2 = r24
            boolean r3 = f102v
            java.lang.String r4 = "ExifInterface"
            if (r3 == 0) goto L_0x0020
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r5 = "getJpegAttributes starting with: "
            r3.append(r5)
            r3.append(r1)
            java.lang.String r3 = r3.toString()
            android.util.Log.d(r4, r3)
        L_0x0020:
            java.nio.ByteOrder r3 = java.nio.ByteOrder.BIG_ENDIAN
            r1.mo53c(r3)
            byte r3 = r22.readByte()
            java.lang.String r5 = "Invalid marker: "
            r6 = -1
            if (r3 != r6) goto L_0x01d8
            byte r7 = r22.readByte()
            r8 = -40
            if (r7 != r8) goto L_0x01bd
            r3 = 2
            r5 = 2
        L_0x0038:
            byte r7 = r22.readByte()
            if (r7 != r6) goto L_0x01a0
            r7 = 1
            int r5 = r5 + r7
            byte r8 = r22.readByte()
            boolean r9 = f102v
            if (r9 == 0) goto L_0x0062
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            java.lang.String r11 = "Found JPEG segment indicator: "
            r10.append(r11)
            r11 = r8 & 255(0xff, float:3.57E-43)
            java.lang.String r11 = java.lang.Integer.toHexString(r11)
            r10.append(r11)
            java.lang.String r10 = r10.toString()
            android.util.Log.d(r4, r10)
        L_0x0062:
            int r5 = r5 + r7
            r10 = -39
            if (r8 == r10) goto L_0x019a
            r10 = -38
            if (r8 != r10) goto L_0x006d
            goto L_0x019a
        L_0x006d:
            int r10 = r22.readUnsignedShort()
            int r10 = r10 - r3
            int r5 = r5 + r3
            if (r9 == 0) goto L_0x009e
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            java.lang.String r11 = "JPEG segment: "
            r9.append(r11)
            r11 = r8 & 255(0xff, float:3.57E-43)
            java.lang.String r11 = java.lang.Integer.toHexString(r11)
            r9.append(r11)
            java.lang.String r11 = " (length: "
            r9.append(r11)
            int r11 = r10 + 2
            r9.append(r11)
            java.lang.String r11 = ")"
            r9.append(r11)
            java.lang.String r9 = r9.toString()
            android.util.Log.d(r4, r9)
        L_0x009e:
            java.lang.String r9 = "Invalid length"
            if (r10 < 0) goto L_0x0194
            r11 = -31
            r12 = 0
            if (r8 == r11) goto L_0x0121
            r11 = -2
            if (r8 == r11) goto L_0x00f3
            switch(r8) {
                case -64: goto L_0x00ba;
                case -63: goto L_0x00ba;
                case -62: goto L_0x00ba;
                case -61: goto L_0x00ba;
                default: goto L_0x00ad;
            }
        L_0x00ad:
            switch(r8) {
                case -59: goto L_0x00ba;
                case -58: goto L_0x00ba;
                case -57: goto L_0x00ba;
                default: goto L_0x00b0;
            }
        L_0x00b0:
            switch(r8) {
                case -55: goto L_0x00ba;
                case -54: goto L_0x00ba;
                case -53: goto L_0x00ba;
                default: goto L_0x00b3;
            }
        L_0x00b3:
            switch(r8) {
                case -51: goto L_0x00ba;
                case -50: goto L_0x00ba;
                case -49: goto L_0x00ba;
                default: goto L_0x00b6;
            }
        L_0x00b6:
            r20 = r4
            goto L_0x0182
        L_0x00ba:
            r1.mo54d(r7)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r7 = r0.f113f
            r7 = r7[r2]
            r8 = 4
            if (r2 == r8) goto L_0x00c7
            java.lang.String r11 = "ImageLength"
            goto L_0x00c9
        L_0x00c7:
            java.lang.String r11 = "ThumbnailImageLength"
        L_0x00c9:
            int r12 = r22.readUnsignedShort()
            long r12 = (long) r12
            java.nio.ByteOrder r14 = r0.f115h
            androidx.exifinterface.media.a$d r12 = androidx.exifinterface.media.C0034a.C0038d.m150f(r12, r14)
            r7.put(r11, r12)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r7 = r0.f113f
            r7 = r7[r2]
            if (r2 == r8) goto L_0x00e0
            java.lang.String r8 = "ImageWidth"
            goto L_0x00e2
        L_0x00e0:
            java.lang.String r8 = "ThumbnailImageWidth"
        L_0x00e2:
            int r11 = r22.readUnsignedShort()
            long r11 = (long) r11
            java.nio.ByteOrder r13 = r0.f115h
            androidx.exifinterface.media.a$d r11 = androidx.exifinterface.media.C0034a.C0038d.m150f(r11, r13)
            r7.put(r8, r11)
            int r10 = r10 + -5
            goto L_0x00b6
        L_0x00f3:
            byte[] r8 = new byte[r10]
            int r11 = r1.read(r8)
            if (r11 != r10) goto L_0x0119
            java.lang.String r10 = "UserComment"
            java.lang.String r11 = r0.mo44d(r10)
            if (r11 != 0) goto L_0x0115
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r11 = r0.f113f
            r7 = r11[r7]
            java.lang.String r11 = new java.lang.String
            java.nio.charset.Charset r13 = f96p0
            r11.<init>(r8, r13)
            androidx.exifinterface.media.a$d r8 = androidx.exifinterface.media.C0034a.C0038d.m149e(r11)
            r7.put(r10, r8)
        L_0x0115:
            r20 = r4
            goto L_0x0181
        L_0x0119:
            java.io.IOException r1 = new java.io.IOException
            java.lang.String r2 = "Invalid exif"
            r1.<init>(r2)
            throw r1
        L_0x0121:
            byte[] r8 = new byte[r10]
            r1.readFully(r8)
            int r11 = r5 + r10
            byte[] r13 = f97q0
            boolean r14 = androidx.exifinterface.media.C0042b.m170g(r8, r13)
            if (r14 == 0) goto L_0x0147
            int r7 = r13.length
            byte[] r7 = java.util.Arrays.copyOfRange(r8, r7, r10)
            int r5 = r23 + r5
            int r8 = r13.length
            int r5 = r5 + r8
            r0.f123p = r5
            r0.m93K(r7, r2)
            androidx.exifinterface.media.a$b r5 = new androidx.exifinterface.media.a$b
            r5.<init>((byte[]) r7)
            r0.m101U(r5)
            goto L_0x017e
        L_0x0147:
            byte[] r13 = f98r0
            boolean r14 = androidx.exifinterface.media.C0042b.m170g(r8, r13)
            if (r14 == 0) goto L_0x017e
            int r14 = r13.length
            int r5 = r5 + r14
            int r13 = r13.length
            byte[] r8 = java.util.Arrays.copyOfRange(r8, r13, r10)
            java.lang.String r10 = "Xmp"
            java.lang.String r13 = r0.mo44d(r10)
            if (r13 != 0) goto L_0x017e
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r13 = r0.f113f
            r13 = r13[r12]
            androidx.exifinterface.media.a$d r15 = new androidx.exifinterface.media.a$d
            r16 = 1
            int r14 = r8.length
            r20 = r4
            long r3 = (long) r5
            r5 = r14
            r14 = r15
            r6 = r15
            r15 = r16
            r16 = r5
            r17 = r3
            r19 = r8
            r14.<init>(r15, r16, r17, r19)
            r13.put(r10, r6)
            r0.f128u = r7
            goto L_0x0180
        L_0x017e:
            r20 = r4
        L_0x0180:
            r5 = r11
        L_0x0181:
            r10 = 0
        L_0x0182:
            if (r10 < 0) goto L_0x018e
            r1.mo54d(r10)
            int r5 = r5 + r10
            r4 = r20
            r3 = 2
            r6 = -1
            goto L_0x0038
        L_0x018e:
            java.io.IOException r1 = new java.io.IOException
            r1.<init>(r9)
            throw r1
        L_0x0194:
            java.io.IOException r1 = new java.io.IOException
            r1.<init>(r9)
            throw r1
        L_0x019a:
            java.nio.ByteOrder r2 = r0.f115h
            r1.mo53c(r2)
            return
        L_0x01a0:
            java.io.IOException r1 = new java.io.IOException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "Invalid marker:"
            r2.append(r3)
            r3 = r7 & 255(0xff, float:3.57E-43)
            java.lang.String r3 = java.lang.Integer.toHexString(r3)
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x01bd:
            java.io.IOException r1 = new java.io.IOException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            r2.append(r5)
            r3 = r3 & 255(0xff, float:3.57E-43)
            java.lang.String r3 = java.lang.Integer.toHexString(r3)
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x01d8:
            java.io.IOException r1 = new java.io.IOException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            r2.append(r5)
            r3 = r3 & 255(0xff, float:3.57E-43)
            java.lang.String r3 = java.lang.Integer.toHexString(r3)
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            goto L_0x01f4
        L_0x01f3:
            throw r1
        L_0x01f4:
            goto L_0x01f3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.m112g(androidx.exifinterface.media.a$b, int, int):void");
    }

    /* renamed from: h */
    private int m113h(BufferedInputStream bufferedInputStream) {
        bufferedInputStream.mark(5000);
        byte[] bArr = new byte[5000];
        bufferedInputStream.read(bArr);
        bufferedInputStream.reset();
        if (m126w(bArr)) {
            return 4;
        }
        if (m129z(bArr)) {
            return 9;
        }
        if (m125v(bArr)) {
            return 12;
        }
        if (m127x(bArr)) {
            return 7;
        }
        if (m83A(bArr)) {
            return 10;
        }
        if (m128y(bArr)) {
            return 13;
        }
        return m88F(bArr) ? 14 : 0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x008c  */
    /* JADX WARNING: Removed duplicated region for block: B:30:? A[RETURN, SYNTHETIC] */
    /* renamed from: i */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m114i(androidx.exifinterface.media.C0034a.C0041g r7) {
        /*
            r6 = this;
            r6.m117l(r7)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r7 = r6.f113f
            r0 = 1
            r7 = r7[r0]
            java.lang.String r1 = "MakerNote"
            java.lang.Object r7 = r7.get(r1)
            androidx.exifinterface.media.a$d r7 = (androidx.exifinterface.media.C0034a.C0038d) r7
            if (r7 == 0) goto L_0x00f5
            androidx.exifinterface.media.a$g r1 = new androidx.exifinterface.media.a$g
            byte[] r7 = r7.f143d
            r1.<init>((byte[]) r7)
            java.nio.ByteOrder r7 = r6.f115h
            r1.mo53c(r7)
            byte[] r7 = f60F
            int r2 = r7.length
            byte[] r2 = new byte[r2]
            r1.readFully(r2)
            r3 = 0
            r1.mo91e(r3)
            byte[] r3 = f61G
            int r4 = r3.length
            byte[] r4 = new byte[r4]
            r1.readFully(r4)
            boolean r7 = java.util.Arrays.equals(r2, r7)
            if (r7 == 0) goto L_0x003f
            r2 = 8
        L_0x003b:
            r1.mo91e(r2)
            goto L_0x0048
        L_0x003f:
            boolean r7 = java.util.Arrays.equals(r4, r3)
            if (r7 == 0) goto L_0x0048
            r2 = 12
            goto L_0x003b
        L_0x0048:
            r7 = 6
            r6.m94L(r1, r7)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r7 = r6.f113f
            r1 = 7
            r7 = r7[r1]
            java.lang.String r2 = "PreviewImageStart"
            java.lang.Object r7 = r7.get(r2)
            androidx.exifinterface.media.a$d r7 = (androidx.exifinterface.media.C0034a.C0038d) r7
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r2 = r6.f113f
            r1 = r2[r1]
            java.lang.String r2 = "PreviewImageLength"
            java.lang.Object r1 = r1.get(r2)
            androidx.exifinterface.media.a$d r1 = (androidx.exifinterface.media.C0034a.C0038d) r1
            if (r7 == 0) goto L_0x007c
            if (r1 == 0) goto L_0x007c
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r2 = r6.f113f
            r3 = 5
            r2 = r2[r3]
            java.lang.String r4 = "JPEGInterchangeFormat"
            r2.put(r4, r7)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r7 = r6.f113f
            r7 = r7[r3]
            java.lang.String r2 = "JPEGInterchangeFormatLength"
            r7.put(r2, r1)
        L_0x007c:
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r7 = r6.f113f
            r1 = 8
            r7 = r7[r1]
            java.lang.String r1 = "AspectFrame"
            java.lang.Object r7 = r7.get(r1)
            androidx.exifinterface.media.a$d r7 = (androidx.exifinterface.media.C0034a.C0038d) r7
            if (r7 == 0) goto L_0x00f5
            java.nio.ByteOrder r1 = r6.f115h
            java.lang.Object r7 = r7.mo85o(r1)
            int[] r7 = (int[]) r7
            if (r7 == 0) goto L_0x00db
            int r1 = r7.length
            r2 = 4
            if (r1 == r2) goto L_0x009b
            goto L_0x00db
        L_0x009b:
            r1 = 2
            r2 = r7[r1]
            r3 = 0
            r4 = r7[r3]
            if (r2 <= r4) goto L_0x00f5
            r2 = 3
            r4 = r7[r2]
            r5 = r7[r0]
            if (r4 <= r5) goto L_0x00f5
            r1 = r7[r1]
            r4 = r7[r3]
            int r1 = r1 - r4
            int r1 = r1 + r0
            r2 = r7[r2]
            r7 = r7[r0]
            int r2 = r2 - r7
            int r2 = r2 + r0
            if (r1 >= r2) goto L_0x00bc
            int r1 = r1 + r2
            int r2 = r1 - r2
            int r1 = r1 - r2
        L_0x00bc:
            java.nio.ByteOrder r7 = r6.f115h
            androidx.exifinterface.media.a$d r7 = androidx.exifinterface.media.C0034a.C0038d.m154j(r1, r7)
            java.nio.ByteOrder r0 = r6.f115h
            androidx.exifinterface.media.a$d r0 = androidx.exifinterface.media.C0034a.C0038d.m154j(r2, r0)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r1 = r6.f113f
            r1 = r1[r3]
            java.lang.String r2 = "ImageWidth"
            r1.put(r2, r7)
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r7 = r6.f113f
            r7 = r7[r3]
            java.lang.String r1 = "ImageLength"
            r7.put(r1, r0)
            goto L_0x00f5
        L_0x00db:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "Invalid aspect frame values. frame="
            r0.append(r1)
            java.lang.String r7 = java.util.Arrays.toString(r7)
            r0.append(r7)
            java.lang.String r7 = r0.toString()
            java.lang.String r0 = "ExifInterface"
            android.util.Log.w(r0, r7)
        L_0x00f5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.m114i(androidx.exifinterface.media.a$g):void");
    }

    /* renamed from: j */
    private void m115j(C0036b bVar) {
        if (f102v) {
            Log.d("ExifInterface", "getPngAttributes starting with: " + bVar);
        }
        bVar.mo53c(ByteOrder.BIG_ENDIAN);
        byte[] bArr = f62H;
        bVar.mo54d(bArr.length);
        int length = bArr.length + 0;
        while (true) {
            try {
                int readInt = bVar.readInt();
                int i = length + 4;
                byte[] bArr2 = new byte[4];
                if (bVar.read(bArr2) == 4) {
                    int i2 = i + 4;
                    if (i2 == 16) {
                        if (!Arrays.equals(bArr2, f64J)) {
                            throw new IOException("Encountered invalid PNG file--IHDR chunk should appearas the first chunk");
                        }
                    }
                    if (!Arrays.equals(bArr2, f65K)) {
                        if (Arrays.equals(bArr2, f63I)) {
                            byte[] bArr3 = new byte[readInt];
                            if (bVar.read(bArr3) == readInt) {
                                int readInt2 = bVar.readInt();
                                CRC32 crc32 = new CRC32();
                                crc32.update(bArr2);
                                crc32.update(bArr3);
                                if (((int) crc32.getValue()) == readInt2) {
                                    this.f123p = i2;
                                    m93K(bArr3, 0);
                                    m105Y();
                                    m101U(new C0036b(bArr3));
                                    return;
                                }
                                throw new IOException("Encountered invalid CRC value for PNG-EXIF chunk.\n recorded CRC value: " + readInt2 + ", calculated CRC value: " + crc32.getValue());
                            }
                            throw new IOException("Failed to read given length for given PNG chunk type: " + C0042b.m164a(bArr2));
                        }
                        int i3 = readInt + 4;
                        bVar.mo54d(i3);
                        length = i2 + i3;
                    } else {
                        return;
                    }
                } else {
                    throw new IOException("Encountered invalid length while parsing PNG chunktype");
                }
            } catch (EOFException unused) {
                throw new IOException("Encountered corrupt PNG file.");
            }
        }
    }

    /* renamed from: k */
    private void m116k(C0036b bVar) {
        boolean z = f102v;
        if (z) {
            Log.d("ExifInterface", "getRafAttributes starting with: " + bVar);
        }
        bVar.mo54d(84);
        byte[] bArr = new byte[4];
        byte[] bArr2 = new byte[4];
        byte[] bArr3 = new byte[4];
        bVar.read(bArr);
        bVar.read(bArr2);
        bVar.read(bArr3);
        int i = ByteBuffer.wrap(bArr).getInt();
        int i2 = ByteBuffer.wrap(bArr2).getInt();
        int i3 = ByteBuffer.wrap(bArr3).getInt();
        byte[] bArr4 = new byte[i2];
        bVar.mo54d(i - bVar.mo50a());
        bVar.read(bArr4);
        m112g(new C0036b(bArr4), i, 5);
        bVar.mo54d(i3 - bVar.mo50a());
        bVar.mo53c(ByteOrder.BIG_ENDIAN);
        int readInt = bVar.readInt();
        if (z) {
            Log.d("ExifInterface", "numberOfDirectoryEntry: " + readInt);
        }
        for (int i4 = 0; i4 < readInt; i4++) {
            int readUnsignedShort = bVar.readUnsignedShort();
            int readUnsignedShort2 = bVar.readUnsignedShort();
            if (readUnsignedShort == f85e0.f144a) {
                short readShort = bVar.readShort();
                short readShort2 = bVar.readShort();
                C0038d j = C0038d.m154j(readShort, this.f115h);
                C0038d j2 = C0038d.m154j(readShort2, this.f115h);
                this.f113f[0].put("ImageLength", j);
                this.f113f[0].put("ImageWidth", j2);
                if (f102v) {
                    Log.d("ExifInterface", "Updated to length: " + readShort + ", width: " + readShort2);
                    return;
                }
                return;
            }
            bVar.mo54d(readUnsignedShort2);
        }
    }

    /* renamed from: l */
    private void m117l(C0041g gVar) {
        C0038d dVar;
        m90H(gVar);
        m94L(gVar, 0);
        m104X(gVar, 0);
        m104X(gVar, 5);
        m104X(gVar, 4);
        m105Y();
        if (this.f111d == 8 && (dVar = this.f113f[1].get("MakerNote")) != null) {
            C0041g gVar2 = new C0041g(dVar.f143d);
            gVar2.mo53c(this.f115h);
            gVar2.mo54d(6);
            m94L(gVar2, 9);
            C0038d dVar2 = this.f113f[9].get("ColorSpace");
            if (dVar2 != null) {
                this.f113f[1].put("ColorSpace", dVar2);
            }
        }
    }

    /* renamed from: m */
    private void m118m(C0041g gVar) {
        if (f102v) {
            Log.d("ExifInterface", "getRw2Attributes starting with: " + gVar);
        }
        m117l(gVar);
        C0038d dVar = this.f113f[0].get("JpgFromRaw");
        if (dVar != null) {
            m112g(new C0036b(dVar.f143d), (int) dVar.f142c, 5);
        }
        C0038d dVar2 = this.f113f[0].get("ISO");
        C0038d dVar3 = this.f113f[1].get("PhotographicSensitivity");
        if (dVar2 != null && dVar3 == null) {
            this.f113f[1].put("PhotographicSensitivity", dVar2);
        }
    }

    /* renamed from: n */
    private void m119n(C0041g gVar) {
        byte[] bArr = f97q0;
        gVar.mo54d(bArr.length);
        byte[] bArr2 = new byte[gVar.available()];
        gVar.readFully(bArr2);
        this.f123p = bArr.length;
        m93K(bArr2, 0);
    }

    /* renamed from: q */
    private void m120q(C0036b bVar) {
        if (f102v) {
            Log.d("ExifInterface", "getWebpAttributes starting with: " + bVar);
        }
        bVar.mo53c(ByteOrder.LITTLE_ENDIAN);
        bVar.mo54d(f66L.length);
        int readInt = bVar.readInt() + 8;
        byte[] bArr = f67M;
        bVar.mo54d(bArr.length);
        int length = bArr.length + 8;
        while (true) {
            try {
                byte[] bArr2 = new byte[4];
                if (bVar.read(bArr2) == 4) {
                    int readInt2 = bVar.readInt();
                    int i = length + 4 + 4;
                    if (Arrays.equals(f68N, bArr2)) {
                        byte[] bArr3 = new byte[readInt2];
                        if (bVar.read(bArr3) == readInt2) {
                            this.f123p = i;
                            m93K(bArr3, 0);
                            m101U(new C0036b(bArr3));
                            return;
                        }
                        throw new IOException("Failed to read given length for given PNG chunk type: " + C0042b.m164a(bArr2));
                    }
                    if (readInt2 % 2 == 1) {
                        readInt2++;
                    }
                    length = i + readInt2;
                    if (length != readInt) {
                        if (length <= readInt) {
                            bVar.mo54d(readInt2);
                        } else {
                            throw new IOException("Encountered WebP file with invalid chunk size");
                        }
                    } else {
                        return;
                    }
                } else {
                    throw new IOException("Encountered invalid length while parsing WebP chunktype");
                }
            } catch (EOFException unused) {
                throw new IOException("Encountered corrupt WebP file.");
            }
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:68|69|70) */
    /* JADX WARNING: Code restructure failed: missing block: B:69:?, code lost:
        java.lang.Double.parseDouble(r12);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x015c, code lost:
        return new android.util.Pair<>(12, -1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x0162, code lost:
        return new android.util.Pair<>(2, -1);
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:68:0x014e */
    /* renamed from: r */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static android.util.Pair<java.lang.Integer, java.lang.Integer> m121r(java.lang.String r12) {
        /*
            java.lang.String r0 = ","
            boolean r1 = r12.contains(r0)
            r2 = 0
            r3 = 1
            r4 = 2
            java.lang.Integer r5 = java.lang.Integer.valueOf(r4)
            r6 = -1
            java.lang.Integer r7 = java.lang.Integer.valueOf(r6)
            if (r1 == 0) goto L_0x00a6
            java.lang.String[] r12 = r12.split(r0, r6)
            r0 = r12[r2]
            android.util.Pair r0 = m121r(r0)
            java.lang.Object r1 = r0.first
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            if (r1 != r4) goto L_0x0029
            return r0
        L_0x0029:
            int r1 = r12.length
            if (r3 >= r1) goto L_0x00a5
            r1 = r12[r3]
            android.util.Pair r1 = m121r(r1)
            java.lang.Object r2 = r1.first
            java.lang.Integer r2 = (java.lang.Integer) r2
            java.lang.Object r4 = r0.first
            boolean r2 = r2.equals(r4)
            if (r2 != 0) goto L_0x004d
            java.lang.Object r2 = r1.second
            java.lang.Integer r2 = (java.lang.Integer) r2
            java.lang.Object r4 = r0.first
            boolean r2 = r2.equals(r4)
            if (r2 == 0) goto L_0x004b
            goto L_0x004d
        L_0x004b:
            r2 = -1
            goto L_0x0055
        L_0x004d:
            java.lang.Object r2 = r0.first
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
        L_0x0055:
            java.lang.Object r4 = r0.second
            java.lang.Integer r4 = (java.lang.Integer) r4
            int r4 = r4.intValue()
            if (r4 == r6) goto L_0x0080
            java.lang.Object r4 = r1.first
            java.lang.Integer r4 = (java.lang.Integer) r4
            java.lang.Object r8 = r0.second
            boolean r4 = r4.equals(r8)
            if (r4 != 0) goto L_0x0077
            java.lang.Object r1 = r1.second
            java.lang.Integer r1 = (java.lang.Integer) r1
            java.lang.Object r4 = r0.second
            boolean r1 = r1.equals(r4)
            if (r1 == 0) goto L_0x0080
        L_0x0077:
            java.lang.Object r1 = r0.second
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            goto L_0x0081
        L_0x0080:
            r1 = -1
        L_0x0081:
            if (r2 != r6) goto L_0x008b
            if (r1 != r6) goto L_0x008b
            android.util.Pair r12 = new android.util.Pair
            r12.<init>(r5, r7)
            return r12
        L_0x008b:
            if (r2 != r6) goto L_0x0097
            android.util.Pair r0 = new android.util.Pair
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r0.<init>(r1, r7)
            goto L_0x00a2
        L_0x0097:
            if (r1 != r6) goto L_0x00a2
            android.util.Pair r0 = new android.util.Pair
            java.lang.Integer r1 = java.lang.Integer.valueOf(r2)
            r0.<init>(r1, r7)
        L_0x00a2:
            int r3 = r3 + 1
            goto L_0x0029
        L_0x00a5:
            return r0
        L_0x00a6:
            java.lang.String r0 = "/"
            boolean r1 = r12.contains(r0)
            r8 = 0
            if (r1 == 0) goto L_0x0105
            java.lang.String[] r12 = r12.split(r0, r6)
            int r0 = r12.length
            if (r0 != r4) goto L_0x00ff
            r0 = r12[r2]     // Catch:{ NumberFormatException -> 0x00ff }
            double r0 = java.lang.Double.parseDouble(r0)     // Catch:{ NumberFormatException -> 0x00ff }
            long r0 = (long) r0     // Catch:{ NumberFormatException -> 0x00ff }
            r12 = r12[r3]     // Catch:{ NumberFormatException -> 0x00ff }
            double r2 = java.lang.Double.parseDouble(r12)     // Catch:{ NumberFormatException -> 0x00ff }
            long r2 = (long) r2     // Catch:{ NumberFormatException -> 0x00ff }
            r12 = 10
            int r4 = (r0 > r8 ? 1 : (r0 == r8 ? 0 : -1))
            if (r4 < 0) goto L_0x00f5
            int r4 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1))
            if (r4 >= 0) goto L_0x00d0
            goto L_0x00f5
        L_0x00d0:
            r4 = 5
            r8 = 2147483647(0x7fffffff, double:1.060997895E-314)
            int r6 = (r0 > r8 ? 1 : (r0 == r8 ? 0 : -1))
            if (r6 > 0) goto L_0x00eb
            int r0 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1))
            if (r0 <= 0) goto L_0x00dd
            goto L_0x00eb
        L_0x00dd:
            android.util.Pair r0 = new android.util.Pair     // Catch:{ NumberFormatException -> 0x00ff }
            java.lang.Integer r12 = java.lang.Integer.valueOf(r12)     // Catch:{ NumberFormatException -> 0x00ff }
            java.lang.Integer r1 = java.lang.Integer.valueOf(r4)     // Catch:{ NumberFormatException -> 0x00ff }
            r0.<init>(r12, r1)     // Catch:{ NumberFormatException -> 0x00ff }
            return r0
        L_0x00eb:
            android.util.Pair r12 = new android.util.Pair     // Catch:{ NumberFormatException -> 0x00ff }
            java.lang.Integer r0 = java.lang.Integer.valueOf(r4)     // Catch:{ NumberFormatException -> 0x00ff }
            r12.<init>(r0, r7)     // Catch:{ NumberFormatException -> 0x00ff }
            return r12
        L_0x00f5:
            android.util.Pair r0 = new android.util.Pair     // Catch:{ NumberFormatException -> 0x00ff }
            java.lang.Integer r12 = java.lang.Integer.valueOf(r12)     // Catch:{ NumberFormatException -> 0x00ff }
            r0.<init>(r12, r7)     // Catch:{ NumberFormatException -> 0x00ff }
            return r0
        L_0x00ff:
            android.util.Pair r12 = new android.util.Pair
            r12.<init>(r5, r7)
            return r12
        L_0x0105:
            long r0 = java.lang.Long.parseLong(r12)     // Catch:{ NumberFormatException -> 0x014e }
            java.lang.Long r0 = java.lang.Long.valueOf(r0)     // Catch:{ NumberFormatException -> 0x014e }
            long r1 = r0.longValue()     // Catch:{ NumberFormatException -> 0x014e }
            r3 = 4
            int r4 = (r1 > r8 ? 1 : (r1 == r8 ? 0 : -1))
            if (r4 < 0) goto L_0x0130
            long r1 = r0.longValue()     // Catch:{ NumberFormatException -> 0x014e }
            r10 = 65535(0xffff, double:3.23786E-319)
            int r4 = (r1 > r10 ? 1 : (r1 == r10 ? 0 : -1))
            if (r4 > 0) goto L_0x0130
            android.util.Pair r0 = new android.util.Pair     // Catch:{ NumberFormatException -> 0x014e }
            r1 = 3
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch:{ NumberFormatException -> 0x014e }
            java.lang.Integer r2 = java.lang.Integer.valueOf(r3)     // Catch:{ NumberFormatException -> 0x014e }
            r0.<init>(r1, r2)     // Catch:{ NumberFormatException -> 0x014e }
            return r0
        L_0x0130:
            long r0 = r0.longValue()     // Catch:{ NumberFormatException -> 0x014e }
            int r2 = (r0 > r8 ? 1 : (r0 == r8 ? 0 : -1))
            if (r2 >= 0) goto L_0x0144
            android.util.Pair r0 = new android.util.Pair     // Catch:{ NumberFormatException -> 0x014e }
            r1 = 9
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch:{ NumberFormatException -> 0x014e }
            r0.<init>(r1, r7)     // Catch:{ NumberFormatException -> 0x014e }
            return r0
        L_0x0144:
            android.util.Pair r0 = new android.util.Pair     // Catch:{ NumberFormatException -> 0x014e }
            java.lang.Integer r1 = java.lang.Integer.valueOf(r3)     // Catch:{ NumberFormatException -> 0x014e }
            r0.<init>(r1, r7)     // Catch:{ NumberFormatException -> 0x014e }
            return r0
        L_0x014e:
            java.lang.Double.parseDouble(r12)     // Catch:{ NumberFormatException -> 0x015d }
            android.util.Pair r12 = new android.util.Pair     // Catch:{ NumberFormatException -> 0x015d }
            r0 = 12
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)     // Catch:{ NumberFormatException -> 0x015d }
            r12.<init>(r0, r7)     // Catch:{ NumberFormatException -> 0x015d }
            return r12
        L_0x015d:
            android.util.Pair r12 = new android.util.Pair
            r12.<init>(r5, r7)
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.m121r(java.lang.String):android.util.Pair");
    }

    /* renamed from: s */
    private void m122s(C0036b bVar, HashMap hashMap) {
        C0038d dVar = (C0038d) hashMap.get("JPEGInterchangeFormat");
        C0038d dVar2 = (C0038d) hashMap.get("JPEGInterchangeFormatLength");
        if (dVar != null && dVar2 != null) {
            int m = dVar.mo83m(this.f115h);
            int m2 = dVar2.mo83m(this.f115h);
            if (this.f111d == 7) {
                m += this.f124q;
            }
            if (m > 0 && m2 > 0) {
                this.f116i = true;
                if (this.f108a == null && this.f110c == null && this.f109b == null) {
                    byte[] bArr = new byte[m2];
                    bVar.skip((long) m);
                    bVar.read(bArr);
                    this.f121n = bArr;
                }
                this.f119l = m;
                this.f120m = m2;
            }
            if (f102v) {
                Log.d("ExifInterface", "Setting thumbnail attributes with offset: " + m + ", length: " + m2);
            }
        }
    }

    /* renamed from: t */
    private void m123t(C0036b bVar, HashMap hashMap) {
        C0036b bVar2 = bVar;
        HashMap hashMap2 = hashMap;
        C0038d dVar = (C0038d) hashMap2.get("StripOffsets");
        C0038d dVar2 = (C0038d) hashMap2.get("StripByteCounts");
        if (dVar != null && dVar2 != null) {
            long[] d = C0042b.m167d(dVar.mo85o(this.f115h));
            long[] d2 = C0042b.m167d(dVar2.mo85o(this.f115h));
            if (d == null || d.length == 0) {
                Log.w("ExifInterface", "stripOffsets should not be null or have zero length.");
            } else if (d2 == null || d2.length == 0) {
                Log.w("ExifInterface", "stripByteCounts should not be null or have zero length.");
            } else if (d.length != d2.length) {
                Log.w("ExifInterface", "stripOffsets and stripByteCounts should have same length.");
            } else {
                long j = 0;
                for (long j2 : d2) {
                    j += j2;
                }
                int i = (int) j;
                byte[] bArr = new byte[i];
                int i2 = 1;
                this.f118k = true;
                this.f117j = true;
                this.f116i = true;
                int i3 = 0;
                int i4 = 0;
                int i5 = 0;
                while (i3 < d.length) {
                    int i6 = (int) d[i3];
                    int i7 = (int) d2[i3];
                    if (i3 < d.length - i2 && ((long) (i6 + i7)) != d[i3 + 1]) {
                        this.f118k = false;
                    }
                    int i8 = i6 - i4;
                    if (i8 < 0) {
                        Log.d("ExifInterface", "Invalid strip offset value");
                        return;
                    }
                    long j3 = (long) i8;
                    if (bVar2.skip(j3) != j3) {
                        Log.d("ExifInterface", "Failed to skip " + i8 + " bytes.");
                        return;
                    }
                    int i9 = i4 + i8;
                    byte[] bArr2 = new byte[i7];
                    if (bVar2.read(bArr2) != i7) {
                        Log.d("ExifInterface", "Failed to read " + i7 + " bytes.");
                        return;
                    }
                    i4 = i9 + i7;
                    System.arraycopy(bArr2, 0, bArr, i5, i7);
                    i5 += i7;
                    i3++;
                    i2 = 1;
                }
                this.f121n = bArr;
                if (this.f118k) {
                    this.f119l = (int) d[0];
                    this.f120m = i;
                }
            }
        }
    }

    /* renamed from: u */
    private void m124u(String str) {
        if (str != null) {
            FileInputStream fileInputStream = null;
            this.f110c = null;
            this.f108a = str;
            try {
                FileInputStream fileInputStream2 = new FileInputStream(str);
                try {
                    if (m84B(fileInputStream2.getFD())) {
                        this.f109b = fileInputStream2.getFD();
                    } else {
                        this.f109b = null;
                    }
                    m89G(fileInputStream2);
                    C0042b.m166c(fileInputStream2);
                } catch (Throwable th) {
                    th = th;
                    fileInputStream = fileInputStream2;
                    C0042b.m166c(fileInputStream);
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                C0042b.m166c(fileInputStream);
                throw th;
            }
        } else {
            throw new NullPointerException("filename cannot be null");
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:58:0x0092 A[Catch:{ all -> 0x008b }] */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x009b  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x00a1  */
    /* renamed from: v */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m125v(byte[] r15) {
        /*
            r14 = this;
            r0 = 0
            r1 = 0
            androidx.exifinterface.media.a$b r2 = new androidx.exifinterface.media.a$b     // Catch:{ Exception -> 0x008d }
            r2.<init>((byte[]) r15)     // Catch:{ Exception -> 0x008d }
            int r1 = r2.readInt()     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            long r3 = (long) r1     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            r1 = 4
            byte[] r5 = new byte[r1]     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            r2.read(r5)     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            byte[] r6 = f57C     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            boolean r5 = java.util.Arrays.equals(r5, r6)     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            if (r5 != 0) goto L_0x001e
            r2.close()
            return r0
        L_0x001e:
            r5 = 16
            r7 = 8
            r9 = 1
            int r11 = (r3 > r9 ? 1 : (r3 == r9 ? 0 : -1))
            if (r11 != 0) goto L_0x0034
            long r3 = r2.readLong()     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            int r11 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r11 >= 0) goto L_0x0035
            r2.close()
            return r0
        L_0x0034:
            r5 = r7
        L_0x0035:
            int r11 = r15.length     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            long r11 = (long) r11     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            int r13 = (r3 > r11 ? 1 : (r3 == r11 ? 0 : -1))
            if (r13 <= 0) goto L_0x003d
            int r15 = r15.length     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            long r3 = (long) r15
        L_0x003d:
            long r3 = r3 - r5
            int r15 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1))
            if (r15 >= 0) goto L_0x0046
            r2.close()
            return r0
        L_0x0046:
            byte[] r15 = new byte[r1]     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            r5 = 0
            r7 = 0
            r8 = 0
        L_0x004c:
            r11 = 4
            long r11 = r3 / r11
            int r13 = (r5 > r11 ? 1 : (r5 == r11 ? 0 : -1))
            if (r13 >= 0) goto L_0x0081
            int r11 = r2.read(r15)     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            if (r11 == r1) goto L_0x005e
            r2.close()
            return r0
        L_0x005e:
            int r11 = (r5 > r9 ? 1 : (r5 == r9 ? 0 : -1))
            if (r11 != 0) goto L_0x0063
            goto L_0x007f
        L_0x0063:
            byte[] r11 = f58D     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            boolean r11 = java.util.Arrays.equals(r15, r11)     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            r12 = 1
            if (r11 == 0) goto L_0x006e
            r7 = 1
            goto L_0x0077
        L_0x006e:
            byte[] r11 = f59E     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            boolean r11 = java.util.Arrays.equals(r15, r11)     // Catch:{ Exception -> 0x0088, all -> 0x0085 }
            if (r11 == 0) goto L_0x0077
            r8 = 1
        L_0x0077:
            if (r7 == 0) goto L_0x007f
            if (r8 == 0) goto L_0x007f
            r2.close()
            return r12
        L_0x007f:
            long r5 = r5 + r9
            goto L_0x004c
        L_0x0081:
            r2.close()
            goto L_0x009e
        L_0x0085:
            r15 = move-exception
            r1 = r2
            goto L_0x009f
        L_0x0088:
            r15 = move-exception
            r1 = r2
            goto L_0x008e
        L_0x008b:
            r15 = move-exception
            goto L_0x009f
        L_0x008d:
            r15 = move-exception
        L_0x008e:
            boolean r2 = f102v     // Catch:{ all -> 0x008b }
            if (r2 == 0) goto L_0x0099
            java.lang.String r2 = "ExifInterface"
            java.lang.String r3 = "Exception parsing HEIF file type box."
            android.util.Log.d(r2, r3, r15)     // Catch:{ all -> 0x008b }
        L_0x0099:
            if (r1 == 0) goto L_0x009e
            r1.close()
        L_0x009e:
            return r0
        L_0x009f:
            if (r1 == 0) goto L_0x00a4
            r1.close()
        L_0x00a4:
            goto L_0x00a6
        L_0x00a5:
            throw r15
        L_0x00a6:
            goto L_0x00a5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.m125v(byte[]):boolean");
    }

    /* renamed from: w */
    private static boolean m126w(byte[] bArr) {
        int i = 0;
        while (true) {
            byte[] bArr2 = f56B;
            if (i >= bArr2.length) {
                return true;
            }
            if (bArr[i] != bArr2[i]) {
                return false;
            }
            i++;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0029  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0030  */
    /* renamed from: x */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m127x(byte[] r4) {
        /*
            r3 = this;
            r0 = 0
            r1 = 0
            androidx.exifinterface.media.a$b r2 = new androidx.exifinterface.media.a$b     // Catch:{ Exception -> 0x002d, all -> 0x0026 }
            r2.<init>((byte[]) r4)     // Catch:{ Exception -> 0x002d, all -> 0x0026 }
            java.nio.ByteOrder r4 = r3.m92J(r2)     // Catch:{ Exception -> 0x0024, all -> 0x0021 }
            r3.f115h = r4     // Catch:{ Exception -> 0x0024, all -> 0x0021 }
            r2.mo53c(r4)     // Catch:{ Exception -> 0x0024, all -> 0x0021 }
            short r4 = r2.readShort()     // Catch:{ Exception -> 0x0024, all -> 0x0021 }
            r1 = 20306(0x4f52, float:2.8455E-41)
            if (r4 == r1) goto L_0x001c
            r1 = 21330(0x5352, float:2.989E-41)
            if (r4 != r1) goto L_0x001d
        L_0x001c:
            r0 = 1
        L_0x001d:
            r2.close()
            return r0
        L_0x0021:
            r4 = move-exception
            r1 = r2
            goto L_0x0027
        L_0x0024:
            r1 = r2
            goto L_0x002e
        L_0x0026:
            r4 = move-exception
        L_0x0027:
            if (r1 == 0) goto L_0x002c
            r1.close()
        L_0x002c:
            throw r4
        L_0x002d:
        L_0x002e:
            if (r1 == 0) goto L_0x0033
            r1.close()
        L_0x0033:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.m127x(byte[]):boolean");
    }

    /* renamed from: y */
    private boolean m128y(byte[] bArr) {
        int i = 0;
        while (true) {
            byte[] bArr2 = f62H;
            if (i >= bArr2.length) {
                return true;
            }
            if (bArr[i] != bArr2[i]) {
                return false;
            }
            i++;
        }
    }

    /* renamed from: z */
    private boolean m129z(byte[] bArr) {
        byte[] bytes = "FUJIFILMCCD-RAW".getBytes(Charset.defaultCharset());
        for (int i = 0; i < bytes.length; i++) {
            if (bArr[i] != bytes[i]) {
                return false;
            }
        }
        return true;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:107:0x0168, code lost:
        r2.delete();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x00e5, code lost:
        r9 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x00e6, code lost:
        r10 = null;
        r1 = r7;
        r7 = r9;
        r9 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:68:0x00eb, code lost:
        r8 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x00ec, code lost:
        r9 = null;
        r10 = null;
        r1 = r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x00f0, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x00f1, code lost:
        r10 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x0104, code lost:
        if (android.os.Build.VERSION.SDK_INT >= 21) goto L_0x0106;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:82:0x0106, code lost:
        androidx.exifinterface.media.C0042b.C0043a.m173c(r14.f109b, 0, android.system.OsConstants.SEEK_SET);
        r1 = new java.io.FileOutputStream(r14.f109b);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x0115, code lost:
        r1 = new java.io.FileOutputStream(r14.f108a);
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:107:0x0168  */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x00f0 A[ExcHandler: all (th java.lang.Throwable), Splitter:B:30:0x0073] */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x0102 A[Catch:{ Exception -> 0x0131, all -> 0x012e }] */
    /* JADX WARNING: Removed duplicated region for block: B:83:0x0115 A[Catch:{ Exception -> 0x0131, all -> 0x012e }] */
    /* renamed from: P */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo42P() {
        /*
            r14 = this;
            int r0 = r14.f111d
            boolean r0 = m86D(r0)
            if (r0 == 0) goto L_0x018d
            java.io.FileDescriptor r0 = r14.f109b
            if (r0 != 0) goto L_0x0019
            java.lang.String r0 = r14.f108a
            if (r0 == 0) goto L_0x0011
            goto L_0x0019
        L_0x0011:
            java.io.IOException r0 = new java.io.IOException
            java.lang.String r1 = "ExifInterface does not support saving attributes for the current input."
            r0.<init>(r1)
            throw r0
        L_0x0019:
            boolean r0 = r14.f116i
            if (r0 == 0) goto L_0x002e
            boolean r0 = r14.f117j
            if (r0 == 0) goto L_0x002e
            boolean r0 = r14.f118k
            if (r0 == 0) goto L_0x0026
            goto L_0x002e
        L_0x0026:
            java.io.IOException r0 = new java.io.IOException
            java.lang.String r1 = "ExifInterface does not support saving attributes when the image file has non-consecutive thumbnail strips"
            r0.<init>(r1)
            throw r0
        L_0x002e:
            r0 = 1
            r14.f127t = r0
            byte[] r1 = r14.mo45o()
            r14.f121n = r1
            r1 = 0
            java.lang.String r2 = "temp"
            java.lang.String r3 = "tmp"
            java.io.File r2 = java.io.File.createTempFile(r2, r3)     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            java.lang.String r3 = r14.f108a     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            r4 = 0
            r6 = 21
            if (r3 == 0) goto L_0x0050
            java.io.FileInputStream r3 = new java.io.FileInputStream     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            java.lang.String r7 = r14.f108a     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            r3.<init>(r7)     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            goto L_0x0064
        L_0x0050:
            int r3 = android.os.Build.VERSION.SDK_INT     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            if (r3 < r6) goto L_0x0063
            java.io.FileDescriptor r3 = r14.f109b     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            int r7 = android.system.OsConstants.SEEK_SET     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            androidx.exifinterface.media.C0042b.C0043a.m173c(r3, r4, r7)     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            java.io.FileInputStream r3 = new java.io.FileInputStream     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            java.io.FileDescriptor r7 = r14.f109b     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            r3.<init>(r7)     // Catch:{ Exception -> 0x017b, all -> 0x0178 }
            goto L_0x0064
        L_0x0063:
            r3 = r1
        L_0x0064:
            java.io.FileOutputStream r7 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x0174, all -> 0x0170 }
            r7.<init>(r2)     // Catch:{ Exception -> 0x0174, all -> 0x0170 }
            androidx.exifinterface.media.C0042b.m168e(r3, r7)     // Catch:{ Exception -> 0x016e, all -> 0x016c }
            androidx.exifinterface.media.C0042b.m166c(r3)
            androidx.exifinterface.media.C0042b.m166c(r7)
            r3 = 0
            java.io.FileInputStream r7 = new java.io.FileInputStream     // Catch:{ Exception -> 0x00f4, all -> 0x00f0 }
            r7.<init>(r2)     // Catch:{ Exception -> 0x00f4, all -> 0x00f0 }
            java.lang.String r8 = r14.f108a     // Catch:{ Exception -> 0x00eb, all -> 0x00f0 }
            if (r8 == 0) goto L_0x0084
            java.io.FileOutputStream r8 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x00eb, all -> 0x00f0 }
            java.lang.String r9 = r14.f108a     // Catch:{ Exception -> 0x00eb, all -> 0x00f0 }
            r8.<init>(r9)     // Catch:{ Exception -> 0x00eb, all -> 0x00f0 }
            goto L_0x0098
        L_0x0084:
            int r8 = android.os.Build.VERSION.SDK_INT     // Catch:{ Exception -> 0x00eb, all -> 0x00f0 }
            if (r8 < r6) goto L_0x0097
            java.io.FileDescriptor r8 = r14.f109b     // Catch:{ Exception -> 0x00eb, all -> 0x00f0 }
            int r9 = android.system.OsConstants.SEEK_SET     // Catch:{ Exception -> 0x00eb, all -> 0x00f0 }
            androidx.exifinterface.media.C0042b.C0043a.m173c(r8, r4, r9)     // Catch:{ Exception -> 0x00eb, all -> 0x00f0 }
            java.io.FileOutputStream r8 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x00eb, all -> 0x00f0 }
            java.io.FileDescriptor r9 = r14.f109b     // Catch:{ Exception -> 0x00eb, all -> 0x00f0 }
            r8.<init>(r9)     // Catch:{ Exception -> 0x00eb, all -> 0x00f0 }
            goto L_0x0098
        L_0x0097:
            r8 = r1
        L_0x0098:
            java.io.BufferedInputStream r9 = new java.io.BufferedInputStream     // Catch:{ Exception -> 0x00e5, all -> 0x00f0 }
            r9.<init>(r7)     // Catch:{ Exception -> 0x00e5, all -> 0x00f0 }
            java.io.BufferedOutputStream r10 = new java.io.BufferedOutputStream     // Catch:{ Exception -> 0x00df, all -> 0x00db }
            r10.<init>(r8)     // Catch:{ Exception -> 0x00df, all -> 0x00db }
            int r11 = r14.f111d     // Catch:{ Exception -> 0x00d6 }
            r12 = 4
            if (r11 != r12) goto L_0x00ab
            r14.m98Q(r9, r10)     // Catch:{ Exception -> 0x00d6 }
            goto L_0x00ca
        L_0x00ab:
            r12 = 13
            if (r11 != r12) goto L_0x00b3
            r14.m99R(r9, r10)     // Catch:{ Exception -> 0x00d6 }
            goto L_0x00ca
        L_0x00b3:
            r12 = 14
            if (r11 != r12) goto L_0x00bb
            r14.m100S(r9, r10)     // Catch:{ Exception -> 0x00d6 }
            goto L_0x00ca
        L_0x00bb:
            r12 = 3
            if (r11 == r12) goto L_0x00c0
            if (r11 != 0) goto L_0x00ca
        L_0x00c0:
            androidx.exifinterface.media.a$c r11 = new androidx.exifinterface.media.a$c     // Catch:{ Exception -> 0x00d6 }
            java.nio.ByteOrder r12 = java.nio.ByteOrder.BIG_ENDIAN     // Catch:{ Exception -> 0x00d6 }
            r11.<init>(r10, r12)     // Catch:{ Exception -> 0x00d6 }
            r14.m106Z(r11)     // Catch:{ Exception -> 0x00d6 }
        L_0x00ca:
            androidx.exifinterface.media.C0042b.m166c(r9)
            androidx.exifinterface.media.C0042b.m166c(r10)
            r2.delete()
            r14.f121n = r1
            return
        L_0x00d6:
            r1 = move-exception
            r13 = r7
            r7 = r1
            r1 = r13
            goto L_0x00f9
        L_0x00db:
            r0 = move-exception
            r10 = r1
            goto L_0x015f
        L_0x00df:
            r10 = move-exception
            r13 = r10
            r10 = r1
            r1 = r7
            r7 = r13
            goto L_0x00f9
        L_0x00e5:
            r9 = move-exception
            r10 = r1
            r1 = r7
            r7 = r9
            r9 = r10
            goto L_0x00f9
        L_0x00eb:
            r8 = move-exception
            r9 = r1
            r10 = r9
            r1 = r7
            goto L_0x00f7
        L_0x00f0:
            r0 = move-exception
            r10 = r1
            goto L_0x0160
        L_0x00f4:
            r8 = move-exception
            r9 = r1
            r10 = r9
        L_0x00f7:
            r7 = r8
            r8 = r10
        L_0x00f9:
            java.io.FileInputStream r11 = new java.io.FileInputStream     // Catch:{ Exception -> 0x0135, all -> 0x0133 }
            r11.<init>(r2)     // Catch:{ Exception -> 0x0135, all -> 0x0133 }
            java.lang.String r1 = r14.f108a     // Catch:{ Exception -> 0x0131, all -> 0x012e }
            if (r1 != 0) goto L_0x0115
            int r1 = android.os.Build.VERSION.SDK_INT     // Catch:{ Exception -> 0x0131, all -> 0x012e }
            if (r1 < r6) goto L_0x011d
            java.io.FileDescriptor r1 = r14.f109b     // Catch:{ Exception -> 0x0131, all -> 0x012e }
            int r6 = android.system.OsConstants.SEEK_SET     // Catch:{ Exception -> 0x0131, all -> 0x012e }
            androidx.exifinterface.media.C0042b.C0043a.m173c(r1, r4, r6)     // Catch:{ Exception -> 0x0131, all -> 0x012e }
            java.io.FileOutputStream r1 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x0131, all -> 0x012e }
            java.io.FileDescriptor r4 = r14.f109b     // Catch:{ Exception -> 0x0131, all -> 0x012e }
            r1.<init>(r4)     // Catch:{ Exception -> 0x0131, all -> 0x012e }
            goto L_0x011c
        L_0x0115:
            java.io.FileOutputStream r1 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x0131, all -> 0x012e }
            java.lang.String r4 = r14.f108a     // Catch:{ Exception -> 0x0131, all -> 0x012e }
            r1.<init>(r4)     // Catch:{ Exception -> 0x0131, all -> 0x012e }
        L_0x011c:
            r8 = r1
        L_0x011d:
            androidx.exifinterface.media.C0042b.m168e(r11, r8)     // Catch:{ Exception -> 0x0131, all -> 0x012e }
            androidx.exifinterface.media.C0042b.m166c(r11)     // Catch:{ all -> 0x015e }
            androidx.exifinterface.media.C0042b.m166c(r8)     // Catch:{ all -> 0x015e }
            java.io.IOException r0 = new java.io.IOException     // Catch:{ all -> 0x015e }
            java.lang.String r1 = "Failed to save new file"
            r0.<init>(r1, r7)     // Catch:{ all -> 0x015e }
            throw r0     // Catch:{ all -> 0x015e }
        L_0x012e:
            r0 = move-exception
            r1 = r11
            goto L_0x0157
        L_0x0131:
            r1 = move-exception
            goto L_0x0138
        L_0x0133:
            r0 = move-exception
            goto L_0x0157
        L_0x0135:
            r3 = move-exception
            r11 = r1
            r1 = r3
        L_0x0138:
            java.io.IOException r3 = new java.io.IOException     // Catch:{ all -> 0x0153 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0153 }
            r4.<init>()     // Catch:{ all -> 0x0153 }
            java.lang.String r5 = "Failed to save new file. Original file is stored in "
            r4.append(r5)     // Catch:{ all -> 0x0153 }
            java.lang.String r5 = r2.getAbsolutePath()     // Catch:{ all -> 0x0153 }
            r4.append(r5)     // Catch:{ all -> 0x0153 }
            java.lang.String r4 = r4.toString()     // Catch:{ all -> 0x0153 }
            r3.<init>(r4, r1)     // Catch:{ all -> 0x0153 }
            throw r3     // Catch:{ all -> 0x0153 }
        L_0x0153:
            r1 = move-exception
            r0 = r1
            r1 = r11
            r3 = 1
        L_0x0157:
            androidx.exifinterface.media.C0042b.m166c(r1)     // Catch:{ all -> 0x015e }
            androidx.exifinterface.media.C0042b.m166c(r8)     // Catch:{ all -> 0x015e }
            throw r0     // Catch:{ all -> 0x015e }
        L_0x015e:
            r0 = move-exception
        L_0x015f:
            r1 = r9
        L_0x0160:
            androidx.exifinterface.media.C0042b.m166c(r1)
            androidx.exifinterface.media.C0042b.m166c(r10)
            if (r3 != 0) goto L_0x016b
            r2.delete()
        L_0x016b:
            throw r0
        L_0x016c:
            r0 = move-exception
            goto L_0x0172
        L_0x016e:
            r0 = move-exception
            goto L_0x0176
        L_0x0170:
            r0 = move-exception
            r7 = r1
        L_0x0172:
            r1 = r3
            goto L_0x0186
        L_0x0174:
            r0 = move-exception
            r7 = r1
        L_0x0176:
            r1 = r3
            goto L_0x017d
        L_0x0178:
            r0 = move-exception
            r7 = r1
            goto L_0x0186
        L_0x017b:
            r0 = move-exception
            r7 = r1
        L_0x017d:
            java.io.IOException r2 = new java.io.IOException     // Catch:{ all -> 0x0185 }
            java.lang.String r3 = "Failed to copy original file to temp file"
            r2.<init>(r3, r0)     // Catch:{ all -> 0x0185 }
            throw r2     // Catch:{ all -> 0x0185 }
        L_0x0185:
            r0 = move-exception
        L_0x0186:
            androidx.exifinterface.media.C0042b.m166c(r1)
            androidx.exifinterface.media.C0042b.m166c(r7)
            throw r0
        L_0x018d:
            java.io.IOException r0 = new java.io.IOException
            java.lang.String r1 = "ExifInterface only supports saving attributes for JPEG, PNG, WebP, and DNG formats."
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.mo42P():void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:115:0x0325, code lost:
        r3.put(r1, r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:97:0x028f, code lost:
        r3.put(r1, r4);
     */
    /* renamed from: T */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo43T(java.lang.String r18, java.lang.String r19) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            r2 = r19
            if (r1 == 0) goto L_0x0332
            java.lang.String r3 = "DateTime"
            boolean r3 = r3.equals(r1)
            java.lang.String r4 = " : "
            java.lang.String r5 = "Invalid value for "
            java.lang.String r6 = "ExifInterface"
            if (r3 != 0) goto L_0x0026
            java.lang.String r3 = "DateTimeOriginal"
            boolean r3 = r3.equals(r1)
            if (r3 != 0) goto L_0x0026
            java.lang.String r3 = "DateTimeDigitized"
            boolean r3 = r3.equals(r1)
            if (r3 == 0) goto L_0x006d
        L_0x0026:
            if (r2 == 0) goto L_0x006d
            java.util.regex.Pattern r3 = f101u0
            java.util.regex.Matcher r3 = r3.matcher(r2)
            boolean r3 = r3.find()
            java.util.regex.Pattern r7 = f103v0
            java.util.regex.Matcher r7 = r7.matcher(r2)
            boolean r7 = r7.find()
            int r8 = r19.length()
            r9 = 19
            if (r8 != r9) goto L_0x0054
            if (r3 != 0) goto L_0x0049
            if (r7 != 0) goto L_0x0049
            goto L_0x0054
        L_0x0049:
            if (r7 == 0) goto L_0x006d
            java.lang.String r3 = "-"
            java.lang.String r7 = ":"
            java.lang.String r2 = r2.replaceAll(r3, r7)
            goto L_0x006d
        L_0x0054:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
        L_0x0059:
            r3.append(r5)
            r3.append(r1)
            r3.append(r4)
            r3.append(r2)
            java.lang.String r1 = r3.toString()
            android.util.Log.w(r6, r1)
            return
        L_0x006d:
            java.lang.String r3 = "ISOSpeedRatings"
            boolean r3 = r3.equals(r1)
            if (r3 == 0) goto L_0x0080
            boolean r1 = f102v
            if (r1 == 0) goto L_0x007e
            java.lang.String r1 = "setAttribute: Replacing TAG_ISO_SPEED_RATINGS with TAG_PHOTOGRAPHIC_SENSITIVITY."
            android.util.Log.d(r6, r1)
        L_0x007e:
            java.lang.String r1 = "PhotographicSensitivity"
        L_0x0080:
            r3 = 2
            r7 = 1
            if (r2 == 0) goto L_0x00f4
            java.util.HashSet<java.lang.String> r8 = f94n0
            boolean r8 = r8.contains(r1)
            if (r8 == 0) goto L_0x00f4
            java.lang.String r8 = "GPSTimeStamp"
            boolean r8 = r1.equals(r8)
            if (r8 == 0) goto L_0x00df
            java.util.regex.Pattern r8 = f100t0
            java.util.regex.Matcher r8 = r8.matcher(r2)
            boolean r9 = r8.find()
            if (r9 != 0) goto L_0x00a6
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            goto L_0x0059
        L_0x00a6:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r4 = r8.group(r7)
            int r4 = java.lang.Integer.parseInt(r4)
            r2.append(r4)
            java.lang.String r4 = "/1,"
            r2.append(r4)
            java.lang.String r5 = r8.group(r3)
            int r5 = java.lang.Integer.parseInt(r5)
            r2.append(r5)
            r2.append(r4)
            r4 = 3
            java.lang.String r4 = r8.group(r4)
            int r4 = java.lang.Integer.parseInt(r4)
            r2.append(r4)
            java.lang.String r4 = "/1"
            r2.append(r4)
            java.lang.String r2 = r2.toString()
            goto L_0x00f4
        L_0x00df:
            double r8 = java.lang.Double.parseDouble(r2)     // Catch:{ NumberFormatException -> 0x00ed }
            androidx.exifinterface.media.a$f r10 = new androidx.exifinterface.media.a$f     // Catch:{ NumberFormatException -> 0x00ed }
            r10.<init>(r8)     // Catch:{ NumberFormatException -> 0x00ed }
            java.lang.String r2 = r10.toString()     // Catch:{ NumberFormatException -> 0x00ed }
            goto L_0x00f4
        L_0x00ed:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            goto L_0x0059
        L_0x00f4:
            r4 = 0
            r5 = 0
        L_0x00f6:
            androidx.exifinterface.media.a$e[][] r8 = f90j0
            int r8 = r8.length
            if (r5 >= r8) goto L_0x0331
            r8 = 4
            if (r5 != r8) goto L_0x0104
            boolean r8 = r0.f116i
            if (r8 != 0) goto L_0x0104
            goto L_0x0329
        L_0x0104:
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$e>[] r8 = f93m0
            r8 = r8[r5]
            java.lang.Object r8 = r8.get(r1)
            androidx.exifinterface.media.a$e r8 = (androidx.exifinterface.media.C0034a.C0039e) r8
            if (r8 == 0) goto L_0x0329
            if (r2 != 0) goto L_0x011b
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r8 = r0.f113f
            r8 = r8[r5]
            r8.remove(r1)
            goto L_0x0329
        L_0x011b:
            android.util.Pair r9 = m121r(r2)
            int r10 = r8.f146c
            java.lang.Object r11 = r9.first
            java.lang.Integer r11 = (java.lang.Integer) r11
            int r11 = r11.intValue()
            r12 = -1
            if (r10 == r11) goto L_0x01eb
            int r10 = r8.f146c
            java.lang.Object r11 = r9.second
            java.lang.Integer r11 = (java.lang.Integer) r11
            int r11 = r11.intValue()
            if (r10 != r11) goto L_0x013a
            goto L_0x01eb
        L_0x013a:
            int r10 = r8.f147d
            if (r10 == r12) goto L_0x0158
            java.lang.Object r11 = r9.first
            java.lang.Integer r11 = (java.lang.Integer) r11
            int r11 = r11.intValue()
            if (r10 == r11) goto L_0x0154
            int r10 = r8.f147d
            java.lang.Object r11 = r9.second
            java.lang.Integer r11 = (java.lang.Integer) r11
            int r11 = r11.intValue()
            if (r10 != r11) goto L_0x0158
        L_0x0154:
            int r8 = r8.f147d
            goto L_0x01ed
        L_0x0158:
            int r10 = r8.f146c
            if (r10 == r7) goto L_0x01e9
            r11 = 7
            if (r10 == r11) goto L_0x01e9
            if (r10 != r3) goto L_0x0163
            goto L_0x01e9
        L_0x0163:
            boolean r10 = f102v
            if (r10 == 0) goto L_0x0329
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            java.lang.String r11 = "Given tag ("
            r10.append(r11)
            r10.append(r1)
            java.lang.String r11 = ") value didn't match with one of expected formats: "
            r10.append(r11)
            java.lang.String[] r11 = f77W
            int r13 = r8.f146c
            r13 = r11[r13]
            r10.append(r13)
            int r13 = r8.f147d
            java.lang.String r14 = ""
            java.lang.String r15 = ", "
            if (r13 != r12) goto L_0x018c
            r8 = r14
            goto L_0x019f
        L_0x018c:
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            r13.<init>()
            r13.append(r15)
            int r8 = r8.f147d
            r8 = r11[r8]
            r13.append(r8)
            java.lang.String r8 = r13.toString()
        L_0x019f:
            r10.append(r8)
            java.lang.String r8 = " (guess: "
            r10.append(r8)
            java.lang.Object r8 = r9.first
            java.lang.Integer r8 = (java.lang.Integer) r8
            int r8 = r8.intValue()
            r8 = r11[r8]
            r10.append(r8)
            java.lang.Object r8 = r9.second
            java.lang.Integer r8 = (java.lang.Integer) r8
            int r8 = r8.intValue()
            if (r8 != r12) goto L_0x01bf
            goto L_0x01d8
        L_0x01bf:
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            r8.append(r15)
            java.lang.Object r9 = r9.second
            java.lang.Integer r9 = (java.lang.Integer) r9
            int r9 = r9.intValue()
            r9 = r11[r9]
            r8.append(r9)
            java.lang.String r14 = r8.toString()
        L_0x01d8:
            r10.append(r14)
            java.lang.String r8 = ")"
            r10.append(r8)
            java.lang.String r8 = r10.toString()
            android.util.Log.d(r6, r8)
            goto L_0x0329
        L_0x01e9:
            r8 = r10
            goto L_0x01ed
        L_0x01eb:
            int r8 = r8.f146c
        L_0x01ed:
            java.lang.String r9 = "/"
            java.lang.String r10 = ","
            switch(r8) {
                case 1: goto L_0x031c;
                case 2: goto L_0x0312;
                case 3: goto L_0x02ef;
                case 4: goto L_0x02cc;
                case 5: goto L_0x0294;
                case 6: goto L_0x01f4;
                case 7: goto L_0x0312;
                case 8: goto L_0x01f4;
                case 9: goto L_0x026f;
                case 10: goto L_0x0234;
                case 11: goto L_0x01f4;
                case 12: goto L_0x020f;
                default: goto L_0x01f4;
            }
        L_0x01f4:
            r15 = 1
            boolean r3 = f102v
            if (r3 == 0) goto L_0x032a
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "Data format isn't one of expected formats: "
            r3.append(r4)
            r3.append(r8)
            java.lang.String r3 = r3.toString()
            android.util.Log.d(r6, r3)
            goto L_0x032a
        L_0x020f:
            java.lang.String[] r8 = r2.split(r10, r12)
            int r9 = r8.length
            double[] r9 = new double[r9]
            r10 = 0
        L_0x0217:
            int r11 = r8.length
            if (r10 >= r11) goto L_0x0225
            r11 = r8[r10]
            double r11 = java.lang.Double.parseDouble(r11)
            r9[r10] = r11
            int r10 = r10 + 1
            goto L_0x0217
        L_0x0225:
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r8 = r0.f113f
            r8 = r8[r5]
            java.nio.ByteOrder r10 = r0.f115h
            androidx.exifinterface.media.a$d r9 = androidx.exifinterface.media.C0034a.C0038d.m146b(r9, r10)
            r8.put(r1, r9)
            goto L_0x0329
        L_0x0234:
            java.lang.String[] r8 = r2.split(r10, r12)
            int r10 = r8.length
            androidx.exifinterface.media.a$f[] r10 = new androidx.exifinterface.media.C0034a.C0040f[r10]
            r11 = 0
        L_0x023c:
            int r13 = r8.length
            if (r11 >= r13) goto L_0x0264
            r13 = r8[r11]
            java.lang.String[] r13 = r13.split(r9, r12)
            androidx.exifinterface.media.a$f r14 = new androidx.exifinterface.media.a$f
            r15 = r13[r4]
            double r3 = java.lang.Double.parseDouble(r15)
            long r3 = (long) r3
            r13 = r13[r7]
            r16 = r8
            double r7 = java.lang.Double.parseDouble(r13)
            long r7 = (long) r7
            r14.<init>(r3, r7)
            r10[r11] = r14
            int r11 = r11 + 1
            r8 = r16
            r3 = 2
            r4 = 0
            r7 = 1
            goto L_0x023c
        L_0x0264:
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r3 = r0.f113f
            r3 = r3[r5]
            java.nio.ByteOrder r4 = r0.f115h
            androidx.exifinterface.media.a$d r4 = androidx.exifinterface.media.C0034a.C0038d.m148d(r10, r4)
            goto L_0x028f
        L_0x026f:
            java.lang.String[] r3 = r2.split(r10, r12)
            int r4 = r3.length
            int[] r4 = new int[r4]
            r7 = 0
        L_0x0277:
            int r8 = r3.length
            if (r7 >= r8) goto L_0x0285
            r8 = r3[r7]
            int r8 = java.lang.Integer.parseInt(r8)
            r4[r7] = r8
            int r7 = r7 + 1
            goto L_0x0277
        L_0x0285:
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r3 = r0.f113f
            r3 = r3[r5]
            java.nio.ByteOrder r7 = r0.f115h
            androidx.exifinterface.media.a$d r4 = androidx.exifinterface.media.C0034a.C0038d.m147c(r4, r7)
        L_0x028f:
            r3.put(r1, r4)
            goto L_0x0329
        L_0x0294:
            java.lang.String[] r3 = r2.split(r10, r12)
            int r4 = r3.length
            androidx.exifinterface.media.a$f[] r4 = new androidx.exifinterface.media.C0034a.C0040f[r4]
            r7 = 0
        L_0x029c:
            int r8 = r3.length
            if (r7 >= r8) goto L_0x02c0
            r8 = r3[r7]
            java.lang.String[] r8 = r8.split(r9, r12)
            androidx.exifinterface.media.a$f r10 = new androidx.exifinterface.media.a$f
            r11 = 0
            r13 = r8[r11]
            double r13 = java.lang.Double.parseDouble(r13)
            long r13 = (long) r13
            r15 = 1
            r8 = r8[r15]
            double r11 = java.lang.Double.parseDouble(r8)
            long r11 = (long) r11
            r10.<init>(r13, r11)
            r4[r7] = r10
            int r7 = r7 + 1
            r12 = -1
            goto L_0x029c
        L_0x02c0:
            r15 = 1
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r3 = r0.f113f
            r3 = r3[r5]
            java.nio.ByteOrder r7 = r0.f115h
            androidx.exifinterface.media.a$d r4 = androidx.exifinterface.media.C0034a.C0038d.m153i(r4, r7)
            goto L_0x0325
        L_0x02cc:
            r3 = -1
            r15 = 1
            java.lang.String[] r3 = r2.split(r10, r3)
            int r4 = r3.length
            long[] r4 = new long[r4]
            r7 = 0
        L_0x02d6:
            int r8 = r3.length
            if (r7 >= r8) goto L_0x02e4
            r8 = r3[r7]
            long r8 = java.lang.Long.parseLong(r8)
            r4[r7] = r8
            int r7 = r7 + 1
            goto L_0x02d6
        L_0x02e4:
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r3 = r0.f113f
            r3 = r3[r5]
            java.nio.ByteOrder r7 = r0.f115h
            androidx.exifinterface.media.a$d r4 = androidx.exifinterface.media.C0034a.C0038d.m151g(r4, r7)
            goto L_0x0325
        L_0x02ef:
            r3 = -1
            r15 = 1
            java.lang.String[] r3 = r2.split(r10, r3)
            int r4 = r3.length
            int[] r4 = new int[r4]
            r7 = 0
        L_0x02f9:
            int r8 = r3.length
            if (r7 >= r8) goto L_0x0307
            r8 = r3[r7]
            int r8 = java.lang.Integer.parseInt(r8)
            r4[r7] = r8
            int r7 = r7 + 1
            goto L_0x02f9
        L_0x0307:
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r3 = r0.f113f
            r3 = r3[r5]
            java.nio.ByteOrder r7 = r0.f115h
            androidx.exifinterface.media.a$d r4 = androidx.exifinterface.media.C0034a.C0038d.m155k(r4, r7)
            goto L_0x0325
        L_0x0312:
            r15 = 1
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r3 = r0.f113f
            r3 = r3[r5]
            androidx.exifinterface.media.a$d r4 = androidx.exifinterface.media.C0034a.C0038d.m149e(r2)
            goto L_0x0325
        L_0x031c:
            r15 = 1
            java.util.HashMap<java.lang.String, androidx.exifinterface.media.a$d>[] r3 = r0.f113f
            r3 = r3[r5]
            androidx.exifinterface.media.a$d r4 = androidx.exifinterface.media.C0034a.C0038d.m145a(r2)
        L_0x0325:
            r3.put(r1, r4)
            goto L_0x032a
        L_0x0329:
            r15 = 1
        L_0x032a:
            int r5 = r5 + 1
            r3 = 2
            r4 = 0
            r7 = 1
            goto L_0x00f6
        L_0x0331:
            return
        L_0x0332:
            java.lang.NullPointerException r1 = new java.lang.NullPointerException
            java.lang.String r2 = "tag shouldn't be null"
            r1.<init>(r2)
            goto L_0x033b
        L_0x033a:
            throw r1
        L_0x033b:
            goto L_0x033a
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.mo43T(java.lang.String, java.lang.String):void");
    }

    /* renamed from: d */
    public String mo44d(String str) {
        String str2;
        if (str != null) {
            C0038d e = m110e(str);
            if (e != null) {
                if (!f94n0.contains(str)) {
                    return e.mo84n(this.f115h);
                }
                if (str.equals("GPSTimeStamp")) {
                    int i = e.f140a;
                    if (i == 5 || i == 10) {
                        C0040f[] fVarArr = (C0040f[]) e.mo85o(this.f115h);
                        if (fVarArr == null || fVarArr.length != 3) {
                            str2 = "Invalid GPS Timestamp array. array=" + Arrays.toString(fVarArr);
                        } else {
                            return String.format("%02d:%02d:%02d", new Object[]{Integer.valueOf((int) (((float) fVarArr[0].f148a) / ((float) fVarArr[0].f149b))), Integer.valueOf((int) (((float) fVarArr[1].f148a) / ((float) fVarArr[1].f149b))), Integer.valueOf((int) (((float) fVarArr[2].f148a) / ((float) fVarArr[2].f149b)))});
                        }
                    } else {
                        str2 = "GPS Timestamp format is not rational. format=" + e.f140a;
                    }
                    Log.w("ExifInterface", str2);
                    return null;
                }
                try {
                    return Double.toString(e.mo82l(this.f115h));
                } catch (NumberFormatException unused) {
                }
            }
            return null;
        }
        throw new NullPointerException("tag shouldn't be null");
    }

    /* renamed from: o */
    public byte[] mo45o() {
        int i = this.f122o;
        if (i == 6 || i == 7) {
            return mo46p();
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:38:0x0063 A[SYNTHETIC, Splitter:B:38:0x0063] */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x009e A[Catch:{ Exception -> 0x009c }] */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x00b5  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x00c0  */
    /* renamed from: p */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public byte[] mo46p() {
        /*
            r11 = this;
            java.lang.String r0 = "ExifInterface"
            boolean r1 = r11.f116i
            r2 = 0
            if (r1 != 0) goto L_0x0008
            return r2
        L_0x0008:
            byte[] r1 = r11.f121n
            if (r1 == 0) goto L_0x000d
            return r1
        L_0x000d:
            android.content.res.AssetManager$AssetInputStream r1 = r11.f110c     // Catch:{ Exception -> 0x00a7, all -> 0x00a4 }
            if (r1 == 0) goto L_0x002e
            boolean r3 = r1.markSupported()     // Catch:{ Exception -> 0x0029, all -> 0x0025 }
            if (r3 == 0) goto L_0x001c
            r1.reset()     // Catch:{ Exception -> 0x0029, all -> 0x0025 }
        L_0x001a:
            r3 = r2
            goto L_0x0061
        L_0x001c:
            java.lang.String r3 = "Cannot read thumbnail from inputstream without mark/reset support"
            android.util.Log.d(r0, r3)     // Catch:{ Exception -> 0x0029, all -> 0x0025 }
            androidx.exifinterface.media.C0042b.m166c(r1)
            return r2
        L_0x0025:
            r0 = move-exception
            r3 = r2
            goto L_0x00ba
        L_0x0029:
            r3 = move-exception
            r4 = r3
            r3 = r2
            goto L_0x00ab
        L_0x002e:
            java.lang.String r1 = r11.f108a     // Catch:{ Exception -> 0x00a7, all -> 0x00a4 }
            if (r1 == 0) goto L_0x003a
            java.io.FileInputStream r1 = new java.io.FileInputStream     // Catch:{ Exception -> 0x00a7, all -> 0x00a4 }
            java.lang.String r3 = r11.f108a     // Catch:{ Exception -> 0x00a7, all -> 0x00a4 }
            r1.<init>(r3)     // Catch:{ Exception -> 0x00a7, all -> 0x00a4 }
            goto L_0x001a
        L_0x003a:
            int r1 = android.os.Build.VERSION.SDK_INT     // Catch:{ Exception -> 0x00a7, all -> 0x00a4 }
            r3 = 21
            if (r1 < r3) goto L_0x005f
            java.io.FileDescriptor r1 = r11.f109b     // Catch:{ Exception -> 0x00a7, all -> 0x00a4 }
            java.io.FileDescriptor r1 = androidx.exifinterface.media.C0042b.C0043a.m172b(r1)     // Catch:{ Exception -> 0x00a7, all -> 0x00a4 }
            r3 = 0
            int r5 = android.system.OsConstants.SEEK_SET     // Catch:{ Exception -> 0x005a, all -> 0x0056 }
            androidx.exifinterface.media.C0042b.C0043a.m173c(r1, r3, r5)     // Catch:{ Exception -> 0x005a, all -> 0x0056 }
            java.io.FileInputStream r3 = new java.io.FileInputStream     // Catch:{ Exception -> 0x005a, all -> 0x0056 }
            r3.<init>(r1)     // Catch:{ Exception -> 0x005a, all -> 0x0056 }
            r10 = r3
            r3 = r1
            r1 = r10
            goto L_0x0061
        L_0x0056:
            r0 = move-exception
            r3 = r1
            goto L_0x00bb
        L_0x005a:
            r3 = move-exception
            r4 = r3
            r3 = r1
            r1 = r2
            goto L_0x00ab
        L_0x005f:
            r1 = r2
            r3 = r1
        L_0x0061:
            if (r1 == 0) goto L_0x009e
            int r4 = r11.f119l     // Catch:{ Exception -> 0x009c }
            int r5 = r11.f123p     // Catch:{ Exception -> 0x009c }
            int r4 = r4 + r5
            long r4 = (long) r4     // Catch:{ Exception -> 0x009c }
            long r4 = r1.skip(r4)     // Catch:{ Exception -> 0x009c }
            int r6 = r11.f119l     // Catch:{ Exception -> 0x009c }
            int r7 = r11.f123p     // Catch:{ Exception -> 0x009c }
            int r6 = r6 + r7
            long r6 = (long) r6
            java.lang.String r8 = "Corrupted image"
            int r9 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r9 != 0) goto L_0x0096
            int r4 = r11.f120m     // Catch:{ Exception -> 0x009c }
            byte[] r4 = new byte[r4]     // Catch:{ Exception -> 0x009c }
            int r5 = r1.read(r4)     // Catch:{ Exception -> 0x009c }
            int r6 = r11.f120m     // Catch:{ Exception -> 0x009c }
            if (r5 != r6) goto L_0x0090
            r11.f121n = r4     // Catch:{ Exception -> 0x009c }
            androidx.exifinterface.media.C0042b.m166c(r1)
            if (r3 == 0) goto L_0x008f
            androidx.exifinterface.media.C0042b.m165b(r3)
        L_0x008f:
            return r4
        L_0x0090:
            java.io.IOException r4 = new java.io.IOException     // Catch:{ Exception -> 0x009c }
            r4.<init>(r8)     // Catch:{ Exception -> 0x009c }
            throw r4     // Catch:{ Exception -> 0x009c }
        L_0x0096:
            java.io.IOException r4 = new java.io.IOException     // Catch:{ Exception -> 0x009c }
            r4.<init>(r8)     // Catch:{ Exception -> 0x009c }
            throw r4     // Catch:{ Exception -> 0x009c }
        L_0x009c:
            r4 = move-exception
            goto L_0x00ab
        L_0x009e:
            java.io.FileNotFoundException r4 = new java.io.FileNotFoundException     // Catch:{ Exception -> 0x009c }
            r4.<init>()     // Catch:{ Exception -> 0x009c }
            throw r4     // Catch:{ Exception -> 0x009c }
        L_0x00a4:
            r0 = move-exception
            r3 = r2
            goto L_0x00bb
        L_0x00a7:
            r3 = move-exception
            r1 = r2
            r4 = r3
            r3 = r1
        L_0x00ab:
            java.lang.String r5 = "Encountered exception while getting thumbnail"
            android.util.Log.d(r0, r5, r4)     // Catch:{ all -> 0x00b9 }
            androidx.exifinterface.media.C0042b.m166c(r1)
            if (r3 == 0) goto L_0x00b8
            androidx.exifinterface.media.C0042b.m165b(r3)
        L_0x00b8:
            return r2
        L_0x00b9:
            r0 = move-exception
        L_0x00ba:
            r2 = r1
        L_0x00bb:
            androidx.exifinterface.media.C0042b.m166c(r2)
            if (r3 == 0) goto L_0x00c3
            androidx.exifinterface.media.C0042b.m165b(r3)
        L_0x00c3:
            goto L_0x00c5
        L_0x00c4:
            throw r0
        L_0x00c5:
            goto L_0x00c4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.exifinterface.media.C0034a.mo46p():byte[]");
    }
}
