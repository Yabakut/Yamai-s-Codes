package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import androidx.versionedparcelable.C0067a;

public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(C0067a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        remoteActionCompat.f22a = (IconCompat) aVar.mo154v(remoteActionCompat.f22a, 1);
        remoteActionCompat.f23b = aVar.mo144l(remoteActionCompat.f23b, 2);
        remoteActionCompat.f24c = aVar.mo144l(remoteActionCompat.f24c, 3);
        remoteActionCompat.f25d = (PendingIntent) aVar.mo150r(remoteActionCompat.f25d, 4);
        remoteActionCompat.f26e = aVar.mo140h(remoteActionCompat.f26e, 5);
        remoteActionCompat.f27f = aVar.mo140h(remoteActionCompat.f27f, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, C0067a aVar) {
        aVar.mo156x(false, false);
        aVar.mo135M(remoteActionCompat.f22a, 1);
        aVar.mo126D(remoteActionCompat.f23b, 2);
        aVar.mo126D(remoteActionCompat.f24c, 3);
        aVar.mo130H(remoteActionCompat.f25d, 4);
        aVar.mo158z(remoteActionCompat.f26e, 5);
        aVar.mo158z(remoteActionCompat.f27f, 6);
    }
}
