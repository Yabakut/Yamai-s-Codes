package androidx.core.app;

import android.app.Activity;
import android.app.SharedElementCallback;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.core.content.C0021a;
import java.util.Arrays;

/* renamed from: androidx.core.app.a */
public class C0015a extends C0021a {

    /* renamed from: c */
    private static C0019d f28c;

    /* renamed from: androidx.core.app.a$a */
    class C0016a implements Runnable {

        /* renamed from: d */
        final /* synthetic */ String[] f29d;

        /* renamed from: e */
        final /* synthetic */ Activity f30e;

        /* renamed from: f */
        final /* synthetic */ int f31f;

        C0016a(String[] strArr, Activity activity, int i) {
            this.f29d = strArr;
            this.f30e = activity;
            this.f31f = i;
        }

        public void run() {
            int[] iArr = new int[this.f29d.length];
            PackageManager packageManager = this.f30e.getPackageManager();
            String packageName = this.f30e.getPackageName();
            int length = this.f29d.length;
            for (int i = 0; i < length; i++) {
                iArr[i] = packageManager.checkPermission(this.f29d[i], packageName);
            }
            ((C0018c) this.f30e).mo21a(this.f31f, this.f29d, iArr);
        }
    }

    /* renamed from: androidx.core.app.a$b */
    static class C0017b {
        /* renamed from: a */
        static void m32a(Object obj) {
            ((SharedElementCallback.OnSharedElementsReadyListener) obj).onSharedElementsReady();
        }

        /* renamed from: b */
        static void m33b(Activity activity, String[] strArr, int i) {
            activity.requestPermissions(strArr, i);
        }

        /* renamed from: c */
        static boolean m34c(Activity activity, String str) {
            return activity.shouldShowRequestPermissionRationale(str);
        }
    }

    /* renamed from: androidx.core.app.a$c */
    public interface C0018c {
        /* renamed from: a */
        void mo21a(int i, String[] strArr, int[] iArr);
    }

    /* renamed from: androidx.core.app.a$d */
    public interface C0019d {
        /* renamed from: a */
        boolean mo22a(Activity activity, String[] strArr, int i);
    }

    /* renamed from: androidx.core.app.a$e */
    public interface C0020e {
        /* renamed from: a */
        void mo23a(int i);
    }

    /* renamed from: e */
    public static void m31e(Activity activity, String[] strArr, int i) {
        C0019d dVar = f28c;
        if (dVar == null || !dVar.mo22a(activity, strArr, i)) {
            int length = strArr.length;
            int i2 = 0;
            while (i2 < length) {
                if (!TextUtils.isEmpty(strArr[i2])) {
                    i2++;
                } else {
                    throw new IllegalArgumentException("Permission request for permissions " + Arrays.toString(strArr) + " must not contain null or empty values");
                }
            }
            if (Build.VERSION.SDK_INT >= 23) {
                if (activity instanceof C0020e) {
                    ((C0020e) activity).mo23a(i);
                }
                C0017b.m33b(activity, strArr, i);
            } else if (activity instanceof C0018c) {
                new Handler(Looper.getMainLooper()).post(new C0016a(strArr, activity, i));
            }
        }
    }
}
