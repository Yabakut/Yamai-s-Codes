package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import p016h.C0185a;

public final class RemoteActionCompat implements C0185a {

    /* renamed from: a */
    public IconCompat f22a;

    /* renamed from: b */
    public CharSequence f23b;

    /* renamed from: c */
    public CharSequence f24c;

    /* renamed from: d */
    public PendingIntent f25d;

    /* renamed from: e */
    public boolean f26e;

    /* renamed from: f */
    public boolean f27f;
}
