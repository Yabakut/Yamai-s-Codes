package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import androidx.versionedparcelable.C0067a;

public class IconCompatParcelizer {
    public static IconCompat read(C0067a aVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f45a = aVar.mo148p(iconCompat.f45a, 1);
        iconCompat.f47c = aVar.mo142j(iconCompat.f47c, 2);
        iconCompat.f48d = aVar.mo150r(iconCompat.f48d, 3);
        iconCompat.f49e = aVar.mo148p(iconCompat.f49e, 4);
        iconCompat.f50f = aVar.mo148p(iconCompat.f50f, 5);
        iconCompat.f51g = (ColorStateList) aVar.mo150r(iconCompat.f51g, 6);
        iconCompat.f53i = aVar.mo152t(iconCompat.f53i, 7);
        iconCompat.f54j = aVar.mo152t(iconCompat.f54j, 8);
        iconCompat.mo39f();
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, C0067a aVar) {
        aVar.mo156x(true, true);
        iconCompat.mo40g(aVar.mo138f());
        int i = iconCompat.f45a;
        if (-1 != i) {
            aVar.mo128F(i, 1);
        }
        byte[] bArr = iconCompat.f47c;
        if (bArr != null) {
            aVar.mo124B(bArr, 2);
        }
        Parcelable parcelable = iconCompat.f48d;
        if (parcelable != null) {
            aVar.mo130H(parcelable, 3);
        }
        int i2 = iconCompat.f49e;
        if (i2 != 0) {
            aVar.mo128F(i2, 4);
        }
        int i3 = iconCompat.f50f;
        if (i3 != 0) {
            aVar.mo128F(i3, 5);
        }
        ColorStateList colorStateList = iconCompat.f51g;
        if (colorStateList != null) {
            aVar.mo130H(colorStateList, 6);
        }
        String str = iconCompat.f53i;
        if (str != null) {
            aVar.mo132J(str, 7);
        }
        String str2 = iconCompat.f54j;
        if (str2 != null) {
            aVar.mo132J(str2, 8);
        }
    }
}
