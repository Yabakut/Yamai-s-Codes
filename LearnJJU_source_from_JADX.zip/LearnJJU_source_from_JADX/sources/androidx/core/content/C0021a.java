package androidx.core.content;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Process;
import java.io.File;
import java.util.concurrent.Executor;
import p008d.C0109a;
import p010e.C0121b;

@SuppressLint({"PrivateConstructorForUtilityClass"})
/* renamed from: androidx.core.content.a */
public class C0021a {

    /* renamed from: a */
    private static final Object f32a = new Object();

    /* renamed from: b */
    private static final Object f33b = new Object();

    /* renamed from: androidx.core.content.a$a */
    static class C0022a {
        /* renamed from: a */
        static File[] m42a(Context context) {
            return context.getExternalCacheDirs();
        }

        /* renamed from: b */
        static File[] m43b(Context context, String str) {
            return context.getExternalFilesDirs(str);
        }

        /* renamed from: c */
        static File[] m44c(Context context) {
            return context.getObbDirs();
        }
    }

    /* renamed from: androidx.core.content.a$b */
    static class C0023b {
        /* renamed from: a */
        static Executor m45a(Context context) {
            return context.getMainExecutor();
        }
    }

    /* renamed from: a */
    public static int m38a(Context context, String str) {
        C0121b.m407a(str, "permission must be non-null");
        return context.checkPermission(str, Process.myPid(), Process.myUid());
    }

    /* renamed from: b */
    public static File[] m39b(Context context) {
        if (Build.VERSION.SDK_INT >= 19) {
            return C0022a.m42a(context);
        }
        return new File[]{context.getExternalCacheDir()};
    }

    /* renamed from: c */
    public static File[] m40c(Context context, String str) {
        if (Build.VERSION.SDK_INT >= 19) {
            return C0022a.m43b(context, str);
        }
        return new File[]{context.getExternalFilesDir(str)};
    }

    /* renamed from: d */
    public static Executor m41d(Context context) {
        return Build.VERSION.SDK_INT >= 28 ? C0023b.m45a(context) : C0109a.m386a(new Handler(context.getMainLooper()));
    }
}
