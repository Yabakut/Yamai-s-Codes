package androidx.core.content.res;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.SparseArray;
import android.util.TypedValue;
import java.util.WeakHashMap;

/* renamed from: androidx.core.content.res.a */
public final class C0028a {

    /* renamed from: a */
    private static final ThreadLocal<TypedValue> f41a = new ThreadLocal<>();

    /* renamed from: b */
    private static final WeakHashMap<Object, SparseArray<Object>> f42b = new WeakHashMap<>(0);

    /* renamed from: c */
    private static final Object f43c = new Object();

    /* renamed from: androidx.core.content.res.a$a */
    static class C0029a {
        /* renamed from: a */
        static Drawable m61a(Resources resources, int i, Resources.Theme theme) {
            return resources.getDrawable(i, theme);
        }

        /* renamed from: b */
        static Drawable m62b(Resources resources, int i, int i2, Resources.Theme theme) {
            return resources.getDrawableForDensity(i, i2, theme);
        }
    }

    /* renamed from: a */
    public static Drawable m60a(Resources resources, int i, Resources.Theme theme) {
        return Build.VERSION.SDK_INT >= 21 ? C0029a.m61a(resources, i, theme) : resources.getDrawable(i);
    }
}
