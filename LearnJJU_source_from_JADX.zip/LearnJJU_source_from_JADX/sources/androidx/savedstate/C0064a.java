package androidx.savedstate;

import android.annotation.SuppressLint;

@SuppressLint({"RestrictedApi"})
/* renamed from: androidx.savedstate.a */
public final class C0064a {
}
