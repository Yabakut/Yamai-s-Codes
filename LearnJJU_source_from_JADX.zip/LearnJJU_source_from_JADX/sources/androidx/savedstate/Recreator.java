package androidx.savedstate;

import android.annotation.SuppressLint;
import androidx.lifecycle.C0051d;
import androidx.lifecycle.C0055e;
import androidx.lifecycle.C0057g;

@SuppressLint({"RestrictedApi"})
final class Recreator implements C0055e {

    /* renamed from: a */
    private final C0065b f189a;

    /* renamed from: g */
    public void mo11g(C0057g gVar, C0051d.C0053b bVar) {
        if (bVar != C0051d.C0053b.ON_CREATE) {
            throw new AssertionError("Next event must be ON_CREATE");
        }
        gVar.mo111a().mo108c(this);
        this.f189a.mo116j();
        throw null;
    }
}
