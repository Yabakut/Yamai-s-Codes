package androidx.savedstate;

import androidx.lifecycle.C0057g;

/* renamed from: androidx.savedstate.b */
public interface C0065b extends C0057g {
    /* renamed from: j */
    C0064a mo116j();
}
