package androidx.savedstate;

import androidx.lifecycle.C0051d;
import androidx.lifecycle.C0055e;
import androidx.lifecycle.C0057g;

class SavedStateRegistry$1 implements C0055e {
    /* renamed from: g */
    public void mo11g(C0057g gVar, C0051d.C0053b bVar) {
        if (bVar == C0051d.C0053b.ON_START) {
            throw null;
        } else if (bVar == C0051d.C0053b.ON_STOP) {
            throw null;
        }
    }
}
