package androidx.fragment.app;

import androidx.lifecycle.C0051d;
import androidx.lifecycle.C0055e;
import androidx.lifecycle.C0057g;

class Fragment$2 implements C0055e {
    /* renamed from: g */
    public void mo11g(C0057g gVar, C0051d.C0053b bVar) {
        if (bVar == C0051d.C0053b.ON_STOP) {
            throw null;
        }
    }
}
