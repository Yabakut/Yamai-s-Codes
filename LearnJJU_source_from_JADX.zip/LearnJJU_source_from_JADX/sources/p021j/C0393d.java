package p021j;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import p051y.C0843c;

/* renamed from: j.d */
public class C0393d extends BroadcastReceiver implements C0843c.C0848d {

    /* renamed from: a */
    private final Context f939a;

    /* renamed from: b */
    private final C0390a f940b;

    /* renamed from: c */
    private C0843c.C0845b f941c;

    /* renamed from: d */
    private final Handler f942d = new Handler(Looper.getMainLooper());

    /* renamed from: e */
    private ConnectivityManager.NetworkCallback f943e;

    /* renamed from: j.d$a */
    class C0394a extends ConnectivityManager.NetworkCallback {
        C0394a() {
        }

        public void onAvailable(Network network) {
            C0393d.this.m1440i();
        }

        public void onLost(Network network) {
            C0393d.this.m1441j("none");
        }
    }

    public C0393d(Context context, C0390a aVar) {
        this.f939a = context;
        this.f940b = aVar;
    }

    /* access modifiers changed from: private */
    /* renamed from: g */
    public /* synthetic */ void m1438g() {
        this.f941c.mo1833a(this.f940b.mo1273b());
    }

    /* access modifiers changed from: private */
    /* renamed from: h */
    public /* synthetic */ void m1439h(String str) {
        this.f941c.mo1833a(str);
    }

    /* access modifiers changed from: private */
    /* renamed from: i */
    public void m1440i() {
        this.f942d.post(new C0391b(this));
    }

    /* access modifiers changed from: private */
    /* renamed from: j */
    public void m1441j(String str) {
        this.f942d.post(new C0392c(this, str));
    }

    /* renamed from: a */
    public void mo1276a(Object obj) {
        if (Build.VERSION.SDK_INT < 24) {
            try {
                this.f939a.unregisterReceiver(this);
            } catch (Exception unused) {
            }
        } else if (this.f943e != null) {
            this.f940b.mo1272a().unregisterNetworkCallback(this.f943e);
            this.f943e = null;
        }
    }

    /* renamed from: b */
    public void mo1277b(Object obj, C0843c.C0845b bVar) {
        this.f941c = bVar;
        if (Build.VERSION.SDK_INT >= 24) {
            this.f943e = new C0394a();
            this.f940b.mo1272a().registerDefaultNetworkCallback(this.f943e);
            return;
        }
        this.f939a.registerReceiver(this, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
    }

    public void onReceive(Context context, Intent intent) {
        C0843c.C0845b bVar = this.f941c;
        if (bVar != null) {
            bVar.mo1833a(this.f940b.mo1273b());
        }
    }
}
