package p021j;

import android.content.Context;
import android.net.ConnectivityManager;
import p033p.C0555a;
import p051y.C0839b;
import p051y.C0843c;
import p051y.C0855j;

/* renamed from: j.f */
public class C0396f implements C0555a {

    /* renamed from: a */
    private C0855j f946a;

    /* renamed from: b */
    private C0843c f947b;

    /* renamed from: c */
    private C0393d f948c;

    /* renamed from: a */
    private void m1445a(C0839b bVar, Context context) {
        this.f946a = new C0855j(bVar, "dev.fluttercommunity.plus/connectivity");
        this.f947b = new C0843c(bVar, "dev.fluttercommunity.plus/connectivity_status");
        C0390a aVar = new C0390a((ConnectivityManager) context.getSystemService("connectivity"));
        C0395e eVar = new C0395e(aVar);
        this.f948c = new C0393d(context, aVar);
        this.f946a.mo1847e(eVar);
        this.f947b.mo1832d(this.f948c);
    }

    /* renamed from: b */
    private void m1446b() {
        this.f946a.mo1847e((C0855j.C0859c) null);
        this.f947b.mo1832d((C0843c.C0848d) null);
        this.f948c.mo1276a((Object) null);
        this.f946a = null;
        this.f947b = null;
        this.f948c = null;
    }

    /* renamed from: d */
    public void mo429d(C0555a.C0557b bVar) {
        m1446b();
    }

    /* renamed from: e */
    public void mo430e(C0555a.C0557b bVar) {
        m1445a(bVar.mo1517b(), bVar.mo1516a());
    }
}
