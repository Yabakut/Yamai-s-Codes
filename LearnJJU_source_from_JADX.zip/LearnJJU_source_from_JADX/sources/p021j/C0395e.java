package p021j;

import p051y.C0854i;
import p051y.C0855j;

/* renamed from: j.e */
class C0395e implements C0855j.C0859c {

    /* renamed from: a */
    private final C0390a f945a;

    C0395e(C0390a aVar) {
        this.f945a = aVar;
    }

    /* renamed from: b */
    public void mo531b(C0854i iVar, C0855j.C0860d dVar) {
        if ("check".equals(iVar.f1634a)) {
            dVar.mo1199a(this.f945a.mo1273b());
        } else {
            dVar.mo1201c();
        }
    }
}
