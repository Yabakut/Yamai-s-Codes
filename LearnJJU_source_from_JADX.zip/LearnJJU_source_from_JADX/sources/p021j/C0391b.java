package p021j;

/* renamed from: j.b */
public final /* synthetic */ class C0391b implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ C0393d f936d;

    public /* synthetic */ C0391b(C0393d dVar) {
        this.f936d = dVar;
    }

    public final void run() {
        this.f936d.m1438g();
    }
}
