package p021j;

import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;

/* renamed from: j.a */
public class C0390a {

    /* renamed from: a */
    private final ConnectivityManager f935a;

    public C0390a(ConnectivityManager connectivityManager) {
        this.f935a = connectivityManager;
    }

    /* renamed from: c */
    private String m1431c() {
        NetworkInfo activeNetworkInfo = this.f935a.getActiveNetworkInfo();
        if (activeNetworkInfo == null || !activeNetworkInfo.isConnected()) {
            return "none";
        }
        int type = activeNetworkInfo.getType();
        return type != 0 ? type != 1 ? (type == 4 || type == 5) ? "mobile" : type != 6 ? type != 7 ? type != 9 ? "none" : "ethernet" : "bluetooth" : "wifi" : "wifi" : "mobile";
    }

    /* renamed from: a */
    public ConnectivityManager mo1272a() {
        return this.f935a;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public String mo1273b() {
        if (Build.VERSION.SDK_INT >= 23) {
            NetworkCapabilities networkCapabilities = this.f935a.getNetworkCapabilities(this.f935a.getActiveNetwork());
            if (networkCapabilities == null) {
                return "none";
            }
            if (networkCapabilities.hasTransport(1)) {
                return "wifi";
            }
            if (networkCapabilities.hasTransport(3)) {
                return "ethernet";
            }
            if (networkCapabilities.hasTransport(0)) {
                return "mobile";
            }
            if (networkCapabilities.hasTransport(2)) {
                return "bluetooth";
            }
        }
        return m1431c();
    }
}
