package p021j;

/* renamed from: j.c */
public final /* synthetic */ class C0392c implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ C0393d f937d;

    /* renamed from: e */
    public final /* synthetic */ String f938e;

    public /* synthetic */ C0392c(C0393d dVar, String str) {
        this.f937d = dVar;
        this.f938e = str;
    }

    public final void run() {
        this.f937d.m1439h(this.f938e);
    }
}
