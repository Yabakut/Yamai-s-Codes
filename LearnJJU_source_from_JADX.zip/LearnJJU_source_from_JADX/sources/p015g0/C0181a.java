package p015g0;

/* renamed from: g0.a */
public final class C0181a extends C0184d {
}
