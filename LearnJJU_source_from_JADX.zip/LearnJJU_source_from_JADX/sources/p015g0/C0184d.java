package p015g0;

/* renamed from: g0.d */
class C0184d extends C0183c {
}
