package p015g0;

/* renamed from: g0.c */
class C0183c extends C0182b {
}
