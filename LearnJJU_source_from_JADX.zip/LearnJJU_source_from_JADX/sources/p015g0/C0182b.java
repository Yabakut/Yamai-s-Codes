package p015g0;

/* renamed from: g0.b */
class C0182b {
    /* renamed from: a */
    public static <T extends Comparable<?>> int m533a(T t, T t2) {
        if (t == t2) {
            return 0;
        }
        if (t == null) {
            return -1;
        }
        if (t2 == null) {
            return 1;
        }
        return t.compareTo(t2);
    }
}
