package p042t0;

/* renamed from: t0.g */
class C0596g extends C0594f {
}
