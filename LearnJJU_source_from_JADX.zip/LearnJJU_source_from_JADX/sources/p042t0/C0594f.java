package p042t0;

import java.util.Iterator;
import kotlin.jvm.internal.C0429i;

/* renamed from: t0.f */
class C0594f extends C0593e {

    /* renamed from: t0.f$a */
    public static final class C0595a implements C0590b<T> {

        /* renamed from: a */
        final /* synthetic */ Iterator f1214a;

        public C0595a(Iterator it) {
            this.f1214a = it;
        }

        public Iterator<T> iterator() {
            return this.f1214a;
        }
    }

    /* renamed from: a */
    public static <T> C0590b<T> m1891a(Iterator<? extends T> it) {
        C0429i.m1496d(it, "<this>");
        return m1892b(new C0595a(it));
    }

    /* renamed from: b */
    public static final <T> C0590b<T> m1892b(C0590b<? extends T> bVar) {
        C0429i.m1496d(bVar, "<this>");
        return bVar instanceof C0589a ? bVar : new C0589a(bVar);
    }
}
