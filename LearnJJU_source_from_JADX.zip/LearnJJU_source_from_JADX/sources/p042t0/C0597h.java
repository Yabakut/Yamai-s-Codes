package p042t0;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.jvm.internal.C0429i;
import p032o0.C0543l;

/* renamed from: t0.h */
class C0597h extends C0596g {
    /* renamed from: c */
    public static <T, R> C0590b<R> m1893c(C0590b<? extends T> bVar, C0543l<? super T, ? extends R> lVar) {
        C0429i.m1496d(bVar, "<this>");
        C0429i.m1496d(lVar, "transform");
        return new C0598i(bVar, lVar);
    }

    /* renamed from: d */
    public static final <T, C extends Collection<? super T>> C m1894d(C0590b<? extends T> bVar, C c) {
        C0429i.m1496d(bVar, "<this>");
        C0429i.m1496d(c, "destination");
        for (Object add : bVar) {
            c.add(add);
        }
        return c;
    }

    /* renamed from: e */
    public static <T> List<T> m1895e(C0590b<? extends T> bVar) {
        C0429i.m1496d(bVar, "<this>");
        return C0161i.m478e(m1896f(bVar));
    }

    /* renamed from: f */
    public static final <T> List<T> m1896f(C0590b<? extends T> bVar) {
        C0429i.m1496d(bVar, "<this>");
        return (List) m1894d(bVar, new ArrayList());
    }
}
