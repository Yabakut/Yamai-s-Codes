package p042t0;

import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;
import kotlin.jvm.internal.C0429i;

/* renamed from: t0.a */
public final class C0589a<T> implements C0590b<T> {

    /* renamed from: a */
    private final AtomicReference<C0590b<T>> f1213a;

    public C0589a(C0590b<? extends T> bVar) {
        C0429i.m1496d(bVar, "sequence");
        this.f1213a = new AtomicReference<>(bVar);
    }

    public Iterator<T> iterator() {
        C0590b andSet = this.f1213a.getAndSet((Object) null);
        if (andSet != null) {
            return andSet.iterator();
        }
        throw new IllegalStateException("This sequence can be consumed only once.");
    }
}
