package p042t0;

import java.util.Iterator;
import kotlin.jvm.internal.C0429i;
import p032o0.C0543l;

/* renamed from: t0.i */
public final class C0598i<T, R> implements C0590b<R> {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public final C0590b<T> f1215a;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public final C0543l<T, R> f1216b;

    /* renamed from: t0.i$a */
    public static final class C0599a implements Iterator<R> {

        /* renamed from: d */
        private final Iterator<T> f1217d;

        /* renamed from: e */
        final /* synthetic */ C0598i<T, R> f1218e;

        C0599a(C0598i<T, R> iVar) {
            this.f1218e = iVar;
            this.f1217d = iVar.f1215a.iterator();
        }

        public boolean hasNext() {
            return this.f1217d.hasNext();
        }

        public R next() {
            return this.f1218e.f1216b.invoke(this.f1217d.next());
        }

        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public C0598i(C0590b<? extends T> bVar, C0543l<? super T, ? extends R> lVar) {
        C0429i.m1496d(bVar, "sequence");
        C0429i.m1496d(lVar, "transformer");
        this.f1215a = bVar;
        this.f1216b = lVar;
    }

    public Iterator<R> iterator() {
        return new C0599a(this);
    }
}
