package p042t0;

import java.util.Iterator;

/* renamed from: t0.b */
public interface C0590b<T> {
    Iterator<T> iterator();
}
