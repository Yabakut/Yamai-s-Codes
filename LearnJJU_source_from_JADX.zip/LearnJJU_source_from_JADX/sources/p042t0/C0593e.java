package p042t0;

/* renamed from: t0.e */
class C0593e extends C0592d {
}
