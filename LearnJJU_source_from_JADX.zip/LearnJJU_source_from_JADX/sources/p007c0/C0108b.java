package p007c0;

import android.content.Context;
import p033p.C0555a;
import p051y.C0839b;
import p051y.C0855j;

/* renamed from: c0.b */
public class C0108b implements C0555a {

    /* renamed from: a */
    private C0855j f264a;

    /* renamed from: b */
    private C0105a f265b;

    /* renamed from: a */
    private void m382a(C0839b bVar, Context context) {
        this.f264a = new C0855j(bVar, "plugins.flutter.io/shared_preferences_android");
        C0105a aVar = new C0105a(context);
        this.f265b = aVar;
        this.f264a.mo1847e(aVar);
    }

    /* renamed from: b */
    private void m383b() {
        this.f265b.mo532g();
        this.f265b = null;
        this.f264a.mo1847e((C0855j.C0859c) null);
        this.f264a = null;
    }

    /* renamed from: d */
    public void mo429d(C0555a.C0557b bVar) {
        m383b();
    }

    /* renamed from: e */
    public void mo430e(C0555a.C0557b bVar) {
        m382a(bVar.mo1517b(), bVar.mo1516a());
    }
}
