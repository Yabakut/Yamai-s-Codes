package p012f;

import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;
import p006c.C0104d;

/* renamed from: f.a */
public final class C0142a {

    /* renamed from: a */
    private final C0147e f278a;

    /* renamed from: f.a$a */
    private static class C0143a extends C0147e {

        /* renamed from: a */
        protected final Window f279a;

        /* renamed from: b */
        private final View f280b;

        C0143a(Window window, View view) {
            this.f279a = window;
            this.f280b = view;
        }

        /* access modifiers changed from: protected */
        /* renamed from: c */
        public void mo554c(int i) {
            View decorView = this.f279a.getDecorView();
            decorView.setSystemUiVisibility(i | decorView.getSystemUiVisibility());
        }

        /* access modifiers changed from: protected */
        /* renamed from: d */
        public void mo555d(int i) {
            this.f279a.addFlags(i);
        }

        /* access modifiers changed from: protected */
        /* renamed from: e */
        public void mo556e(int i) {
            View decorView = this.f279a.getDecorView();
            decorView.setSystemUiVisibility((i ^ -1) & decorView.getSystemUiVisibility());
        }

        /* access modifiers changed from: protected */
        /* renamed from: f */
        public void mo557f(int i) {
            this.f279a.clearFlags(i);
        }
    }

    /* renamed from: f.a$b */
    private static class C0144b extends C0143a {
        C0144b(Window window, View view) {
            super(window, view);
        }

        /* renamed from: b */
        public void mo558b(boolean z) {
            if (z) {
                mo557f(67108864);
                mo555d(Integer.MIN_VALUE);
                mo554c(8192);
                return;
            }
            mo556e(8192);
        }
    }

    /* renamed from: f.a$c */
    private static class C0145c extends C0144b {
        C0145c(Window window, View view) {
            super(window, view);
        }

        /* renamed from: a */
        public void mo559a(boolean z) {
            if (z) {
                mo557f(134217728);
                mo555d(Integer.MIN_VALUE);
                mo554c(16);
                return;
            }
            mo556e(16);
        }
    }

    /* renamed from: f.a$d */
    private static class C0146d extends C0147e {

        /* renamed from: a */
        final C0142a f281a;

        /* renamed from: b */
        final WindowInsetsController f282b;

        /* renamed from: c */
        private final C0104d<Object, WindowInsetsController.OnControllableInsetsChangedListener> f283c;

        /* renamed from: d */
        protected Window f284d;

        C0146d(Window window, C0142a aVar) {
            this(window.getInsetsController(), aVar);
            this.f284d = window;
        }

        C0146d(WindowInsetsController windowInsetsController, C0142a aVar) {
            this.f283c = new C0104d<>();
            this.f282b = windowInsetsController;
            this.f281a = aVar;
        }

        /* renamed from: a */
        public void mo559a(boolean z) {
            if (z) {
                if (this.f284d != null) {
                    mo560c(16);
                }
                this.f282b.setSystemBarsAppearance(16, 16);
                return;
            }
            if (this.f284d != null) {
                mo561d(16);
            }
            this.f282b.setSystemBarsAppearance(0, 16);
        }

        /* renamed from: b */
        public void mo558b(boolean z) {
            if (z) {
                if (this.f284d != null) {
                    mo560c(8192);
                }
                this.f282b.setSystemBarsAppearance(8, 8);
                return;
            }
            if (this.f284d != null) {
                mo561d(8192);
            }
            this.f282b.setSystemBarsAppearance(0, 8);
        }

        /* access modifiers changed from: protected */
        /* renamed from: c */
        public void mo560c(int i) {
            View decorView = this.f284d.getDecorView();
            decorView.setSystemUiVisibility(i | decorView.getSystemUiVisibility());
        }

        /* access modifiers changed from: protected */
        /* renamed from: d */
        public void mo561d(int i) {
            View decorView = this.f284d.getDecorView();
            decorView.setSystemUiVisibility((i ^ -1) & decorView.getSystemUiVisibility());
        }
    }

    /* renamed from: f.a$e */
    private static class C0147e {
        C0147e() {
        }

        /* renamed from: a */
        public void mo559a(boolean z) {
        }

        /* renamed from: b */
        public void mo558b(boolean z) {
        }
    }

    public C0142a(Window window, View view) {
        C0147e aVar;
        int i = Build.VERSION.SDK_INT;
        if (i >= 30) {
            this.f278a = new C0146d(window, this);
            return;
        }
        if (i >= 26) {
            aVar = new C0145c(window, view);
        } else if (i >= 23) {
            aVar = new C0144b(window, view);
        } else if (i >= 20) {
            aVar = new C0143a(window, view);
        } else {
            this.f278a = new C0147e();
            return;
        }
        this.f278a = aVar;
    }

    /* renamed from: a */
    public void mo552a(boolean z) {
        this.f278a.mo559a(z);
    }

    /* renamed from: b */
    public void mo553b(boolean z) {
        this.f278a.mo558b(z);
    }
}
