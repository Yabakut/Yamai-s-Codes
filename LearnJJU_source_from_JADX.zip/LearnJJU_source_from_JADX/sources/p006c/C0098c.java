package p006c;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

/* renamed from: c.c */
abstract class C0098c<K, V> {

    /* renamed from: a */
    C0098c<K, V>.b f234a;

    /* renamed from: b */
    C0098c<K, V>.c f235b;

    /* renamed from: c */
    C0098c<K, V>.e f236c;

    /* renamed from: c.c$a */
    final class C0099a<T> implements Iterator<T> {

        /* renamed from: d */
        final int f237d;

        /* renamed from: e */
        int f238e;

        /* renamed from: f */
        int f239f;

        /* renamed from: g */
        boolean f240g = false;

        C0099a(int i) {
            this.f237d = i;
            this.f238e = C0098c.this.mo438d();
        }

        public boolean hasNext() {
            return this.f239f < this.f238e;
        }

        public T next() {
            if (hasNext()) {
                T b = C0098c.this.mo436b(this.f239f, this.f237d);
                this.f239f++;
                this.f240g = true;
                return b;
            }
            throw new NoSuchElementException();
        }

        public void remove() {
            if (this.f240g) {
                int i = this.f239f - 1;
                this.f239f = i;
                this.f238e--;
                this.f240g = false;
                C0098c.this.mo442h(i);
                return;
            }
            throw new IllegalStateException();
        }
    }

    /* renamed from: c.c$b */
    final class C0100b implements Set<Map.Entry<K, V>> {
        C0100b() {
        }

        /* renamed from: a */
        public boolean add(Map.Entry<K, V> entry) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends Map.Entry<K, V>> collection) {
            int d = C0098c.this.mo438d();
            for (Map.Entry entry : collection) {
                C0098c.this.mo441g(entry.getKey(), entry.getValue());
            }
            return d != C0098c.this.mo438d();
        }

        public void clear() {
            C0098c.this.mo435a();
        }

        public boolean contains(Object obj) {
            if (!(obj instanceof Map.Entry)) {
                return false;
            }
            Map.Entry entry = (Map.Entry) obj;
            int e = C0098c.this.mo439e(entry.getKey());
            if (e < 0) {
                return false;
            }
            return C0097b.m342b(C0098c.this.mo436b(e, 1), entry.getValue());
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean equals(Object obj) {
            return C0098c.m344k(this, obj);
        }

        public int hashCode() {
            int i = 0;
            for (int d = C0098c.this.mo438d() - 1; d >= 0; d--) {
                Object b = C0098c.this.mo436b(d, 0);
                Object b2 = C0098c.this.mo436b(d, 1);
                i += (b == null ? 0 : b.hashCode()) ^ (b2 == null ? 0 : b2.hashCode());
            }
            return i;
        }

        public boolean isEmpty() {
            return C0098c.this.mo438d() == 0;
        }

        public Iterator<Map.Entry<K, V>> iterator() {
            return new C0102d();
        }

        public boolean remove(Object obj) {
            throw new UnsupportedOperationException();
        }

        public boolean removeAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public boolean retainAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public int size() {
            return C0098c.this.mo438d();
        }

        public Object[] toArray() {
            throw new UnsupportedOperationException();
        }

        public <T> T[] toArray(T[] tArr) {
            throw new UnsupportedOperationException();
        }
    }

    /* renamed from: c.c$c */
    final class C0101c implements Set<K> {
        C0101c() {
        }

        public boolean add(K k) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends K> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            C0098c.this.mo435a();
        }

        public boolean contains(Object obj) {
            return C0098c.this.mo439e(obj) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            return C0098c.m343j(C0098c.this.mo437c(), collection);
        }

        public boolean equals(Object obj) {
            return C0098c.m344k(this, obj);
        }

        public int hashCode() {
            int i = 0;
            for (int d = C0098c.this.mo438d() - 1; d >= 0; d--) {
                Object b = C0098c.this.mo436b(d, 0);
                i += b == null ? 0 : b.hashCode();
            }
            return i;
        }

        public boolean isEmpty() {
            return C0098c.this.mo438d() == 0;
        }

        public Iterator<K> iterator() {
            return new C0099a(0);
        }

        public boolean remove(Object obj) {
            int e = C0098c.this.mo439e(obj);
            if (e < 0) {
                return false;
            }
            C0098c.this.mo442h(e);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            return C0098c.m345o(C0098c.this.mo437c(), collection);
        }

        public boolean retainAll(Collection<?> collection) {
            return C0098c.m346p(C0098c.this.mo437c(), collection);
        }

        public int size() {
            return C0098c.this.mo438d();
        }

        public Object[] toArray() {
            return C0098c.this.mo447q(0);
        }

        public <T> T[] toArray(T[] tArr) {
            return C0098c.this.mo448r(tArr, 0);
        }
    }

    /* renamed from: c.c$d */
    final class C0102d implements Iterator<Map.Entry<K, V>>, Map.Entry<K, V> {

        /* renamed from: d */
        int f244d;

        /* renamed from: e */
        int f245e;

        /* renamed from: f */
        boolean f246f = false;

        C0102d() {
            this.f244d = C0098c.this.mo438d() - 1;
            this.f245e = -1;
        }

        /* renamed from: a */
        public Map.Entry<K, V> next() {
            if (hasNext()) {
                this.f245e++;
                this.f246f = true;
                return this;
            }
            throw new NoSuchElementException();
        }

        public boolean equals(Object obj) {
            if (!this.f246f) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            } else if (!(obj instanceof Map.Entry)) {
                return false;
            } else {
                Map.Entry entry = (Map.Entry) obj;
                return C0097b.m342b(entry.getKey(), C0098c.this.mo436b(this.f245e, 0)) && C0097b.m342b(entry.getValue(), C0098c.this.mo436b(this.f245e, 1));
            }
        }

        public K getKey() {
            if (this.f246f) {
                return C0098c.this.mo436b(this.f245e, 0);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public V getValue() {
            if (this.f246f) {
                return C0098c.this.mo436b(this.f245e, 1);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public boolean hasNext() {
            return this.f245e < this.f244d;
        }

        public int hashCode() {
            if (this.f246f) {
                int i = 0;
                Object b = C0098c.this.mo436b(this.f245e, 0);
                Object b2 = C0098c.this.mo436b(this.f245e, 1);
                int hashCode = b == null ? 0 : b.hashCode();
                if (b2 != null) {
                    i = b2.hashCode();
                }
                return hashCode ^ i;
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public void remove() {
            if (this.f246f) {
                C0098c.this.mo442h(this.f245e);
                this.f245e--;
                this.f244d--;
                this.f246f = false;
                return;
            }
            throw new IllegalStateException();
        }

        public V setValue(V v) {
            if (this.f246f) {
                return C0098c.this.mo443i(this.f245e, v);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public String toString() {
            return getKey() + "=" + getValue();
        }
    }

    /* renamed from: c.c$e */
    final class C0103e implements Collection<V> {
        C0103e() {
        }

        public boolean add(V v) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends V> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            C0098c.this.mo435a();
        }

        public boolean contains(Object obj) {
            return C0098c.this.mo440f(obj) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean isEmpty() {
            return C0098c.this.mo438d() == 0;
        }

        public Iterator<V> iterator() {
            return new C0099a(1);
        }

        public boolean remove(Object obj) {
            int f = C0098c.this.mo440f(obj);
            if (f < 0) {
                return false;
            }
            C0098c.this.mo442h(f);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            int d = C0098c.this.mo438d();
            int i = 0;
            boolean z = false;
            while (i < d) {
                if (collection.contains(C0098c.this.mo436b(i, 1))) {
                    C0098c.this.mo442h(i);
                    i--;
                    d--;
                    z = true;
                }
                i++;
            }
            return z;
        }

        public boolean retainAll(Collection<?> collection) {
            int d = C0098c.this.mo438d();
            int i = 0;
            boolean z = false;
            while (i < d) {
                if (!collection.contains(C0098c.this.mo436b(i, 1))) {
                    C0098c.this.mo442h(i);
                    i--;
                    d--;
                    z = true;
                }
                i++;
            }
            return z;
        }

        public int size() {
            return C0098c.this.mo438d();
        }

        public Object[] toArray() {
            return C0098c.this.mo447q(1);
        }

        public <T> T[] toArray(T[] tArr) {
            return C0098c.this.mo448r(tArr, 1);
        }
    }

    C0098c() {
    }

    /* renamed from: j */
    public static <K, V> boolean m343j(Map<K, V> map, Collection<?> collection) {
        for (Object containsKey : collection) {
            if (!map.containsKey(containsKey)) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: k */
    public static <T> boolean m344k(Set<T> set, Object obj) {
        if (set == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set2 = (Set) obj;
            try {
                return set.size() == set2.size() && set.containsAll(set2);
            } catch (ClassCastException | NullPointerException unused) {
            }
        }
        return false;
    }

    /* renamed from: o */
    public static <K, V> boolean m345o(Map<K, V> map, Collection<?> collection) {
        int size = map.size();
        for (Object remove : collection) {
            map.remove(remove);
        }
        return size != map.size();
    }

    /* renamed from: p */
    public static <K, V> boolean m346p(Map<K, V> map, Collection<?> collection) {
        int size = map.size();
        Iterator<K> it = map.keySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(it.next())) {
                it.remove();
            }
        }
        return size != map.size();
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo435a();

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract Object mo436b(int i, int i2);

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public abstract Map<K, V> mo437c();

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public abstract int mo438d();

    /* access modifiers changed from: protected */
    /* renamed from: e */
    public abstract int mo439e(Object obj);

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public abstract int mo440f(Object obj);

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public abstract void mo441g(K k, V v);

    /* access modifiers changed from: protected */
    /* renamed from: h */
    public abstract void mo442h(int i);

    /* access modifiers changed from: protected */
    /* renamed from: i */
    public abstract V mo443i(int i, V v);

    /* renamed from: l */
    public Set<Map.Entry<K, V>> mo444l() {
        if (this.f234a == null) {
            this.f234a = new C0100b();
        }
        return this.f234a;
    }

    /* renamed from: m */
    public Set<K> mo445m() {
        if (this.f235b == null) {
            this.f235b = new C0101c();
        }
        return this.f235b;
    }

    /* renamed from: n */
    public Collection<V> mo446n() {
        if (this.f236c == null) {
            this.f236c = new C0103e();
        }
        return this.f236c;
    }

    /* renamed from: q */
    public Object[] mo447q(int i) {
        int d = mo438d();
        Object[] objArr = new Object[d];
        for (int i2 = 0; i2 < d; i2++) {
            objArr[i2] = mo436b(i2, i);
        }
        return objArr;
    }

    /* renamed from: r */
    public <T> T[] mo448r(T[] tArr, int i) {
        int d = mo438d();
        if (tArr.length < d) {
            tArr = (Object[]) Array.newInstance(tArr.getClass().getComponentType(), d);
        }
        for (int i2 = 0; i2 < d; i2++) {
            tArr[i2] = mo436b(i2, i);
        }
        if (tArr.length > d) {
            tArr[d] = null;
        }
        return tArr;
    }
}
