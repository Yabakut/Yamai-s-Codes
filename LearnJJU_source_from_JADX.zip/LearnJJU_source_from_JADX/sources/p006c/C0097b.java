package p006c;

/* renamed from: c.b */
class C0097b {

    /* renamed from: a */
    static final int[] f231a = new int[0];

    /* renamed from: b */
    static final long[] f232b = new long[0];

    /* renamed from: c */
    static final Object[] f233c = new Object[0];

    /* renamed from: a */
    static int m341a(int[] iArr, int i, int i2) {
        int i3 = i - 1;
        int i4 = 0;
        while (i4 <= i3) {
            int i5 = (i4 + i3) >>> 1;
            int i6 = iArr[i5];
            if (i6 < i2) {
                i4 = i5 + 1;
            } else if (i6 <= i2) {
                return i5;
            } else {
                i3 = i5 - 1;
            }
        }
        return i4 ^ -1;
    }

    /* renamed from: b */
    public static boolean m342b(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }
}
