package p006c;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

/* renamed from: c.a */
public class C0095a<K, V> extends C0104d<K, V> implements Map<K, V> {

    /* renamed from: k */
    C0098c<K, V> f229k;

    /* renamed from: c.a$a */
    class C0096a extends C0098c<K, V> {
        C0096a() {
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo435a() {
            C0095a.this.clear();
        }

        /* access modifiers changed from: protected */
        /* renamed from: b */
        public Object mo436b(int i, int i2) {
            return C0095a.this.f254e[(i << 1) + i2];
        }

        /* access modifiers changed from: protected */
        /* renamed from: c */
        public Map<K, V> mo437c() {
            return C0095a.this;
        }

        /* access modifiers changed from: protected */
        /* renamed from: d */
        public int mo438d() {
            return C0095a.this.f255f;
        }

        /* access modifiers changed from: protected */
        /* renamed from: e */
        public int mo439e(Object obj) {
            return C0095a.this.mo512f(obj);
        }

        /* access modifiers changed from: protected */
        /* renamed from: f */
        public int mo440f(Object obj) {
            return C0095a.this.mo516h(obj);
        }

        /* access modifiers changed from: protected */
        /* renamed from: g */
        public void mo441g(K k, V v) {
            C0095a.this.put(k, v);
        }

        /* access modifiers changed from: protected */
        /* renamed from: h */
        public void mo442h(int i) {
            C0095a.this.mo520j(i);
        }

        /* access modifiers changed from: protected */
        /* renamed from: i */
        public V mo443i(int i, V v) {
            return C0095a.this.mo521k(i, v);
        }
    }

    /* renamed from: m */
    private C0098c<K, V> m331m() {
        if (this.f229k == null) {
            this.f229k = new C0096a();
        }
        return this.f229k;
    }

    public Set<Map.Entry<K, V>> entrySet() {
        return m331m().mo444l();
    }

    public Set<K> keySet() {
        return m331m().mo445m();
    }

    public void putAll(Map<? extends K, ? extends V> map) {
        mo506c(this.f255f + map.size());
        for (Map.Entry next : map.entrySet()) {
            put(next.getKey(), next.getValue());
        }
    }

    public Collection<V> values() {
        return m331m().mo446n();
    }
}
