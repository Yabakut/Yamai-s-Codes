package p006c;

import java.util.ConcurrentModificationException;
import java.util.Map;

/* renamed from: c.d */
public class C0104d<K, V> {

    /* renamed from: g */
    static Object[] f249g;

    /* renamed from: h */
    static int f250h;

    /* renamed from: i */
    static Object[] f251i;

    /* renamed from: j */
    static int f252j;

    /* renamed from: d */
    int[] f253d = C0097b.f231a;

    /* renamed from: e */
    Object[] f254e = C0097b.f233c;

    /* renamed from: f */
    int f255f = 0;

    /* renamed from: a */
    private void m363a(int i) {
        Class<C0104d> cls = C0104d.class;
        if (i == 8) {
            synchronized (cls) {
                Object[] objArr = f251i;
                if (objArr != null) {
                    this.f254e = objArr;
                    f251i = (Object[]) objArr[0];
                    this.f253d = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    f252j--;
                    return;
                }
            }
        } else if (i == 4) {
            synchronized (cls) {
                Object[] objArr2 = f249g;
                if (objArr2 != null) {
                    this.f254e = objArr2;
                    f249g = (Object[]) objArr2[0];
                    this.f253d = (int[]) objArr2[1];
                    objArr2[1] = null;
                    objArr2[0] = null;
                    f250h--;
                    return;
                }
            }
        }
        this.f253d = new int[i];
        this.f254e = new Object[(i << 1)];
    }

    /* renamed from: b */
    private static int m364b(int[] iArr, int i, int i2) {
        try {
            return C0097b.m341a(iArr, i, i2);
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    /* renamed from: d */
    private static void m365d(int[] iArr, Object[] objArr, int i) {
        Class<C0104d> cls = C0104d.class;
        if (iArr.length == 8) {
            synchronized (cls) {
                if (f252j < 10) {
                    objArr[0] = f251i;
                    objArr[1] = iArr;
                    for (int i2 = (i << 1) - 1; i2 >= 2; i2--) {
                        objArr[i2] = null;
                    }
                    f251i = objArr;
                    f252j++;
                }
            }
        } else if (iArr.length == 4) {
            synchronized (cls) {
                if (f250h < 10) {
                    objArr[0] = f249g;
                    objArr[1] = iArr;
                    for (int i3 = (i << 1) - 1; i3 >= 2; i3--) {
                        objArr[i3] = null;
                    }
                    f249g = objArr;
                    f250h++;
                }
            }
        }
    }

    /* renamed from: c */
    public void mo506c(int i) {
        int i2 = this.f255f;
        int[] iArr = this.f253d;
        if (iArr.length < i) {
            Object[] objArr = this.f254e;
            m363a(i);
            if (this.f255f > 0) {
                System.arraycopy(iArr, 0, this.f253d, 0, i2);
                System.arraycopy(objArr, 0, this.f254e, 0, i2 << 1);
            }
            m365d(iArr, objArr, i2);
        }
        if (this.f255f != i2) {
            throw new ConcurrentModificationException();
        }
    }

    public void clear() {
        int i = this.f255f;
        if (i > 0) {
            int[] iArr = this.f253d;
            Object[] objArr = this.f254e;
            this.f253d = C0097b.f231a;
            this.f254e = C0097b.f233c;
            this.f255f = 0;
            m365d(iArr, objArr, i);
        }
        if (this.f255f > 0) {
            throw new ConcurrentModificationException();
        }
    }

    public boolean containsKey(Object obj) {
        return mo512f(obj) >= 0;
    }

    public boolean containsValue(Object obj) {
        return mo516h(obj) >= 0;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public int mo510e(Object obj, int i) {
        int i2 = this.f255f;
        if (i2 == 0) {
            return -1;
        }
        int b = m364b(this.f253d, i2, i);
        if (b < 0 || obj.equals(this.f254e[b << 1])) {
            return b;
        }
        int i3 = b + 1;
        while (i3 < i2 && this.f253d[i3] == i) {
            if (obj.equals(this.f254e[i3 << 1])) {
                return i3;
            }
            i3++;
        }
        int i4 = b - 1;
        while (i4 >= 0 && this.f253d[i4] == i) {
            if (obj.equals(this.f254e[i4 << 1])) {
                return i4;
            }
            i4--;
        }
        return i3 ^ -1;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0104d) {
            C0104d dVar = (C0104d) obj;
            if (size() != dVar.size()) {
                return false;
            }
            int i = 0;
            while (i < this.f255f) {
                try {
                    Object i2 = mo518i(i);
                    Object l = mo522l(i);
                    Object obj2 = dVar.get(i2);
                    if (l == null) {
                        if (obj2 != null || !dVar.containsKey(i2)) {
                            return false;
                        }
                    } else if (!l.equals(obj2)) {
                        return false;
                    }
                    i++;
                } catch (ClassCastException | NullPointerException unused) {
                    return false;
                }
            }
            return true;
        }
        if (obj instanceof Map) {
            Map map = (Map) obj;
            if (size() != map.size()) {
                return false;
            }
            int i3 = 0;
            while (i3 < this.f255f) {
                try {
                    Object i4 = mo518i(i3);
                    Object l2 = mo522l(i3);
                    Object obj3 = map.get(i4);
                    if (l2 == null) {
                        if (obj3 != null || !map.containsKey(i4)) {
                            return false;
                        }
                    } else if (!l2.equals(obj3)) {
                        return false;
                    }
                    i3++;
                } catch (ClassCastException | NullPointerException unused2) {
                }
            }
            return true;
        }
        return false;
    }

    /* renamed from: f */
    public int mo512f(Object obj) {
        return obj == null ? mo513g() : mo510e(obj, obj.hashCode());
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public int mo513g() {
        int i = this.f255f;
        if (i == 0) {
            return -1;
        }
        int b = m364b(this.f253d, i, 0);
        if (b < 0 || this.f254e[b << 1] == null) {
            return b;
        }
        int i2 = b + 1;
        while (i2 < i && this.f253d[i2] == 0) {
            if (this.f254e[i2 << 1] == null) {
                return i2;
            }
            i2++;
        }
        int i3 = b - 1;
        while (i3 >= 0 && this.f253d[i3] == 0) {
            if (this.f254e[i3 << 1] == null) {
                return i3;
            }
            i3--;
        }
        return i2 ^ -1;
    }

    public V get(Object obj) {
        return getOrDefault(obj, (Object) null);
    }

    public V getOrDefault(Object obj, V v) {
        int f = mo512f(obj);
        return f >= 0 ? this.f254e[(f << 1) + 1] : v;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public int mo516h(Object obj) {
        int i = this.f255f * 2;
        Object[] objArr = this.f254e;
        if (obj == null) {
            for (int i2 = 1; i2 < i; i2 += 2) {
                if (objArr[i2] == null) {
                    return i2 >> 1;
                }
            }
            return -1;
        }
        for (int i3 = 1; i3 < i; i3 += 2) {
            if (obj.equals(objArr[i3])) {
                return i3 >> 1;
            }
        }
        return -1;
    }

    public int hashCode() {
        int[] iArr = this.f253d;
        Object[] objArr = this.f254e;
        int i = this.f255f;
        int i2 = 1;
        int i3 = 0;
        int i4 = 0;
        while (i3 < i) {
            Object obj = objArr[i2];
            i4 += (obj == null ? 0 : obj.hashCode()) ^ iArr[i3];
            i3++;
            i2 += 2;
        }
        return i4;
    }

    /* renamed from: i */
    public K mo518i(int i) {
        return this.f254e[i << 1];
    }

    public boolean isEmpty() {
        return this.f255f <= 0;
    }

    /* renamed from: j */
    public V mo520j(int i) {
        V[] vArr = this.f254e;
        int i2 = i << 1;
        V v = vArr[i2 + 1];
        int i3 = this.f255f;
        int i4 = 0;
        if (i3 <= 1) {
            m365d(this.f253d, vArr, i3);
            this.f253d = C0097b.f231a;
            this.f254e = C0097b.f233c;
        } else {
            int i5 = i3 - 1;
            int[] iArr = this.f253d;
            int i6 = 8;
            if (iArr.length <= 8 || i3 >= iArr.length / 3) {
                if (i < i5) {
                    int i7 = i + 1;
                    int i8 = i5 - i;
                    System.arraycopy(iArr, i7, iArr, i, i8);
                    Object[] objArr = this.f254e;
                    System.arraycopy(objArr, i7 << 1, objArr, i2, i8 << 1);
                }
                Object[] objArr2 = this.f254e;
                int i9 = i5 << 1;
                objArr2[i9] = null;
                objArr2[i9 + 1] = null;
            } else {
                if (i3 > 8) {
                    i6 = i3 + (i3 >> 1);
                }
                m363a(i6);
                if (i3 == this.f255f) {
                    if (i > 0) {
                        System.arraycopy(iArr, 0, this.f253d, 0, i);
                        System.arraycopy(vArr, 0, this.f254e, 0, i2);
                    }
                    if (i < i5) {
                        int i10 = i + 1;
                        int i11 = i5 - i;
                        System.arraycopy(iArr, i10, this.f253d, i, i11);
                        System.arraycopy(vArr, i10 << 1, this.f254e, i2, i11 << 1);
                    }
                } else {
                    throw new ConcurrentModificationException();
                }
            }
            i4 = i5;
        }
        if (i3 == this.f255f) {
            this.f255f = i4;
            return v;
        }
        throw new ConcurrentModificationException();
    }

    /* renamed from: k */
    public V mo521k(int i, V v) {
        int i2 = (i << 1) + 1;
        V[] vArr = this.f254e;
        V v2 = vArr[i2];
        vArr[i2] = v;
        return v2;
    }

    /* renamed from: l */
    public V mo522l(int i) {
        return this.f254e[(i << 1) + 1];
    }

    public V put(K k, V v) {
        int i;
        int i2;
        int i3 = this.f255f;
        if (k == null) {
            i2 = mo513g();
            i = 0;
        } else {
            int hashCode = k.hashCode();
            i = hashCode;
            i2 = mo510e(k, hashCode);
        }
        if (i2 >= 0) {
            int i4 = (i2 << 1) + 1;
            V[] vArr = this.f254e;
            V v2 = vArr[i4];
            vArr[i4] = v;
            return v2;
        }
        int i5 = i2 ^ -1;
        int[] iArr = this.f253d;
        if (i3 >= iArr.length) {
            int i6 = 4;
            if (i3 >= 8) {
                i6 = (i3 >> 1) + i3;
            } else if (i3 >= 4) {
                i6 = 8;
            }
            Object[] objArr = this.f254e;
            m363a(i6);
            if (i3 == this.f255f) {
                int[] iArr2 = this.f253d;
                if (iArr2.length > 0) {
                    System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                    System.arraycopy(objArr, 0, this.f254e, 0, objArr.length);
                }
                m365d(iArr, objArr, i3);
            } else {
                throw new ConcurrentModificationException();
            }
        }
        if (i5 < i3) {
            int[] iArr3 = this.f253d;
            int i7 = i5 + 1;
            System.arraycopy(iArr3, i5, iArr3, i7, i3 - i5);
            Object[] objArr2 = this.f254e;
            System.arraycopy(objArr2, i5 << 1, objArr2, i7 << 1, (this.f255f - i5) << 1);
        }
        int i8 = this.f255f;
        if (i3 == i8) {
            int[] iArr4 = this.f253d;
            if (i5 < iArr4.length) {
                iArr4[i5] = i;
                Object[] objArr3 = this.f254e;
                int i9 = i5 << 1;
                objArr3[i9] = k;
                objArr3[i9 + 1] = v;
                this.f255f = i8 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }

    public V putIfAbsent(K k, V v) {
        V v2 = get(k);
        return v2 == null ? put(k, v) : v2;
    }

    public V remove(Object obj) {
        int f = mo512f(obj);
        if (f >= 0) {
            return mo520j(f);
        }
        return null;
    }

    public boolean remove(Object obj, Object obj2) {
        int f = mo512f(obj);
        if (f < 0) {
            return false;
        }
        Object l = mo522l(f);
        if (obj2 != l && (obj2 == null || !obj2.equals(l))) {
            return false;
        }
        mo520j(f);
        return true;
    }

    public V replace(K k, V v) {
        int f = mo512f(k);
        if (f >= 0) {
            return mo521k(f, v);
        }
        return null;
    }

    public boolean replace(K k, V v, V v2) {
        int f = mo512f(k);
        if (f < 0) {
            return false;
        }
        V l = mo522l(f);
        if (l != v && (v == null || !v.equals(l))) {
            return false;
        }
        mo521k(f, v2);
        return true;
    }

    public int size() {
        return this.f255f;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f255f * 28);
        sb.append('{');
        for (int i = 0; i < this.f255f; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            Object i2 = mo518i(i);
            if (i2 != this) {
                sb.append(i2);
            } else {
                sb.append("(this Map)");
            }
            sb.append('=');
            Object l = mo522l(i);
            if (l != this) {
                sb.append(l);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
