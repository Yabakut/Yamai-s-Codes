package p033p;

import android.content.Context;
import p020io.flutter.embedding.engine.C0276a;
import p020io.flutter.plugin.platform.C0321e;
import p020io.flutter.view.C0382d;
import p051y.C0839b;

/* renamed from: p.a */
public interface C0555a {

    /* renamed from: p.a$a */
    public interface C0556a {
    }

    /* renamed from: p.a$b */
    public static class C0557b {

        /* renamed from: a */
        private final Context f1189a;

        /* renamed from: b */
        private final C0276a f1190b;

        /* renamed from: c */
        private final C0839b f1191c;

        /* renamed from: d */
        private final C0382d f1192d;

        /* renamed from: e */
        private final C0321e f1193e;

        /* renamed from: f */
        private final C0556a f1194f;

        public C0557b(Context context, C0276a aVar, C0839b bVar, C0382d dVar, C0321e eVar, C0556a aVar2) {
            this.f1189a = context;
            this.f1190b = aVar;
            this.f1191c = bVar;
            this.f1192d = dVar;
            this.f1193e = eVar;
            this.f1194f = aVar2;
        }

        /* renamed from: a */
        public Context mo1516a() {
            return this.f1189a;
        }

        /* renamed from: b */
        public C0839b mo1517b() {
            return this.f1191c;
        }
    }

    /* renamed from: d */
    void mo429d(C0557b bVar);

    /* renamed from: e */
    void mo430e(C0557b bVar);
}
