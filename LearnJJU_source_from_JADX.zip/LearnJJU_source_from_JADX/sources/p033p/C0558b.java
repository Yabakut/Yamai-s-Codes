package p033p;

/* renamed from: p.b */
public interface C0558b {
    /* renamed from: j */
    void mo956j(C0555a aVar);
}
