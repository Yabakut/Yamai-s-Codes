package p040s0;

/* renamed from: s0.d */
public interface C0584d {
}
