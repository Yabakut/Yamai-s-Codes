package p040s0;

import java.util.List;
import java.util.Map;

/* renamed from: s0.b */
public interface C0582b<R> extends C0581a {
    R call(Object... objArr);

    R callBy(Map<Object, ? extends Object> map);

    List<Object> getParameters();

    C0586f getReturnType();

    List<Object> getTypeParameters();

    C0587g getVisibility();

    boolean isAbstract();

    boolean isFinal();

    boolean isOpen();

    boolean isSuspend();
}
