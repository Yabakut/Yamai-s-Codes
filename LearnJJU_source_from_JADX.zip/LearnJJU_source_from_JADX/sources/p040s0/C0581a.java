package p040s0;

import java.lang.annotation.Annotation;
import java.util.List;

/* renamed from: s0.a */
public interface C0581a {
    List<Annotation> getAnnotations();
}
