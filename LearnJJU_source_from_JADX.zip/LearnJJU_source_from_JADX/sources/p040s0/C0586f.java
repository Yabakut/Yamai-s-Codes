package p040s0;

/* renamed from: s0.f */
public interface C0586f extends C0581a {
}
