package p040s0;

/* renamed from: s0.g */
public enum C0587g {
    PUBLIC,
    PROTECTED,
    INTERNAL,
    PRIVATE
}
