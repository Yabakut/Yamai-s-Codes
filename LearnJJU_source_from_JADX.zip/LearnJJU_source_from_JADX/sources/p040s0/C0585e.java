package p040s0;

import p011e0.C0125c;

/* renamed from: s0.e */
public interface C0585e<R> extends C0582b<R>, C0125c<R> {
    boolean isExternal();

    boolean isInfix();

    boolean isInline();

    boolean isOperator();

    boolean isSuspend();
}
