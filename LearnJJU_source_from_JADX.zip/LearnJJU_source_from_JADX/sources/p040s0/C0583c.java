package p040s0;

/* renamed from: s0.c */
public interface C0583c<T> extends C0584d, C0581a {
    /* renamed from: a */
    String mo1323a();
}
