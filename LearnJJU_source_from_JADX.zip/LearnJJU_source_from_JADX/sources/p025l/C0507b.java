package p025l;

import java.nio.ByteBuffer;
import p025l.C0508c;

/* renamed from: l.b */
public final /* synthetic */ class C0507b implements Runnable {

    /* renamed from: d */
    public final /* synthetic */ C0508c f1127d;

    /* renamed from: e */
    public final /* synthetic */ String f1128e;

    /* renamed from: f */
    public final /* synthetic */ C0508c.C0512d f1129f;

    /* renamed from: g */
    public final /* synthetic */ ByteBuffer f1130g;

    /* renamed from: h */
    public final /* synthetic */ int f1131h;

    /* renamed from: i */
    public final /* synthetic */ long f1132i;

    public /* synthetic */ C0507b(C0508c cVar, String str, C0508c.C0512d dVar, ByteBuffer byteBuffer, int i, long j) {
        this.f1127d = cVar;
        this.f1128e = str;
        this.f1129f = dVar;
        this.f1130g = byteBuffer;
        this.f1131h = i;
        this.f1132i = j;
    }

    public final void run() {
        this.f1127d.m1776k(this.f1128e, this.f1129f, this.f1130g, this.f1131h, this.f1132i);
    }
}
