package p025l;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import p009d0.C0115e;
import p020io.flutter.embedding.engine.FlutterJNI;
import p023k.C0401a;
import p023k.C0405b;
import p051y.C0839b;

/* renamed from: l.c */
class C0508c implements C0839b, C0515d {

    /* renamed from: a */
    private final FlutterJNI f1133a;

    /* renamed from: b */
    private final Map<String, C0512d> f1134b;

    /* renamed from: c */
    private Map<String, List<C0509a>> f1135c;

    /* renamed from: d */
    private final Object f1136d;

    /* renamed from: e */
    private final AtomicBoolean f1137e;

    /* renamed from: f */
    private final Map<Integer, C0839b.C0841b> f1138f;

    /* renamed from: g */
    private int f1139g;

    /* renamed from: h */
    private final C0510b f1140h;

    /* renamed from: i */
    private WeakHashMap<C0839b.C0842c, C0510b> f1141i;

    /* renamed from: j */
    private C0514f f1142j;

    /* renamed from: l.c$a */
    private static class C0509a {

        /* renamed from: a */
        public final ByteBuffer f1143a;

        /* renamed from: b */
        int f1144b;

        /* renamed from: c */
        long f1145c;

        C0509a(ByteBuffer byteBuffer, int i, long j) {
            this.f1143a = byteBuffer;
            this.f1144b = i;
            this.f1145c = j;
        }
    }

    /* renamed from: l.c$b */
    interface C0510b {
        /* renamed from: a */
        void mo1490a(Runnable runnable);
    }

    /* renamed from: l.c$c */
    private static class C0511c implements C0514f {

        /* renamed from: a */
        ExecutorService f1146a = C0401a.m1455e().mo1284b();

        C0511c() {
        }
    }

    /* renamed from: l.c$d */
    private static class C0512d {

        /* renamed from: a */
        public final C0839b.C0840a f1147a;

        /* renamed from: b */
        public final C0510b f1148b;

        C0512d(C0839b.C0840a aVar, C0510b bVar) {
            this.f1147a = aVar;
            this.f1148b = bVar;
        }
    }

    /* renamed from: l.c$e */
    static class C0513e implements C0839b.C0841b {

        /* renamed from: a */
        private final FlutterJNI f1149a;

        /* renamed from: b */
        private final int f1150b;

        /* renamed from: c */
        private final AtomicBoolean f1151c = new AtomicBoolean(false);

        C0513e(FlutterJNI flutterJNI, int i) {
            this.f1149a = flutterJNI;
            this.f1150b = i;
        }

        /* renamed from: a */
        public void mo842a(ByteBuffer byteBuffer) {
            if (this.f1151c.getAndSet(true)) {
                throw new IllegalStateException("Reply already submitted");
            } else if (byteBuffer == null) {
                this.f1149a.invokePlatformMessageEmptyResponseCallback(this.f1150b);
            } else {
                this.f1149a.invokePlatformMessageResponseCallback(this.f1150b, byteBuffer, byteBuffer.position());
            }
        }
    }

    /* renamed from: l.c$f */
    interface C0514f {
    }

    C0508c(FlutterJNI flutterJNI) {
        this(flutterJNI, new C0511c());
    }

    C0508c(FlutterJNI flutterJNI, C0514f fVar) {
        this.f1134b = new HashMap();
        this.f1135c = new HashMap();
        this.f1136d = new Object();
        this.f1137e = new AtomicBoolean(false);
        this.f1138f = new HashMap();
        this.f1139g = 1;
        this.f1140h = new C0516e();
        this.f1141i = new WeakHashMap<>();
        this.f1133a = flutterJNI;
        this.f1142j = fVar;
    }

    /* renamed from: h */
    private void m1773h(String str, C0512d dVar, ByteBuffer byteBuffer, int i, long j) {
        C0512d dVar2 = dVar;
        C0510b bVar = dVar2 != null ? dVar2.f1148b : null;
        C0507b bVar2 = new C0507b(this, str, dVar, byteBuffer, i, j);
        if (bVar == null) {
            bVar = this.f1140h;
        }
        bVar.mo1490a(bVar2);
    }

    /* renamed from: i */
    private static void m1774i(Error error) {
        Thread currentThread = Thread.currentThread();
        if (currentThread.getUncaughtExceptionHandler() != null) {
            currentThread.getUncaughtExceptionHandler().uncaughtException(currentThread, error);
            return;
        }
        throw error;
    }

    /* renamed from: j */
    private void m1775j(C0512d dVar, ByteBuffer byteBuffer, int i) {
        if (dVar != null) {
            try {
                C0405b.m1466e("DartMessenger", "Deferring to registered handler to process message.");
                dVar.f1147a.mo1482a(byteBuffer, new C0513e(this.f1133a, i));
            } catch (Exception e) {
                C0405b.m1464c("DartMessenger", "Uncaught exception in binary message listener", e);
            } catch (Error e2) {
                m1774i(e2);
            }
        } else {
            C0405b.m1466e("DartMessenger", "No registered handler for message. Responding to Dart with empty reply message.");
            this.f1133a.invokePlatformMessageEmptyResponseCallback(i);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: k */
    public /* synthetic */ void m1776k(String str, C0512d dVar, ByteBuffer byteBuffer, int i, long j) {
        C0115e.m393a("DartMessenger#handleMessageFromDart on " + str);
        try {
            m1775j(dVar, byteBuffer, i);
            if (byteBuffer != null && byteBuffer.isDirect()) {
                byteBuffer.limit(0);
            }
        } finally {
            this.f1133a.cleanupMessageData(j);
            C0115e.m394b();
        }
    }

    /* renamed from: a */
    public void mo1472a(String str, ByteBuffer byteBuffer, C0839b.C0841b bVar) {
        C0115e.m393a("DartMessenger#send on " + str);
        try {
            C0405b.m1466e("DartMessenger", "Sending message with callback over channel '" + str + "'");
            int i = this.f1139g;
            this.f1139g = i + 1;
            if (bVar != null) {
                this.f1138f.put(Integer.valueOf(i), bVar);
            }
            if (byteBuffer == null) {
                this.f1133a.dispatchEmptyPlatformMessage(str, i);
            } else {
                this.f1133a.dispatchPlatformMessage(str, byteBuffer, byteBuffer.position(), i);
            }
        } finally {
            C0115e.m394b();
        }
    }

    /* renamed from: b */
    public void mo1488b(String str, ByteBuffer byteBuffer, int i, long j) {
        C0512d dVar;
        boolean z;
        C0405b.m1466e("DartMessenger", "Received message from Dart over channel '" + str + "'");
        synchronized (this.f1136d) {
            dVar = this.f1134b.get(str);
            z = this.f1137e.get() && dVar == null;
            if (z) {
                if (!this.f1135c.containsKey(str)) {
                    this.f1135c.put(str, new LinkedList());
                }
                this.f1135c.get(str).add(new C0509a(byteBuffer, i, j));
            }
        }
        if (!z) {
            m1773h(str, dVar, byteBuffer, i, j);
        }
    }

    /* renamed from: c */
    public void mo1473c(String str, ByteBuffer byteBuffer) {
        C0405b.m1466e("DartMessenger", "Sending message over channel '" + str + "'");
        mo1472a(str, byteBuffer, (C0839b.C0841b) null);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0076, code lost:
        r10 = r10.iterator();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x007e, code lost:
        if (r10.hasNext() == false) goto L_0x009b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0080, code lost:
        r11 = (p025l.C0508c.C0509a) r10.next();
        m1773h(r9, r8.f1134b.get(r9), r11.f1143a, r11.f1144b, r11.f1145c);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x009b, code lost:
        return;
     */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1474d(java.lang.String r9, p051y.C0839b.C0840a r10, p051y.C0839b.C0842c r11) {
        /*
            r8 = this;
            if (r10 != 0) goto L_0x002a
            java.lang.String r10 = "DartMessenger"
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r11.<init>()
            java.lang.String r0 = "Removing handler for channel '"
            r11.append(r0)
            r11.append(r9)
            java.lang.String r0 = "'"
            r11.append(r0)
            java.lang.String r11 = r11.toString()
            p023k.C0405b.m1466e(r10, r11)
            java.lang.Object r0 = r8.f1136d
            monitor-enter(r0)
            java.util.Map<java.lang.String, l.c$d> r10 = r8.f1134b     // Catch:{ all -> 0x0027 }
            r10.remove(r9)     // Catch:{ all -> 0x0027 }
            monitor-exit(r0)     // Catch:{ all -> 0x0027 }
            return
        L_0x0027:
            r9 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0027 }
            throw r9
        L_0x002a:
            r0 = 0
            if (r11 == 0) goto L_0x0041
            java.util.WeakHashMap<y.b$c, l.c$b> r0 = r8.f1141i
            java.lang.Object r11 = r0.get(r11)
            r0 = r11
            l.c$b r0 = (p025l.C0508c.C0510b) r0
            if (r0 == 0) goto L_0x0039
            goto L_0x0041
        L_0x0039:
            java.lang.IllegalArgumentException r9 = new java.lang.IllegalArgumentException
            java.lang.String r10 = "Unrecognized TaskQueue, use BinaryMessenger to create your TaskQueue (ex makeBackgroundTaskQueue)."
            r9.<init>(r10)
            throw r9
        L_0x0041:
            java.lang.String r11 = "DartMessenger"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Setting handler for channel '"
            r1.append(r2)
            r1.append(r9)
            java.lang.String r2 = "'"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            p023k.C0405b.m1466e(r11, r1)
            java.lang.Object r11 = r8.f1136d
            monitor-enter(r11)
            java.util.Map<java.lang.String, l.c$d> r1 = r8.f1134b     // Catch:{ all -> 0x009c }
            l.c$d r2 = new l.c$d     // Catch:{ all -> 0x009c }
            r2.<init>(r10, r0)     // Catch:{ all -> 0x009c }
            r1.put(r9, r2)     // Catch:{ all -> 0x009c }
            java.util.Map<java.lang.String, java.util.List<l.c$a>> r10 = r8.f1135c     // Catch:{ all -> 0x009c }
            java.lang.Object r10 = r10.remove(r9)     // Catch:{ all -> 0x009c }
            java.util.List r10 = (java.util.List) r10     // Catch:{ all -> 0x009c }
            if (r10 != 0) goto L_0x0075
            monitor-exit(r11)     // Catch:{ all -> 0x009c }
            return
        L_0x0075:
            monitor-exit(r11)     // Catch:{ all -> 0x009c }
            java.util.Iterator r10 = r10.iterator()
        L_0x007a:
            boolean r11 = r10.hasNext()
            if (r11 == 0) goto L_0x009b
            java.lang.Object r11 = r10.next()
            l.c$a r11 = (p025l.C0508c.C0509a) r11
            java.util.Map<java.lang.String, l.c$d> r0 = r8.f1134b
            java.lang.Object r0 = r0.get(r9)
            r3 = r0
            l.c$d r3 = (p025l.C0508c.C0512d) r3
            java.nio.ByteBuffer r4 = r11.f1143a
            int r5 = r11.f1144b
            long r6 = r11.f1145c
            r1 = r8
            r2 = r9
            r1.m1773h(r2, r3, r4, r5, r6)
            goto L_0x007a
        L_0x009b:
            return
        L_0x009c:
            r9 = move-exception
            monitor-exit(r11)     // Catch:{ all -> 0x009c }
            goto L_0x00a0
        L_0x009f:
            throw r9
        L_0x00a0:
            goto L_0x009f
        */
        throw new UnsupportedOperationException("Method not decompiled: p025l.C0508c.mo1474d(java.lang.String, y.b$a, y.b$c):void");
    }

    /* renamed from: e */
    public void mo1475e(String str, C0839b.C0840a aVar) {
        mo1474d(str, aVar, (C0839b.C0842c) null);
    }

    /* renamed from: f */
    public void mo1489f(int i, ByteBuffer byteBuffer) {
        C0405b.m1466e("DartMessenger", "Received message reply from Dart.");
        C0839b.C0841b remove = this.f1138f.remove(Integer.valueOf(i));
        if (remove != null) {
            try {
                C0405b.m1466e("DartMessenger", "Invoking registered callback for reply from Dart.");
                remove.mo842a(byteBuffer);
                if (byteBuffer != null && byteBuffer.isDirect()) {
                    byteBuffer.limit(0);
                }
            } catch (Exception e) {
                C0405b.m1464c("DartMessenger", "Uncaught exception in binary message reply handler", e);
            } catch (Error e2) {
                m1774i(e2);
            }
        }
    }
}
