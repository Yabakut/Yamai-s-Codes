package p025l;

import android.content.res.AssetManager;
import java.nio.ByteBuffer;
import java.util.List;
import p009d0.C0115e;
import p020io.flutter.embedding.engine.FlutterJNI;
import p023k.C0405b;
import p051y.C0839b;
import p051y.C0870s;

/* renamed from: l.a */
public class C0502a implements C0839b {

    /* renamed from: a */
    private final FlutterJNI f1114a;

    /* renamed from: b */
    private final AssetManager f1115b;

    /* renamed from: c */
    private final C0508c f1116c;

    /* renamed from: d */
    private final C0839b f1117d;

    /* renamed from: e */
    private boolean f1118e = false;
    /* access modifiers changed from: private */

    /* renamed from: f */
    public String f1119f;
    /* access modifiers changed from: private */

    /* renamed from: g */
    public C0506d f1120g;

    /* renamed from: h */
    private final C0839b.C0840a f1121h;

    /* renamed from: l.a$a */
    class C0503a implements C0839b.C0840a {
        C0503a() {
        }

        /* renamed from: a */
        public void mo1482a(ByteBuffer byteBuffer, C0839b.C0841b bVar) {
            String unused = C0502a.this.f1119f = C0870s.f1652b.mo1834a(byteBuffer);
            if (C0502a.this.f1120g != null) {
                C0502a.this.f1120g.mo1486a(C0502a.this.f1119f);
            }
        }
    }

    /* renamed from: l.a$b */
    public static class C0504b {

        /* renamed from: a */
        public final String f1123a;

        /* renamed from: b */
        public final String f1124b;

        /* renamed from: c */
        public final String f1125c;

        public C0504b(String str, String str2) {
            this.f1123a = str;
            this.f1124b = null;
            this.f1125c = str2;
        }

        public C0504b(String str, String str2, String str3) {
            this.f1123a = str;
            this.f1124b = str2;
            this.f1125c = str3;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            C0504b bVar = (C0504b) obj;
            if (!this.f1123a.equals(bVar.f1123a)) {
                return false;
            }
            return this.f1125c.equals(bVar.f1125c);
        }

        public int hashCode() {
            return (this.f1123a.hashCode() * 31) + this.f1125c.hashCode();
        }

        public String toString() {
            return "DartEntrypoint( bundle path: " + this.f1123a + ", function: " + this.f1125c + " )";
        }
    }

    /* renamed from: l.a$c */
    private static class C0505c implements C0839b {

        /* renamed from: a */
        private final C0508c f1126a;

        private C0505c(C0508c cVar) {
            this.f1126a = cVar;
        }

        /* synthetic */ C0505c(C0508c cVar, C0503a aVar) {
            this(cVar);
        }

        /* renamed from: a */
        public void mo1472a(String str, ByteBuffer byteBuffer, C0839b.C0841b bVar) {
            this.f1126a.mo1472a(str, byteBuffer, bVar);
        }

        /* renamed from: c */
        public void mo1473c(String str, ByteBuffer byteBuffer) {
            this.f1126a.mo1472a(str, byteBuffer, (C0839b.C0841b) null);
        }

        /* renamed from: d */
        public void mo1474d(String str, C0839b.C0840a aVar, C0839b.C0842c cVar) {
            this.f1126a.mo1474d(str, aVar, cVar);
        }

        /* renamed from: e */
        public void mo1475e(String str, C0839b.C0840a aVar) {
            this.f1126a.mo1475e(str, aVar);
        }
    }

    /* renamed from: l.a$d */
    public interface C0506d {
        /* renamed from: a */
        void mo1486a(String str);
    }

    public C0502a(FlutterJNI flutterJNI, AssetManager assetManager) {
        C0503a aVar = new C0503a();
        this.f1121h = aVar;
        this.f1114a = flutterJNI;
        this.f1115b = assetManager;
        C0508c cVar = new C0508c(flutterJNI);
        this.f1116c = cVar;
        cVar.mo1475e("flutter/isolate", aVar);
        this.f1117d = new C0505c(cVar, (C0503a) null);
        if (flutterJNI.isAttached()) {
            this.f1118e = true;
        }
    }

    @Deprecated
    /* renamed from: a */
    public void mo1472a(String str, ByteBuffer byteBuffer, C0839b.C0841b bVar) {
        this.f1117d.mo1472a(str, byteBuffer, bVar);
    }

    @Deprecated
    /* renamed from: c */
    public void mo1473c(String str, ByteBuffer byteBuffer) {
        this.f1117d.mo1473c(str, byteBuffer);
    }

    @Deprecated
    /* renamed from: d */
    public void mo1474d(String str, C0839b.C0840a aVar, C0839b.C0842c cVar) {
        this.f1117d.mo1474d(str, aVar, cVar);
    }

    @Deprecated
    /* renamed from: e */
    public void mo1475e(String str, C0839b.C0840a aVar) {
        this.f1117d.mo1475e(str, aVar);
    }

    /* renamed from: h */
    public void mo1476h(C0504b bVar, List<String> list) {
        if (this.f1118e) {
            C0405b.m1467f("DartExecutor", "Attempted to run a DartExecutor that is already running.");
            return;
        }
        C0115e.m393a("DartExecutor#executeDartEntrypoint");
        try {
            C0405b.m1466e("DartExecutor", "Executing Dart entrypoint: " + bVar);
            this.f1114a.runBundleAndSnapshotFromLibrary(bVar.f1123a, bVar.f1125c, bVar.f1124b, this.f1115b, list);
            this.f1118e = true;
        } finally {
            C0115e.m394b();
        }
    }

    /* renamed from: i */
    public String mo1477i() {
        return this.f1119f;
    }

    /* renamed from: j */
    public boolean mo1478j() {
        return this.f1118e;
    }

    /* renamed from: k */
    public void mo1479k() {
        if (this.f1114a.isAttached()) {
            this.f1114a.notifyLowMemoryWarning();
        }
    }

    /* renamed from: l */
    public void mo1480l() {
        C0405b.m1466e("DartExecutor", "Attached to JNI. Registering the platform message handler for this Dart execution context.");
        this.f1114a.setPlatformMessageHandler(this.f1116c);
    }

    /* renamed from: m */
    public void mo1481m() {
        C0405b.m1466e("DartExecutor", "Detached from JNI. De-registering the platform message handler for this Dart execution context.");
        this.f1114a.setPlatformMessageHandler((C0515d) null);
    }
}
