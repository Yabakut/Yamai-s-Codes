package p025l;

import java.nio.ByteBuffer;

/* renamed from: l.d */
public interface C0515d {
    /* renamed from: b */
    void mo1488b(String str, ByteBuffer byteBuffer, int i, long j);

    /* renamed from: f */
    void mo1489f(int i, ByteBuffer byteBuffer);
}
