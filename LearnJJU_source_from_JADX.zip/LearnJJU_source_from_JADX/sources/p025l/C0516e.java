package p025l;

import android.os.Handler;
import android.os.Looper;
import p009d0.C0111a;
import p025l.C0508c;

/* renamed from: l.e */
public class C0516e implements C0508c.C0510b {

    /* renamed from: a */
    private final Handler f1152a = C0111a.m387a(Looper.getMainLooper());

    /* renamed from: a */
    public void mo1490a(Runnable runnable) {
        this.f1152a.post(runnable);
    }
}
