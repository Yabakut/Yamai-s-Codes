package p045v;

import p020io.flutter.embedding.engine.C0276a;
import p020io.flutter.plugins.GeneratedPluginRegistrant;
import p023k.C0405b;

/* renamed from: v.a */
public class C0623a {
    /* renamed from: a */
    public static void m1986a(C0276a aVar) {
        try {
            GeneratedPluginRegistrant.class.getDeclaredMethod("registerWith", new Class[]{C0276a.class}).invoke((Object) null, new Object[]{aVar});
        } catch (Exception e) {
            C0405b.m1463b("GeneratedPluginsRegister", "Tried to automatically register plugins with FlutterEngine (" + aVar + ") but could not find or invoke the GeneratedPluginRegistrant.");
            C0405b.m1464c("GeneratedPluginsRegister", "Received exception while registering", e);
        }
    }
}
