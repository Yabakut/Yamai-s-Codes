package p024k0;

import kotlin.jvm.internal.C0429i;
import p022j0.C0397a;

/* renamed from: k0.a */
public class C0406a extends C0397a {
    /* renamed from: a */
    public void mo1281a(Throwable th, Throwable th2) {
        C0429i.m1496d(th, "cause");
        C0429i.m1496d(th2, "exception");
    }
}
