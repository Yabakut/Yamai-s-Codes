package p027m;

import p020io.flutter.embedding.engine.FlutterJNI;
import p049x.C0746b;

/* renamed from: m.a */
public interface C0518a {
    /* renamed from: a */
    void mo1491a(C0746b bVar);

    /* renamed from: b */
    String mo1492b(int i, String str);

    /* renamed from: c */
    void mo1493c(int i, String str);

    /* renamed from: d */
    boolean mo1494d(int i, String str);

    /* renamed from: e */
    void mo1495e();

    /* renamed from: f */
    void mo1496f(FlutterJNI flutterJNI);
}
