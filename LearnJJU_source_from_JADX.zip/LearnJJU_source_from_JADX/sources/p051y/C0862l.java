package p051y;

import android.content.Intent;

/* renamed from: y.l */
public interface C0862l {
    /* renamed from: c */
    boolean mo1220c(int i, int i2, Intent intent);
}
