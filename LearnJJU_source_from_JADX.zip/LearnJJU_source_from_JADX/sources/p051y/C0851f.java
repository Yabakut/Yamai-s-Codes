package p051y;

import java.nio.ByteBuffer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: y.f */
public final class C0851f implements C0861k {

    /* renamed from: a */
    public static final C0851f f1633a = new C0851f();

    private C0851f() {
    }

    /* renamed from: a */
    public ByteBuffer mo1836a(String str, String str2, Object obj, String str3) {
        return C0850e.f1632a.mo1835b(new JSONArray().put(str).put(C0852g.m2661a(str2)).put(C0852g.m2661a(obj)).put(C0852g.m2661a(str3)));
    }

    /* renamed from: b */
    public ByteBuffer mo1837b(C0854i iVar) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("method", iVar.f1634a);
            jSONObject.put("args", C0852g.m2661a(iVar.f1635b));
            return C0850e.f1632a.mo1835b(jSONObject);
        } catch (JSONException e) {
            throw new IllegalArgumentException("Invalid JSON", e);
        }
    }

    /* renamed from: c */
    public ByteBuffer mo1838c(String str, String str2, Object obj) {
        return C0850e.f1632a.mo1835b(new JSONArray().put(str).put(C0852g.m2661a(str2)).put(C0852g.m2661a(obj)));
    }

    /* renamed from: d */
    public ByteBuffer mo1839d(Object obj) {
        return C0850e.f1632a.mo1835b(new JSONArray().put(C0852g.m2661a(obj)));
    }

    /* renamed from: e */
    public C0854i mo1840e(ByteBuffer byteBuffer) {
        try {
            Object a = C0850e.f1632a.mo1834a(byteBuffer);
            if (a instanceof JSONObject) {
                JSONObject jSONObject = (JSONObject) a;
                Object obj = jSONObject.get("method");
                Object g = mo1842g(jSONObject.opt("args"));
                if (obj instanceof String) {
                    return new C0854i((String) obj, g);
                }
            }
            throw new IllegalArgumentException("Invalid method call: " + a);
        } catch (JSONException e) {
            throw new IllegalArgumentException("Invalid JSON", e);
        }
    }

    /* renamed from: f */
    public Object mo1841f(ByteBuffer byteBuffer) {
        try {
            Object a = C0850e.f1632a.mo1834a(byteBuffer);
            if (a instanceof JSONArray) {
                JSONArray jSONArray = (JSONArray) a;
                if (jSONArray.length() == 1) {
                    return mo1842g(jSONArray.opt(0));
                }
                if (jSONArray.length() == 3) {
                    Object obj = jSONArray.get(0);
                    Object g = mo1842g(jSONArray.opt(1));
                    Object g2 = mo1842g(jSONArray.opt(2));
                    if ((obj instanceof String) && (g == null || (g instanceof String))) {
                        throw new C0849d((String) obj, (String) g, g2);
                    }
                }
            }
            throw new IllegalArgumentException("Invalid envelope: " + a);
        } catch (JSONException e) {
            throw new IllegalArgumentException("Invalid JSON", e);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public Object mo1842g(Object obj) {
        if (obj == JSONObject.NULL) {
            return null;
        }
        return obj;
    }
}
