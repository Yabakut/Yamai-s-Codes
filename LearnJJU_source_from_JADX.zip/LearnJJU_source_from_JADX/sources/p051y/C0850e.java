package p051y;

import java.nio.ByteBuffer;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

/* renamed from: y.e */
public final class C0850e implements C0853h<Object> {

    /* renamed from: a */
    public static final C0850e f1632a = new C0850e();

    private C0850e() {
    }

    /* renamed from: a */
    public Object mo1834a(ByteBuffer byteBuffer) {
        if (byteBuffer == null) {
            return null;
        }
        try {
            JSONTokener jSONTokener = new JSONTokener(C0870s.f1652b.mo1834a(byteBuffer));
            Object nextValue = jSONTokener.nextValue();
            if (!jSONTokener.more()) {
                return nextValue;
            }
            throw new IllegalArgumentException("Invalid JSON");
        } catch (JSONException e) {
            throw new IllegalArgumentException("Invalid JSON", e);
        }
    }

    /* renamed from: b */
    public ByteBuffer mo1835b(Object obj) {
        C0870s sVar;
        String obj2;
        if (obj == null) {
            return null;
        }
        Object a = C0852g.m2661a(obj);
        if (a instanceof String) {
            sVar = C0870s.f1652b;
            obj2 = JSONObject.quote((String) a);
        } else {
            sVar = C0870s.f1652b;
            obj2 = a.toString();
        }
        return sVar.mo1835b(obj2);
    }
}
