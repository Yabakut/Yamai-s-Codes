package p051y;

/* renamed from: y.p */
public interface C0866p {
    /* renamed from: f */
    void mo1851f();
}
