package p051y;

import java.nio.ByteBuffer;

/* renamed from: y.b */
public interface C0839b {

    /* renamed from: y.b$a */
    public interface C0840a {
        /* renamed from: a */
        void mo1482a(ByteBuffer byteBuffer, C0841b bVar);
    }

    /* renamed from: y.b$b */
    public interface C0841b {
        /* renamed from: a */
        void mo842a(ByteBuffer byteBuffer);
    }

    /* renamed from: y.b$c */
    public interface C0842c {
    }

    /* renamed from: a */
    void mo1472a(String str, ByteBuffer byteBuffer, C0841b bVar);

    /* renamed from: c */
    void mo1473c(String str, ByteBuffer byteBuffer);

    /* renamed from: d */
    void mo1474d(String str, C0840a aVar, C0842c cVar);

    /* renamed from: e */
    void mo1475e(String str, C0840a aVar);
}
