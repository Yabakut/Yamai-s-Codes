package p051y;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import p051y.C0867q;

/* renamed from: y.r */
public final class C0869r implements C0861k {

    /* renamed from: b */
    public static final C0869r f1649b = new C0869r(C0867q.f1646a);

    /* renamed from: a */
    private final C0867q f1650a;

    public C0869r(C0867q qVar) {
        this.f1650a = qVar;
    }

    /* renamed from: g */
    private static String m2710g(Throwable th) {
        StringWriter stringWriter = new StringWriter();
        th.printStackTrace(new PrintWriter(stringWriter));
        return stringWriter.toString();
    }

    /* renamed from: a */
    public ByteBuffer mo1836a(String str, String str2, Object obj, String str3) {
        C0867q.C0868a aVar = new C0867q.C0868a();
        aVar.write(1);
        this.f1650a.mo1854p(aVar, str);
        this.f1650a.mo1854p(aVar, str2);
        if (obj instanceof Throwable) {
            this.f1650a.mo1854p(aVar, m2710g((Throwable) obj));
        } else {
            this.f1650a.mo1854p(aVar, obj);
        }
        this.f1650a.mo1854p(aVar, str3);
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(aVar.size());
        allocateDirect.put(aVar.mo1855a(), 0, aVar.size());
        return allocateDirect;
    }

    /* renamed from: b */
    public ByteBuffer mo1837b(C0854i iVar) {
        C0867q.C0868a aVar = new C0867q.C0868a();
        this.f1650a.mo1854p(aVar, iVar.f1634a);
        this.f1650a.mo1854p(aVar, iVar.f1635b);
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(aVar.size());
        allocateDirect.put(aVar.mo1855a(), 0, aVar.size());
        return allocateDirect;
    }

    /* renamed from: c */
    public ByteBuffer mo1838c(String str, String str2, Object obj) {
        C0867q.C0868a aVar = new C0867q.C0868a();
        aVar.write(1);
        this.f1650a.mo1854p(aVar, str);
        this.f1650a.mo1854p(aVar, str2);
        if (obj instanceof Throwable) {
            this.f1650a.mo1854p(aVar, m2710g((Throwable) obj));
        } else {
            this.f1650a.mo1854p(aVar, obj);
        }
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(aVar.size());
        allocateDirect.put(aVar.mo1855a(), 0, aVar.size());
        return allocateDirect;
    }

    /* renamed from: d */
    public ByteBuffer mo1839d(Object obj) {
        C0867q.C0868a aVar = new C0867q.C0868a();
        aVar.write(0);
        this.f1650a.mo1854p(aVar, obj);
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(aVar.size());
        allocateDirect.put(aVar.mo1855a(), 0, aVar.size());
        return allocateDirect;
    }

    /* renamed from: e */
    public C0854i mo1840e(ByteBuffer byteBuffer) {
        byteBuffer.order(ByteOrder.nativeOrder());
        Object f = this.f1650a.mo1852f(byteBuffer);
        Object f2 = this.f1650a.mo1852f(byteBuffer);
        if ((f instanceof String) && !byteBuffer.hasRemaining()) {
            return new C0854i((String) f, f2);
        }
        throw new IllegalArgumentException("Method call corrupted");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x000e, code lost:
        if (r0 == 1) goto L_0x001e;
     */
    /* renamed from: f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object mo1841f(java.nio.ByteBuffer r5) {
        /*
            r4 = this;
            java.nio.ByteOrder r0 = java.nio.ByteOrder.nativeOrder()
            r5.order(r0)
            byte r0 = r5.get()
            if (r0 == 0) goto L_0x0011
            r1 = 1
            if (r0 != r1) goto L_0x004a
            goto L_0x001e
        L_0x0011:
            y.q r0 = r4.f1650a
            java.lang.Object r0 = r0.mo1852f(r5)
            boolean r1 = r5.hasRemaining()
            if (r1 != 0) goto L_0x001e
            return r0
        L_0x001e:
            y.q r0 = r4.f1650a
            java.lang.Object r0 = r0.mo1852f(r5)
            y.q r1 = r4.f1650a
            java.lang.Object r1 = r1.mo1852f(r5)
            y.q r2 = r4.f1650a
            java.lang.Object r2 = r2.mo1852f(r5)
            boolean r3 = r0 instanceof java.lang.String
            if (r3 == 0) goto L_0x004a
            if (r1 == 0) goto L_0x003a
            boolean r3 = r1 instanceof java.lang.String
            if (r3 == 0) goto L_0x004a
        L_0x003a:
            boolean r5 = r5.hasRemaining()
            if (r5 != 0) goto L_0x004a
            y.d r5 = new y.d
            java.lang.String r0 = (java.lang.String) r0
            java.lang.String r1 = (java.lang.String) r1
            r5.<init>(r0, r1, r2)
            throw r5
        L_0x004a:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Envelope corrupted"
            r5.<init>(r0)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: p051y.C0869r.mo1841f(java.nio.ByteBuffer):java.lang.Object");
    }
}
