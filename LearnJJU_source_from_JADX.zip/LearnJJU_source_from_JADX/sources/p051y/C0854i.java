package p051y;

import java.util.Map;
import org.json.JSONObject;

/* renamed from: y.i */
public final class C0854i {

    /* renamed from: a */
    public final String f1634a;

    /* renamed from: b */
    public final Object f1635b;

    public C0854i(String str, Object obj) {
        this.f1634a = str;
        this.f1635b = obj;
    }

    /* renamed from: a */
    public <T> T mo1843a(String str) {
        Object obj = this.f1635b;
        if (obj == null) {
            return null;
        }
        if (obj instanceof Map) {
            return ((Map) obj).get(str);
        }
        if (obj instanceof JSONObject) {
            return ((JSONObject) obj).opt(str);
        }
        throw new ClassCastException();
    }

    /* renamed from: b */
    public <T> T mo1844b() {
        return this.f1635b;
    }
}
