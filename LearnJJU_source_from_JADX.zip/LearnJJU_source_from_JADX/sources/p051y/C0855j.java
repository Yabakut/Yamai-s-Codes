package p051y;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import p023k.C0405b;
import p051y.C0839b;

/* renamed from: y.j */
public class C0855j {

    /* renamed from: a */
    private final C0839b f1636a;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public final String f1637b;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public final C0861k f1638c;

    /* renamed from: d */
    private final C0839b.C0842c f1639d;

    /* renamed from: y.j$a */
    private final class C0856a implements C0839b.C0840a {

        /* renamed from: a */
        private final C0859c f1640a;

        /* renamed from: y.j$a$a */
        class C0857a implements C0860d {

            /* renamed from: a */
            final /* synthetic */ C0839b.C0841b f1642a;

            C0857a(C0839b.C0841b bVar) {
                this.f1642a = bVar;
            }

            /* renamed from: a */
            public void mo1199a(Object obj) {
                this.f1642a.mo842a(C0855j.this.f1638c.mo1839d(obj));
            }

            /* renamed from: b */
            public void mo1200b(String str, String str2, Object obj) {
                this.f1642a.mo842a(C0855j.this.f1638c.mo1838c(str, str2, obj));
            }

            /* renamed from: c */
            public void mo1201c() {
                this.f1642a.mo842a((ByteBuffer) null);
            }
        }

        C0856a(C0859c cVar) {
            this.f1640a = cVar;
        }

        /* renamed from: b */
        private String m2671b(Exception exc) {
            StringWriter stringWriter = new StringWriter();
            exc.printStackTrace(new PrintWriter(stringWriter));
            return stringWriter.toString();
        }

        /* renamed from: a */
        public void mo1482a(ByteBuffer byteBuffer, C0839b.C0841b bVar) {
            try {
                this.f1640a.mo531b(C0855j.this.f1638c.mo1840e(byteBuffer), new C0857a(bVar));
            } catch (RuntimeException e) {
                C0405b.m1464c("MethodChannel#" + C0855j.this.f1637b, "Failed to handle method call", e);
                bVar.mo842a(C0855j.this.f1638c.mo1836a("error", e.getMessage(), (Object) null, m2671b(e)));
            }
        }
    }

    /* renamed from: y.j$b */
    private final class C0858b implements C0839b.C0841b {

        /* renamed from: a */
        private final C0860d f1644a;

        C0858b(C0860d dVar) {
            this.f1644a = dVar;
        }

        /* renamed from: a */
        public void mo842a(ByteBuffer byteBuffer) {
            if (byteBuffer == null) {
                try {
                    this.f1644a.mo1201c();
                } catch (RuntimeException e) {
                    C0405b.m1464c("MethodChannel#" + C0855j.this.f1637b, "Failed to handle method call result", e);
                }
            } else {
                try {
                    this.f1644a.mo1199a(C0855j.this.f1638c.mo1841f(byteBuffer));
                } catch (C0849d e2) {
                    this.f1644a.mo1200b(e2.f1630d, e2.getMessage(), e2.f1631e);
                }
            }
        }
    }

    /* renamed from: y.j$c */
    public interface C0859c {
        /* renamed from: b */
        void mo531b(C0854i iVar, C0860d dVar);
    }

    /* renamed from: y.j$d */
    public interface C0860d {
        /* renamed from: a */
        void mo1199a(Object obj);

        /* renamed from: b */
        void mo1200b(String str, String str2, Object obj);

        /* renamed from: c */
        void mo1201c();
    }

    public C0855j(C0839b bVar, String str) {
        this(bVar, str, C0869r.f1649b);
    }

    public C0855j(C0839b bVar, String str, C0861k kVar) {
        this(bVar, str, kVar, (C0839b.C0842c) null);
    }

    public C0855j(C0839b bVar, String str, C0861k kVar, C0839b.C0842c cVar) {
        this.f1636a = bVar;
        this.f1637b = str;
        this.f1638c = kVar;
        this.f1639d = cVar;
    }

    /* renamed from: c */
    public void mo1845c(String str, Object obj) {
        mo1846d(str, obj, (C0860d) null);
    }

    /* renamed from: d */
    public void mo1846d(String str, Object obj, C0860d dVar) {
        this.f1636a.mo1472a(this.f1637b, this.f1638c.mo1837b(new C0854i(str, obj)), dVar == null ? null : new C0858b(dVar));
    }

    /* renamed from: e */
    public void mo1847e(C0859c cVar) {
        C0856a aVar = null;
        if (this.f1639d != null) {
            C0839b bVar = this.f1636a;
            String str = this.f1637b;
            if (cVar != null) {
                aVar = new C0856a(cVar);
            }
            bVar.mo1474d(str, aVar, this.f1639d);
            return;
        }
        C0839b bVar2 = this.f1636a;
        String str2 = this.f1637b;
        if (cVar != null) {
            aVar = new C0856a(cVar);
        }
        bVar2.mo1475e(str2, aVar);
    }
}
