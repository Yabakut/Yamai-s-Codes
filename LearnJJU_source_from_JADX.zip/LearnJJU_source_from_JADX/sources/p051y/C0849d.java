package p051y;

/* renamed from: y.d */
public class C0849d extends RuntimeException {

    /* renamed from: d */
    public final String f1630d;

    /* renamed from: e */
    public final Object f1631e;

    C0849d(String str, String str2, Object obj) {
        super(str2);
        this.f1630d = str;
        this.f1631e = obj;
    }
}
