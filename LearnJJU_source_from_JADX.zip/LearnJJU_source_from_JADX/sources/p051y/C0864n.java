package p051y;

@Deprecated
/* renamed from: y.n */
public interface C0864n {
    /* renamed from: c */
    C0864n mo1849c(C0862l lVar);

    /* renamed from: d */
    C0864n mo1850d(C0865o oVar);
}
