package p051y;

import java.nio.ByteBuffer;
import p023k.C0405b;
import p051y.C0839b;

/* renamed from: y.a */
public final class C0832a<T> {

    /* renamed from: a */
    private final C0839b f1611a;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public final String f1612b;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public final C0853h<T> f1613c;

    /* renamed from: d */
    private final C0839b.C0842c f1614d;

    /* renamed from: y.a$b */
    private final class C0834b implements C0839b.C0840a {

        /* renamed from: a */
        private final C0837d<T> f1615a;

        /* renamed from: y.a$b$a */
        class C0835a implements C0838e<T> {

            /* renamed from: a */
            final /* synthetic */ C0839b.C0841b f1617a;

            C0835a(C0839b.C0841b bVar) {
                this.f1617a = bVar;
            }

            /* renamed from: a */
            public void mo1739a(T t) {
                this.f1617a.mo842a(C0832a.this.f1613c.mo1835b(t));
            }
        }

        private C0834b(C0837d<T> dVar) {
            this.f1615a = dVar;
        }

        /* renamed from: a */
        public void mo1482a(ByteBuffer byteBuffer, C0839b.C0841b bVar) {
            try {
                this.f1615a.mo1737a(C0832a.this.f1613c.mo1834a(byteBuffer), new C0835a(bVar));
            } catch (RuntimeException e) {
                C0405b.m1464c("BasicMessageChannel#" + C0832a.this.f1612b, "Failed to handle message", e);
                bVar.mo842a((ByteBuffer) null);
            }
        }
    }

    /* renamed from: y.a$c */
    private final class C0836c implements C0839b.C0841b {

        /* renamed from: a */
        private final C0838e<T> f1619a;

        private C0836c(C0838e<T> eVar) {
            this.f1619a = eVar;
        }

        /* renamed from: a */
        public void mo842a(ByteBuffer byteBuffer) {
            try {
                this.f1619a.mo1739a(C0832a.this.f1613c.mo1834a(byteBuffer));
            } catch (RuntimeException e) {
                C0405b.m1464c("BasicMessageChannel#" + C0832a.this.f1612b, "Failed to handle message reply", e);
            }
        }
    }

    /* renamed from: y.a$d */
    public interface C0837d<T> {
        /* renamed from: a */
        void mo1737a(T t, C0838e<T> eVar);
    }

    /* renamed from: y.a$e */
    public interface C0838e<T> {
        /* renamed from: a */
        void mo1739a(T t);
    }

    public C0832a(C0839b bVar, String str, C0853h<T> hVar) {
        this(bVar, str, hVar, (C0839b.C0842c) null);
    }

    public C0832a(C0839b bVar, String str, C0853h<T> hVar, C0839b.C0842c cVar) {
        this.f1611a = bVar;
        this.f1612b = str;
        this.f1613c = hVar;
        this.f1614d = cVar;
    }

    /* renamed from: c */
    public void mo1829c(T t) {
        mo1830d(t, (C0838e) null);
    }

    /* renamed from: d */
    public void mo1830d(T t, C0838e<T> eVar) {
        C0839b bVar = this.f1611a;
        String str = this.f1612b;
        ByteBuffer b = this.f1613c.mo1835b(t);
        C0836c cVar = null;
        if (eVar != null) {
            cVar = new C0836c(eVar);
        }
        bVar.mo1472a(str, b, cVar);
    }

    /* renamed from: e */
    public void mo1831e(C0837d<T> dVar) {
        C0834b bVar = null;
        if (this.f1614d != null) {
            C0839b bVar2 = this.f1611a;
            String str = this.f1612b;
            if (dVar != null) {
                bVar = new C0834b(dVar);
            }
            bVar2.mo1474d(str, bVar, this.f1614d);
            return;
        }
        C0839b bVar3 = this.f1611a;
        String str2 = this.f1612b;
        if (dVar != null) {
            bVar = new C0834b(dVar);
        }
        bVar3.mo1475e(str2, bVar);
    }
}
