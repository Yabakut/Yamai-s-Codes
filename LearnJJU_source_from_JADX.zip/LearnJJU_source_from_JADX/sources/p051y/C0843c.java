package p051y;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import p023k.C0405b;
import p051y.C0839b;

/* renamed from: y.c */
public final class C0843c {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public final C0839b f1621a;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public final String f1622b;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public final C0861k f1623c;

    /* renamed from: d */
    private final C0839b.C0842c f1624d;

    /* renamed from: y.c$b */
    public interface C0845b {
        /* renamed from: a */
        void mo1833a(Object obj);
    }

    /* renamed from: y.c$c */
    private final class C0846c implements C0839b.C0840a {

        /* renamed from: a */
        private final C0848d f1625a;
        /* access modifiers changed from: private */

        /* renamed from: b */
        public final AtomicReference<C0845b> f1626b = new AtomicReference<>((Object) null);

        /* renamed from: y.c$c$a */
        private final class C0847a implements C0845b {

            /* renamed from: a */
            final AtomicBoolean f1628a;

            private C0847a() {
                this.f1628a = new AtomicBoolean(false);
            }

            /* renamed from: a */
            public void mo1833a(Object obj) {
                if (!this.f1628a.get() && C0846c.this.f1626b.get() == this) {
                    C0843c.this.f1621a.mo1473c(C0843c.this.f1622b, C0843c.this.f1623c.mo1839d(obj));
                }
            }
        }

        C0846c(C0848d dVar) {
            this.f1625a = dVar;
        }

        /* renamed from: c */
        private void m2646c(Object obj, C0839b.C0841b bVar) {
            ByteBuffer byteBuffer;
            if (this.f1626b.getAndSet((Object) null) != null) {
                try {
                    this.f1625a.mo1276a(obj);
                    bVar.mo842a(C0843c.this.f1623c.mo1839d((Object) null));
                } catch (RuntimeException e) {
                    C0405b.m1464c("EventChannel#" + C0843c.this.f1622b, "Failed to close event stream", e);
                    byteBuffer = C0843c.this.f1623c.mo1838c("error", e.getMessage(), (Object) null);
                }
            } else {
                byteBuffer = C0843c.this.f1623c.mo1838c("error", "No active stream to cancel", (Object) null);
                bVar.mo842a(byteBuffer);
            }
        }

        /* renamed from: d */
        private void m2647d(Object obj, C0839b.C0841b bVar) {
            C0847a aVar = new C0847a();
            if (this.f1626b.getAndSet(aVar) != null) {
                try {
                    this.f1625a.mo1276a((Object) null);
                } catch (RuntimeException e) {
                    C0405b.m1464c("EventChannel#" + C0843c.this.f1622b, "Failed to close existing event stream", e);
                }
            }
            try {
                this.f1625a.mo1277b(obj, aVar);
                bVar.mo842a(C0843c.this.f1623c.mo1839d((Object) null));
            } catch (RuntimeException e2) {
                this.f1626b.set((Object) null);
                C0405b.m1464c("EventChannel#" + C0843c.this.f1622b, "Failed to open event stream", e2);
                bVar.mo842a(C0843c.this.f1623c.mo1838c("error", e2.getMessage(), (Object) null));
            }
        }

        /* renamed from: a */
        public void mo1482a(ByteBuffer byteBuffer, C0839b.C0841b bVar) {
            C0854i e = C0843c.this.f1623c.mo1840e(byteBuffer);
            if (e.f1634a.equals("listen")) {
                m2647d(e.f1635b, bVar);
            } else if (e.f1634a.equals("cancel")) {
                m2646c(e.f1635b, bVar);
            } else {
                bVar.mo842a((ByteBuffer) null);
            }
        }
    }

    /* renamed from: y.c$d */
    public interface C0848d {
        /* renamed from: a */
        void mo1276a(Object obj);

        /* renamed from: b */
        void mo1277b(Object obj, C0845b bVar);
    }

    public C0843c(C0839b bVar, String str) {
        this(bVar, str, C0869r.f1649b);
    }

    public C0843c(C0839b bVar, String str, C0861k kVar) {
        this(bVar, str, kVar, (C0839b.C0842c) null);
    }

    public C0843c(C0839b bVar, String str, C0861k kVar, C0839b.C0842c cVar) {
        this.f1621a = bVar;
        this.f1622b = str;
        this.f1623c = kVar;
        this.f1624d = cVar;
    }

    /* renamed from: d */
    public void mo1832d(C0848d dVar) {
        C0846c cVar = null;
        if (this.f1624d != null) {
            C0839b bVar = this.f1621a;
            String str = this.f1622b;
            if (dVar != null) {
                cVar = new C0846c(dVar);
            }
            bVar.mo1474d(str, cVar, this.f1624d);
            return;
        }
        C0839b bVar2 = this.f1621a;
        String str2 = this.f1622b;
        if (dVar != null) {
            cVar = new C0846c(dVar);
        }
        bVar2.mo1475e(str2, cVar);
    }
}
