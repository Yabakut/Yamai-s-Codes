package p051y;

import android.content.Intent;

/* renamed from: y.m */
public interface C0863m {
    /* renamed from: d */
    boolean mo1848d(Intent intent);
}
