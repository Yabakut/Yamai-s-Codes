package p051y;

import java.nio.ByteBuffer;

/* renamed from: y.h */
public interface C0853h<T> {
    /* renamed from: a */
    T mo1834a(ByteBuffer byteBuffer);

    /* renamed from: b */
    ByteBuffer mo1835b(T t);
}
