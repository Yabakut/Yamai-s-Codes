package p051y;

/* renamed from: y.o */
public interface C0865o {
    /* renamed from: a */
    boolean mo1219a(int i, String[] strArr, int[] iArr);
}
