package p051y;

import java.nio.ByteBuffer;

/* renamed from: y.k */
public interface C0861k {
    /* renamed from: a */
    ByteBuffer mo1836a(String str, String str2, Object obj, String str3);

    /* renamed from: b */
    ByteBuffer mo1837b(C0854i iVar);

    /* renamed from: c */
    ByteBuffer mo1838c(String str, String str2, Object obj);

    /* renamed from: d */
    ByteBuffer mo1839d(Object obj);

    /* renamed from: e */
    C0854i mo1840e(ByteBuffer byteBuffer);

    /* renamed from: f */
    Object mo1841f(ByteBuffer byteBuffer);
}
