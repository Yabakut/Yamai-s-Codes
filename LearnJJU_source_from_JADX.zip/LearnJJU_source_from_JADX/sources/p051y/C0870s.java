package p051y;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;

/* renamed from: y.s */
public final class C0870s implements C0853h<String> {

    /* renamed from: a */
    private static final Charset f1651a = Charset.forName("UTF8");

    /* renamed from: b */
    public static final C0870s f1652b = new C0870s();

    private C0870s() {
    }

    /* renamed from: c */
    public String mo1834a(ByteBuffer byteBuffer) {
        int i;
        byte[] bArr;
        if (byteBuffer == null) {
            return null;
        }
        int remaining = byteBuffer.remaining();
        if (byteBuffer.hasArray()) {
            bArr = byteBuffer.array();
            i = byteBuffer.arrayOffset();
        } else {
            bArr = new byte[remaining];
            byteBuffer.get(bArr);
            i = 0;
        }
        return new String(bArr, i, remaining, f1651a);
    }

    /* renamed from: d */
    public ByteBuffer mo1835b(String str) {
        if (str == null) {
            return null;
        }
        byte[] bytes = str.getBytes(f1651a);
        ByteBuffer allocateDirect = ByteBuffer.allocateDirect(bytes.length);
        allocateDirect.put(bytes);
        return allocateDirect;
    }
}
