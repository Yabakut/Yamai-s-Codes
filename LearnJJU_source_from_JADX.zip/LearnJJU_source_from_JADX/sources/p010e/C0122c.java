package p010e;

/* renamed from: e.c */
public final class C0122c {
    /* renamed from: a */
    public static <T> T m408a(T t) {
        t.getClass();
        return t;
    }
}
