package p010e;

/* renamed from: e.a */
public interface C0120a<T> {
    void accept(T t);
}
