package p010e;

/* renamed from: e.b */
public class C0121b {
    /* renamed from: a */
    public static <T> T m407a(T t, String str) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(str);
    }
}
