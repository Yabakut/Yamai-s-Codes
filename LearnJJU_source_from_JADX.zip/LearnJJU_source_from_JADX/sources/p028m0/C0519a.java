package p028m0;

import java.io.Closeable;

/* renamed from: m0.a */
public final class C0519a {
    /* renamed from: a */
    public static final void m1795a(Closeable closeable, Throwable th) {
        if (closeable != null) {
            if (th == null) {
                closeable.close();
                return;
            }
            try {
                closeable.close();
            } catch (Throwable th2) {
                C0124b.m410a(th, th2);
            }
        }
    }
}
