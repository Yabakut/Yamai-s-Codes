package p001a0;

import android.annotation.TargetApi;
import android.view.PointerIcon;
import java.util.HashMap;
import p049x.C0756g;

@TargetApi(24)
/* renamed from: a0.a */
public class C0006a {

    /* renamed from: c */
    private static HashMap<String, Integer> f10c;
    /* access modifiers changed from: private */

    /* renamed from: a */
    public final C0009c f11a;

    /* renamed from: b */
    private final C0756g f12b;

    /* renamed from: a0.a$a */
    class C0007a implements C0756g.C0758b {
        C0007a() {
        }

        /* renamed from: a */
        public void mo8a(String str) {
            C0006a.this.f11a.setPointerIcon(C0006a.this.m13d(str));
        }
    }

    /* renamed from: a0.a$b */
    class C0008b extends HashMap<String, Integer> {
        C0008b() {
            put("alias", 1010);
            put("allScroll", 1013);
            put("basic", 1000);
            put("cell", 1006);
            put("click", 1002);
            put("contextMenu", 1001);
            put("copy", 1011);
            put("forbidden", 1012);
            put("grab", 1020);
            put("grabbing", 1021);
            put("help", 1003);
            put("move", 1013);
            put("none", 0);
            put("noDrop", 1012);
            put("precise", 1007);
            put("text", 1008);
            put("resizeColumn", 1014);
            put("resizeDown", 1015);
            put("resizeUpLeft", 1016);
            put("resizeDownRight", 1017);
            put("resizeLeft", 1014);
            put("resizeLeftRight", 1014);
            put("resizeRight", 1014);
            put("resizeRow", 1015);
            put("resizeUp", 1015);
            put("resizeUpDown", 1015);
            put("resizeUpLeft", 1017);
            put("resizeUpRight", 1016);
            put("resizeUpLeftDownRight", 1017);
            put("resizeUpRightDownLeft", 1016);
            put("verticalText", 1009);
            put("wait", 1004);
            put("zoomIn", 1018);
            put("zoomOut", 1019);
        }
    }

    /* renamed from: a0.a$c */
    public interface C0009c {
        /* renamed from: b */
        PointerIcon mo9b(int i);

        void setPointerIcon(PointerIcon pointerIcon);
    }

    public C0006a(C0009c cVar, C0756g gVar) {
        this.f11a = cVar;
        this.f12b = gVar;
        gVar.mo1748b(new C0007a());
    }

    /* access modifiers changed from: private */
    /* renamed from: d */
    public PointerIcon m13d(String str) {
        if (f10c == null) {
            f10c = new C0008b();
        }
        return this.f11a.mo9b(f10c.getOrDefault(str, 1000).intValue());
    }

    /* renamed from: c */
    public void mo7c() {
        this.f12b.mo1748b((C0756g.C0758b) null);
    }
}
