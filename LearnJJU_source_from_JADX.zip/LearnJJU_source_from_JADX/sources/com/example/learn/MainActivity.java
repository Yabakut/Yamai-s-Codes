package com.example.learn;

import p020io.flutter.embedding.android.C0220d;

public final class MainActivity extends C0220d {
}
