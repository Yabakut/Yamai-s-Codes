package p048w0;

import kotlin.jvm.internal.C0425e;
import p046v0.C0724y1;

/* renamed from: w0.b */
public abstract class C0741b extends C0724y1 {
    private C0741b() {
    }

    public /* synthetic */ C0741b(C0425e eVar) {
        this();
    }
}
