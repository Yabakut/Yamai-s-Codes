package p048w0;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.C0425e;
import kotlin.jvm.internal.C0429i;
import p011e0.C0141q;
import p017h0.C0195g;
import p046v0.C0703s1;
import p046v0.C0717w0;

/* renamed from: w0.a */
public final class C0740a extends C0741b {
    private volatile C0740a _immediate;

    /* renamed from: e */
    private final Handler f1391e;

    /* renamed from: f */
    private final String f1392f;

    /* renamed from: g */
    private final boolean f1393g;

    /* renamed from: h */
    private final C0740a f1394h;

    public C0740a(Handler handler, String str) {
        this(handler, str, false);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0740a(Handler handler, String str, int i, C0425e eVar) {
        this(handler, (i & 2) != 0 ? null : str);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    private C0740a(Handler handler, String str, boolean z) {
        super((C0425e) null);
        C0740a aVar = null;
        this.f1391e = handler;
        this.f1392f = str;
        this.f1393g = z;
        this._immediate = z ? this : aVar;
        C0740a aVar2 = this._immediate;
        if (aVar2 == null) {
            aVar2 = new C0740a(handler, str, true);
            this._immediate = aVar2;
            C0141q qVar = C0141q.f277a;
        }
        this.f1394h = aVar2;
    }

    /* renamed from: r */
    private final void m2362r(C0195g gVar, Runnable runnable) {
        C0703s1.m2179c(gVar, new CancellationException("The task was rejected, the handler underlying the dispatcher '" + this + "' was closed"));
        C0717w0.m2290b().mo1422m(gVar, runnable);
    }

    public boolean equals(Object obj) {
        return (obj instanceof C0740a) && ((C0740a) obj).f1391e == this.f1391e;
    }

    public int hashCode() {
        return System.identityHashCode(this.f1391e);
    }

    /* renamed from: m */
    public void mo1422m(C0195g gVar, Runnable runnable) {
        if (!this.f1391e.post(runnable)) {
            m2362r(gVar, runnable);
        }
    }

    /* renamed from: n */
    public boolean mo1423n(C0195g gVar) {
        return !this.f1393g || !C0429i.m1493a(Looper.myLooper(), this.f1391e.getLooper());
    }

    /* renamed from: t */
    public C0740a mo1424p() {
        return this.f1394h;
    }

    public String toString() {
        String q = mo1697q();
        if (q != null) {
            return q;
        }
        String str = this.f1392f;
        if (str == null) {
            str = this.f1391e.toString();
        }
        return this.f1393g ? C0429i.m1501i(str, ".immediate") : str;
    }
}
